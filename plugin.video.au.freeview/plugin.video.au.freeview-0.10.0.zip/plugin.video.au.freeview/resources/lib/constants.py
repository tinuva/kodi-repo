M3U8_URL = 'http://iptv.matthuisman.nz/au/{}/tv.json'
REGIONS = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Darwin', 'Hobart', 'Canberra']