M3U8_FILE = 'http://iptv.matthuisman.nz/au/{0}/tv.json'
CACHE_TIME = (60*60*12) #12 hours