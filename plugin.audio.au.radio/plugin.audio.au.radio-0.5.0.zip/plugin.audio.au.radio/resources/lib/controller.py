import requests

from matthuisman.controller import Controller as BaseController

from . import config

class Controller(BaseController):
    def home(self, params):
        channels = self._get_channels()

        if params.get('play'):
            channel = channels[params['play']]
            channel['url'] = channel['_play_url']
            return self._view.play(channel)
        
        slugs = sorted(channels, key=lambda k: channels[k].get('channel', channels[k]['title']))
        items = [channels[slug] for slug in slugs]
        items.append({'title':'Settings', 'url': self._router.get(self.settings)})

        self._view.items(items, title=self._addon.settings.get('region'), cache=False)

    def _get_channels(self):
        channels = {}

        url = config.M3U8_FILE.format(self._addon.settings.get('region'))
        func = lambda: requests.get(url).json()
        data = self._addon.cache.function(url, func, expires=config.CACHE_TIME)
        
        for slug in data:
            channel = data[slug]

            info = {
                'title': channel['name'],
                'plot': channel.get('description',''),
                'mediatype': 'music',
            }

            url = channel['mjh_sub']
            item = {
                'title': channel['name'],
                'images': {'thumb': channel.get('logo', None)},
                'url': self._router.get(self.home, {'play': slug}, live=True),
                '_play_url': url,
                'playable': True,
                'info': info,
                'video': channel.get('video',{}),
                'audio': channel.get('audio',{}),
                'options': {'headers': channel.get('headers', {})},
            }

            if channel.get('channel'):
                item['channel'] = channel['channel']

            channels[slug] = item

        return channels