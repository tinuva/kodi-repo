M3U8_URL = 'http://iptv.matthuisman.nz/au/{}/radio.json'
REGIONS = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Darwin', 'Hobart', 'Canberra']