M3U8_URL = 'http://iptv.matthuisman.nz/au/{}/radio.json'
CHANNELS_EXPIRY = (60*60*12) #12 hours

REGIONS = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Darwin', 'Hobart', 'Canberra']