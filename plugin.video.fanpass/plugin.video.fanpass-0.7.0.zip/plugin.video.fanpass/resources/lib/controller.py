import os

from matthuisman.controller import Controller as BaseController
from matthuisman.exceptions import InputError

from .api import API
from . import config

class Controller(BaseController):
    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self._api = API(self._addon)

    def home(self, params):
        channels = {
            60: {'title':'Sky Sport 1'},
            61: {'title':'Sky Sport 2'},
            62: {'title':'Sky Sport 3'},
            63: {'title':'Sky Sport 4'},
        }

        items = []
        for channel_num in channels:
            channel = channels[channel_num]

            channel.update({
                'playable': True,
                'images': {'thumb': os.path.join(self._addon.path, 'resources', 'images', str(channel_num) + '.png')},
                'url': self._router.get(self.home, {'play': channel_num}, live=True),
                'vid_type': 'hls',
            })

            items.append(channel)

        if not self._api.logged_in:
            items.append({'title':'[B]Login[/B]', 'url': self._router.get(self.login)})
        else:
            items.append({'title':'Logout', 'url': self._router.get(self.logout)})

        items.append({'title':'Settings', 'url': self._router.get(self.settings)})

        if params.get('play'):
            if not self._api.logged_in:
                self._do_login()
                
            channel = channels[int(params['play'])]
            channel.update({
                'url': self._api.get_play_url(params['play']),
                'options': {'use_ia_hls': self._addon.settings.getBool('use_ia_hls'), 'fetch_cookies': self._addon.settings.getBool('use_ia_hls')},
            })

            self._view.play(channel)
        else:
            self._view.items(items)

    def login(self, params):
        if self._api.logged_in:
            return

        self._do_login()
        self._view.refresh()

    def logout(self, params):
        if not self._view.dialog_yes_no("Are you sure you want to logout?"):
            return

        self._api.logout()
        self._view.refresh()

    def _do_login(self):
        username = self._view.get_input("Fan Pass Email", default=self._addon.data.get('username', '')).strip()
        if not username:
            raise InputError()

        password = self._view.get_input("Fan Pass Password", hidden=True).strip()
        if not password:
            raise InputError()

        self._addon.data['username'] = username
        self._api.login(username=username, password=password)