import requests

from matthuisman.exceptions import LoginError, ComsError

from . import config
## REMEMBER: NOT TOO MANY FAILED LOGINS ELSE LOCKED OUT ##

class API(object):
    def __init__(self, addon):
        self._addon = addon
        self._session = requests.session()
        self._session.headers.update(config.HEADERS)
        self._logged_in = self._addon.data.get('nllinktoken') != None

    @property
    def logged_in(self):
        return self._logged_in

    def logout(self):
        self._session.post(config.BASE_API+'/service/logout', data={'format': 'json'})
        self._addon.data.pop('nllinktoken', None)
        self._logged_in = False

    def login(self, username, password):
        data = {
            'username': username,
            'password': password,
            'cookielink': 'true',
            'format': 'json',
        }

        r = self._session.post(config.BASE_API+'/secure/authenticate', data=data)

        json = r.json()
        nllinktoken = r.cookies.get_dict().pop('nllinktoken', None)
        if json.get('code') != 'loginsuccess' or not nllinktoken:
            self._addon.data.pop('nllinktoken', None)
            self._logged_in = False
            raise LoginError("Failed to login: '{0}'".format(json.get('code')))

        self._logged_in = True
        self._addon.data['nllinktoken'] = nllinktoken

    def get_play_url(self, channel_id):
        payload = {
            'id': channel_id,
            'nt': 1,
            'type': 'channel',
            'format': 'json',
        }

        try:
            login_cookies = {'nllinktoken': self._addon.data.get('nllinktoken'), 'UserName': self._addon.data.get('username')}
            data = self._session.post(config.BASE_API+'/service/publishpoint', data=payload, cookies=login_cookies).json()
            if not data.get('path'):
                raise ComsError
        except Exception as e:
            raise ComsError("{0}\nCheck your Fan Pass subscription is current.".format(e))
        else:
            return data['path']

    def get_channels(self, **kwargs):
        return self._session.get(config.BASE_API+'/service/channels', params={'format': 'json'}, **kwargs).json()