from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    LOGIN            = 30000
    LOGOUT           = 30002
    SETTINGS         = 30003
    ASK_USERNAME     = 30004
    ASK_PASSWORD     = 30005
    LOGIN_ERROR      = 30006
    LOGOUT_YES_NO    = 30007
    SKY_SPORT_1      = 30008
    SKY_SPORT_2      = 30009
    SKY_SPORT_3      = 30010
    SKY_SPORT_4      = 30011

_ = Language()