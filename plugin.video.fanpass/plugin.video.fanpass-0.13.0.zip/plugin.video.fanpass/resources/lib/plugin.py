import os

from matthuisman import plugin, gui, cache, userdata, signals, inputstream
from matthuisman.constants import ADDON_PATH

from .api import API
from .language import _

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login))
    else:
        channels = _get_channels()
        for channel_num in channels:
            folder.add_items([channels[channel_num]])

        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout))

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD, default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        try:
            api.login(username=username, password=password)
            gui.refresh()
        except Exception as e:
            gui.ok(_.LOGIN_ERROR)

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()

@plugin.route()
@plugin.login_required()
def play(channel):
    channels = _get_channels()
    data = api.play(channel)

    item = channels[int(channel)]
    item.inputstream = inputstream.Widevine(license_key='https://prod-lic2widevine.sd-ngp.net/proxy')
    item.headers['Authorization'] = 'bearer {}'.format(data['drmToken'])
    item.properties['inputstream.adaptive.manifest_update_parameter'] = 'full'
    item.path = data['path']

    return item

def _get_channels():
    return {
        60: plugin.Item(
            label    = _.SKY_SPORT_1, 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '60.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=60)),

        61: plugin.Item(
            label    = _.SKY_SPORT_2, 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '61.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=61)),

        62: plugin.Item(
            label    = _.SKY_SPORT_3, 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '62.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=62)),

        63: plugin.Item(
            label    = _.SKY_SPORT_4, 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '63.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=63)),
    }