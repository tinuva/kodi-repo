HEADERS = {
    'User-Agent': 'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36 android mobile fan pass 8.0904',
    #'User-Agent': 'Mozilla/5.0 (Linux; Android 8.1.0; MI 5 Build/OPM7.181105.004; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/69.0.3497.109 Mobile Safari/537.36 android mobile fan pass 8.0904'
}

API_URL = 'https://fanpass.co.nz/{}'