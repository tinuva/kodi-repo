import hashlib

from matthuisman import userdata
from matthuisman.session import Session

from .constants import API_URL, HEADERS

class Error(Exception):
    pass

class API(object):
    def __init__(self):
        self.new_session()

    def new_session(self):
        self._session = Session(HEADERS, base_url=API_URL)
        self._logged_in = userdata.get('nllinktoken') != None

    @property
    def logged_in(self):
        return self._logged_in

    def logout(self):
        self._session.post('service/logout', data={'format': 'json'})
        userdata.delete('nllinktoken')
        self.new_session()

    def login(self, username, password):
        data = {
            'username': username,
            'password': password,
            'cookielink': 'true',
            'format': 'json',
        }

        r = self._session.post('secure/authenticate', data=data)

        json = r.json()
        nllinktoken = r.cookies.get_dict().pop('nllinktoken', None)
        if json.get('code') != 'loginsuccess' or not nllinktoken:
            self.logout()
            raise Error(json.get('code', ''))

        userdata.set('nllinktoken', nllinktoken)
        self.new_session()

    def deviceid(self):
        return hashlib.sha1(userdata.get('username')).hexdigest()[:8]

    def play(self, channel_id):
        payload = {
            'id': channel_id,
            'nt': 1,
            'type': 'channel',
            'format': 'json',
            'drmtoken': True,
            'deviceid': self.deviceid(),
        }

        login_cookies = {'nllinktoken': userdata.get('nllinktoken'), 'UserName': userdata.get('username')}
        return self._session.post('service/publishpoint', data=payload, cookies=login_cookies).json()

    # def channels(self, **kwargs):
    #     return self._session.get('service/channels', params={'format': 'json'}, **kwargs).json()