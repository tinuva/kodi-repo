from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME     = 30001
    ASK_PASSWORD     = 30002
    SKY_SPORT_1      = 30003
    SKY_SPORT_2      = 30004
    SKY_SPORT_3      = 30005
    SKY_SPORT_4      = 30006

_ = Language()