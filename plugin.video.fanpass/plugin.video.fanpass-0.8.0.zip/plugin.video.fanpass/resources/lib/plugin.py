import os

from matthuisman import plugin, gui, cache, settings, userdata
from matthuisman.util import get_string as _
from matthuisman.constants import ADDON_PATH

from .api import API

L_LOGIN            = 30000
L_LOGOUT           = 30002
L_SETTINGS         = 30003
L_ASK_USERNAME     = 30004
L_ASK_PASSWORD     = 30005
L_LOGIN_ERROR      = 30006
L_LOGOUT_YES_NO    = 30007
L_SKY_SPORT_1      = 30008
L_SKY_SPORT_2      = 30009
L_SKY_SPORT_3      = 30010
L_SKY_SPORT_4      = 30011

api = API()

@plugin.before_dispatch()
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in
#    cache.enabled    = settings.getBool('use_cache', True)

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not api.logged_in:
        folder.add_item(label=_(L_LOGIN, bold=True), path=plugin.url_for(login))

    channels = _get_channels()
    for channel_num in channels:
        folder.add_items([channels[channel_num]])

    if api.logged_in:
        folder.add_item(label=_(L_LOGOUT), path=plugin.url_for(logout))

    folder.add_item(label=_(L_SETTINGS), path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_(L_ASK_USERNAME), default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_(L_ASK_PASSWORD), default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        try:
            api.login(username=username, password=password)
            gui.refresh()
        except Exception as e:
            gui.ok(_(L_LOGIN_ERROR))

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_(L_LOGOUT_YES_NO)):
        return

    api.logout()
    gui.refresh()

@plugin.route()
@plugin.login_required()
def play(channel):
    channels = _get_channels()
    item = channels[int(channel)]
    item.path = api.play(channel)
    return item

def _get_channels():
    return {
        60: plugin.Item(
            label    = _(L_SKY_SPORT_1), 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '60.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=60)),

        61: plugin.Item(
            label    = _(L_SKY_SPORT_2), 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '61.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=61)),

        62: plugin.Item(
            label    = _(L_SKY_SPORT_3), 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '62.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=62)),

        63: plugin.Item(
            label    = _(L_SKY_SPORT_4), 
            art      = {'thumb': os.path.join(ADDON_PATH, 'resources', 'images', '63.png')}, 
            playable = True, 
            path     = plugin.url_for(play, is_live=True, channel=63)),
    }