import os

try:
    import cPickle as pickle
except:
    import pickle

from . import peewee, userdata
from .constants import DB_PATH, DB_PRAGMAS, DB_MAX_INSERTS, DB_TABLES_KEY
from .util import hash_6

path = os.path.dirname(DB_PATH)
if not os.path.exists(path):
    os.makedirs(path)

db = peewee.SqliteDatabase(DB_PATH, pragmas=DB_PRAGMAS)

class HashField(peewee.TextField):
    def db_value(self, value):
        return hash_6(value)

class PickledField(peewee.BlobField):
    def db_value(self, value):
        if value != None:
            return super(PickledField, self).db_value(pickle.dumps(value, pickle.HIGHEST_PROTOCOL))

    def python_value(self, value):
        if value != None:
            return super(PickledField, self).python_value(pickle.loads(str(value)))

class Model(peewee.Model):
    checksum = ''

    @classmethod
    def get_checksum(cls):
        _checksum = [cls.checksum]

        for field in cls._meta.sorted_fields:
            _checksum.append(field.__dict__)

        return hash_6(_checksum)

    @classmethod
    def delete(cls, *args, **kwargs):
        return super(Model, cls).delete().where(*args, **kwargs).execute()

    @classmethod
    def exists(cls, *args, **kwargs):
        try:
            return cls.select().where(*args, **kwargs).exists()
        except peewee.OperationalError:
            return False

    @classmethod
    def set(cls, *args, **kwargs):
        return super(Model, cls).replace(*args, **kwargs).execute()

    @classmethod
    def name(cls):
        return cls._meta.table_name

    @classmethod
    def truncate(cls):
        return super(Model, cls).delete().execute()

    @classmethod
    def replace_many(cls, data):
        with db.atomic():
            for idx in range(0, len(data), DB_MAX_INSERTS):
                super(Model, cls).replace_many(data[idx:idx+DB_MAX_INSERTS]).execute()

    def to_dict(self):
        data = {}

        for field in self._meta.sorted_fields:
            field_data = self.__data__.get(field.name)
            data[field.name] = field_data

        return data

    def __str__(self):
        return str(self.to_dict())

    def __repr__(self):
        return self.__str__

    class Meta:
        database = db
        only_save_dirty = True

def check_table(table):
    _tables = userdata.get(DB_TABLES_KEY, {})

    key      = table.name()
    checksum = table.get_checksum()

    if _tables.get(key) == checksum:
        return

    db.drop_tables([table])
    db.create_tables([table])

    _tables[key] = checksum
    userdata.set(DB_TABLES_KEY, _tables)

def delete():
    close()
    userdata.set(DB_TABLES_KEY, {})
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

def close():
    db.close()

def connect():
    db.connect(reuse_if_open=True)