# plugin.video.fanpass

Unofficial 3rd party Fan Pass plugin for Kodi.

https://www.matthuisman.nz/2018/06/fan-pass-kodi-add-on.html
