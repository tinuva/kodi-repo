from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME                = 30000
    ASK_PASSWORD                = 30001
    SHOWS                       = 30002
    GENRE                       = 30003
    SEASON                      = 30004
    LOGIN_ERROR                 = 30005

_ = Language()