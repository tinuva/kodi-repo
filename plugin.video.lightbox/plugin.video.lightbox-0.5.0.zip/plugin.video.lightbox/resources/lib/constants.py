HEADERS = {
    'User-Agent': 'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36', 
    'X-Forwarded-For': '202.89.4.222',
}

API_URL            = 'https://api.lightbox.co.nz/api/client/gql'

SHOWS_EXPIRY       = (60*60*24) #24 Hours
EPISODE_EXPIRY     = (60*5)     #5 Minutes

BRIGHTCOVE_URL     = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/ref:{}?jwtauth={}'
BRIGHTCOVE_ACCOUNT = '5449166731001'
BRIGHTCOVE_KEY     = 'BCpkADawqM31jJSqDf-CU0kRN8vMu46gUZEzcsZuB6MCCF3tx37IuORLwSj3IGTghvxSyTplhz9kRrSCm3zBR1S2UExgefbeYzdgIpcoEmU3VV-loNsg_BV7pdsVMz6_Am0cz_sS6mOG2jeT'

ALL_SHOWS_ID       = 'f14763a1-ba76-412c-adf2-a37c118f6846'
ALL_GENRE_ID       = '/tv-series/all'