import hashlib

from matthuisman import userdata, inputstream, cache, plugin
from matthuisman.session import Session

from .constants import API_URL, HEADERS, ALL_GENRE_ID, EPISODE_EXPIRY, BRIGHTCOVE_URL, BRIGHTCOVE_ACCOUNT, BRIGHTCOVE_KEY
from . import queries

class API(object):
    def new_session(self):
        self._logged_in = False

        self._session = Session(HEADERS)
        self._set_access_token(userdata.get('jwt_token'))

    def _set_access_token(self, token):
        if token:
            self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
            self._logged_in = True

    @property
    def logged_in(self):
        return self._logged_in

    def logout(self):
        userdata.delete('jwt_token')
        self.new_session()

    def _device_info(self, username):
        return {
            'uuid': hashlib.sha1(username).hexdigest(),
            'platform': 'Android',
            'name': 'KODI',
            'os': 'KODI',
            'model': 'KODI',
            #'version': '27'
        }

    def _query_request(self, query, variables=None, **kwargs):
        data = {
            'query': ' '.join(query.split()), 
            'variables': variables or {},
        }

        return self._session.post(API_URL, json=data, **kwargs).json()

    def login(self, username, password):
        variables = {
            'input': {
                'deviceInfo': self._device_info(username),
            },
            'username': username,
            'password': password,
        }

        data = self._query_request(queries.LOGIN, variables)
        if data.get('errors'):
            raise Exception(data['errors'][0].get('message'))
        
        jwt_token = data['data']['login']['session']['token']
        userdata.set('jwt_token', jwt_token)

        self.new_session()

    def all_genre(self):
        return self._shows(ALL_GENRE_ID)['data']['screen']['components'][0]['items']

    def genre(self, genre):
        return self._shows(genre)['data']['screen']

    @cache.cached(EPISODE_EXPIRY, key=lambda self, path: path)
    def show(self, path):
        return self._shows(path)['data']['screen']['components'][0]['series']

    def _shows(self, screenID):
        variables = {
            'screenId': screenID,
        }

        return self._query_request(queries.TVSHOWS, variables)

    def search(self, query):
        variables = {
            'input': {
                'query': query,
            },
        }

        results = self._query_request(queries.SEARCH, variables)['data']['search']['components']
        for result in results:
            if result['contentType'] == 'SERIES':
                return result['tiles']

        return []

    def playback_auth(self, contentID):
        variables = {
            'contentItemId': contentID,
        }

        return self._query_request(queries.PLAYBACK_AUTH, variables)

    def get_brightcove_src(self, referenceID, jwt_token):
        brightcove_url = BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, referenceID, jwt_token)
        data = self._session.get(brightcove_url, headers={'BCOV-POLICY': BRIGHTCOVE_KEY}).json()

        videos = []
        for source in data['sources']:
            if not source.get('src'):
                continue

            if source.get('container') == 'MP4':
                videos.append({
                    'item': plugin.Item(
                        path = source['src'], 
                        art = False), 
                    '_sort': source.get('avg_bitrate', source.get('height')),
                })

            elif 'key_systems' in source and 'com.widevine.alpha' in source['key_systems']:
                videos.append({
                    'item': plugin.Item(
                        inputstream = inputstream.Widevine(source['key_systems']['com.widevine.alpha']['license_url']), 
                        path = source['src'], 
                        art = False),
                })

        if videos:
            videos = sorted(videos, key=lambda x: x.get('_sort'), reverse=True)
            return videos[0]['item']

        raise Exception('Could not find a source from brightcove')