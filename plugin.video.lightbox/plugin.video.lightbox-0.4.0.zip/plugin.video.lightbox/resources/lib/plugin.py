import os

from matthuisman import plugin, gui, cache, userdata, signals

from .api import API
from .language import _
from .constants import HEADERS, SHOWS_EXPIRY, ALL_SHOWS_ID

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True),  path=plugin.url_for(login))
    else:
        folder.add_item(label=_(_.SHOWS,  _bold=True), path=plugin.url_for(genre, id=ALL_SHOWS_ID),  cache_key=cache.key_for(genre, id=ALL_SHOWS_ID))
        folder.add_item(label=_(_.GENRE,  _bold=True), path=plugin.url_for(all_genre),  cache_key=cache.key_for(all_genre))
        folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search),     cache_key=cache.key_for(search))
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout))

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD, default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        try:
            api.login(username=username, password=password)
            gui.refresh()
        except Exception as e:
            gui.ok(_(_.LOGIN_ERROR, error=e))

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def all_genre():
    folder = plugin.Folder(title=_.GENRE)
    rows =  api.all_genre()

    for row in sorted(rows, key=lambda x: x['name'].lower().strip(), reverse=False):
        folder.add_item(
            label = row['name'],
            path  = plugin.url_for(genre, id=row['id']),
            cache_key = cache.key_for(genre, id=row['id']),
        )

    return folder

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def genre(id):
    genre = api.genre(id)
    folder = plugin.Folder(title=genre['title'])
    folder.add_items(_parse_shows(genre['components'][0]['tiles']))
    return folder

@plugin.route()
def show(path):
    show = api.show(path)
    folder = plugin.Folder(title=show['title'])
    folder.add_items(_parse_show(show))
    return folder

@plugin.route()
def episodes(path, season_id):
    show = api.show(path)

    folder = plugin.Folder(title=show['title'])

    for season in show['seasons']:
        if season['id'] == season_id:
            folder.add_items(_parse_episodes(show, season))
            break

    return folder

@plugin.route()
def search():
    query = gui.input(_.SEARCH, default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    @cache.cached(SHOWS_EXPIRY)
    def get_results(query):
        folder = plugin.Folder(title=_(_.SEARCH_FOR, query=query))

        rows = api.search(query)
        folder.add_items(_parse_shows(rows))

        if not folder.items:
            folder.add_item(
                label     = _(_.NO_RESULTS, _label=True),
                is_folder = False,
            )

        return folder

    return get_results(query)

@plugin.route()
@plugin.login_required()
def play(id):
    data = api.playback_auth(id)

    referenceID = data['data']['playbackAuth']['videos'][0]['referenceId']
    jwt_token   = data['data']['playbackAuth']['videos'][0]['token']

    item = api.get_brightcove_src(referenceID, jwt_token)
    item.headers = HEADERS

    return item

def _parse_shows(rows):
    items = []
    
    for row in sorted(rows, key=lambda x: x['header'].lower().strip(), reverse=False):
        if row['contentItem']['isComingSoon']:
            continue

        item = plugin.Item(
            label = row['header'],
            path  = plugin.url_for(show, path=row['contentItem']['path']),
            cache_key = row['contentItem']['path'],
            info  = {
                'plot': row['contentItem']['description'],
                'mediatype': 'tvshow',
            },
            art = {
                'thumb': row['image'], 
                'fanart': row['contentItem']['keyart']['uri'],
            },
        )

        items.append(item)

    return items

def _parse_show(show):
    items = []

    for season in show['seasons']:
        item = plugin.Item(
            label = _(_.SEASON, season_number=season['seasonNumber']),
            path  = plugin.url_for(episodes, path=show['path'], season_id=season['id']),
            cache_key = show['path'],
            info = {
                'plot': season['description'],
            },
            art = {
                'thumb': show['images'][0]['uri'], 
                'fanart': show['keyart']['uri'],
            },
        )

        items.append(item)

    return items


def _parse_episodes(show, season):
    items = []

    for episode in season['episodes']:
        if episode['isComingSoon']:
            continue

        item = plugin.Item(
            label = episode['title'],
            playable = True,
            path = plugin.url_for(play, id=episode['id']),
            info = {
                'plot': episode['description'],
                'duration': episode['duration']*60,
                'tvshowtitle': show['title'],
                'mediatype': 'episode',
                'season' : int(episode['seasonNumber']),
                'episode': int(episode['episodeNumber']),
            },
            art = {
                'thumb': episode['images'][0]['uri'], 
                'fanart': show['keyart']['uri']
            },
        )

        items.append(item)

    return items