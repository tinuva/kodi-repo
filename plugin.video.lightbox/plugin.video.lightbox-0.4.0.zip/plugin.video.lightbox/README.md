# plugin.video.lightbox

Unofficial 3rd party Lightbox.co.nz plugin for Kodi.

https://www.matthuisman.nz/2018/06/lightbox-kodi-add-on.html
