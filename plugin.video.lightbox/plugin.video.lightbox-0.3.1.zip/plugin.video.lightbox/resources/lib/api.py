import requests
import hashlib

from matthuisman.exceptions import LoginError
from matthuisman.util import process_brightcove

from . import config
from . import queries

class API(object):
    def __init__(self, addon):
        self._addon = addon

        self._session = requests.session()
        self._session.headers.update(config.HEADERS)

        jwt_token = self._addon.data.get('jwt_token')
        if jwt_token:
            self._session.headers.update({'Authorization': 'Bearer {0}'.format(jwt_token)})

        self._logged_in = jwt_token != None

    @property
    def logged_in(self):
        return self._logged_in

    def _query_request(self, query, variables=None, **kwargs):
        if not variables: variables = {}
        data = {'query': " ".join(query.split()), 'variables': variables}
        return self._session.post(config.API_ENDPOINT, json=data, **kwargs).json()

    def _device_info(self, username):
        return {
            "uuid": hashlib.sha1(username).hexdigest(),
            "platform": "Android",
            "name": "Samsung Galaxy S9",
            "os": "Android",
            "model": "Galaxy S9",
            #"version": "27"
        }

    def login(self, username, password):
        variables = {
            "input": {"deviceInfo": self._device_info(username)},
            "username": username,
            "password": password,
        }

        data = self._query_request(queries.LOGIN, variables)
        if data.get('errors'):
            raise LoginError("Failed to login: '{}'".format(data['errors'][0].get('message')))

        jwt_token = data['data']['login']['session']['token']
        self._session.headers.update({'Authorization': 'Bearer {0}'.format(jwt_token)})
        self._addon.data['jwt_token'] = jwt_token
        self._logged_in = True

    def tvshows(self, screenID, **kwargs):
        variables = {"screenId": screenID}
        return self._query_request(queries.TVSHOWS, variables, **kwargs)

    def search(self, query, **kwargs):
        variables = {"input": {"query": query}}
        return self._query_request(queries.SEARCH, variables, **kwargs)

    def playback_auth(self, contentID):
        variables = {"contentItemId": contentID}
        return self._query_request(queries.PLAYBACK_AUTH, variables)

    def logout(self):
        self._session.headers.pop('Authorization', None)
        self._addon.data.pop('jwt_token', None)
        self._logged_in = False

    def get_brightcove_src(self, referenceID, jwt_token):
        brightcove_url = config.BRIGHTCOVE_URL.format(config.BRIGHTCOVE_ACCOUNT, referenceID, jwt_token)
        data = self._session.get(brightcove_url, headers={'BCOV-POLICY': config.BRIGHTCOVE_KEY}).json()
        return process_brightcove(data)

    # def config(self):
    #     variables = {"input": {"deviceInfo": self._device_info()}}
    #     return self._query_request(queries.CONFIG, variables)

    # def account(self):
    #     data = self._query_request(queries.ACCOUNT)