import os

from matthuisman.controller import Controller as BaseController
from matthuisman.exceptions import InputError, ViewError

from .api import API
from . import config

class Controller(BaseController):
    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self._api = API(self._addon)
    
    def home(self, params):
        items = [
            {'title':'Shows',  'url': self._router.get(self.shows, {'id': 'f14763a1-ba76-412c-adf2-a37c118f6846'})},
            {'title':'Genre',  'url': self._router.get(self.shows)},
            {'title':'Search', 'url': self._router.get(self.search)},
        ]

        if not self._api.logged_in:
            items.append({'title':'[B]Login[/B]',  'url': self._router.get(self.login)})
        else:
            items.append({'title':'Logout', 'url': self._router.get(self.logout)})

        items.append({'title':'Settings', 'url': self._router.get(self.settings)})

        self._view.items(items)

    def shows(self, params):
        if params.get('path'):
            def get_items():
                items = []

                series = self._api.tvshows(params['path'])['data']['screen']['components'][0]['series']

                for season in series['seasons']:
                    items.append({'title': '[B][COLOR yellow]** Season {0} **[/COLOR][/B]'.format(season.get('seasonNumber', '')), 'is_folder': False})
                    
                    for episode in season['episodes']:
                        playable = True
                        ep_title = episode['title']

                        if episode.get('isComingSoon'):
                            playable = False
                            ep_title += ' [COLOR yellow](Coming Soon)[/COLOR]'

                        info = {
                            'title': ep_title,
                            'plot': episode['description'],
                            'duration': episode['duration']*60,
                            'mediatype': 'episode',
                            'tvshowtitle': series['title'],
                            'season' : int(episode['seasonNumber']),
                            'episode': int(episode['episodeNumber']),
                            'sortseason': int(episode['seasonNumber']),
                            'sortepisode': int(episode['episodeNumber']),
                        }

                        items.append({
                            'title': ep_title, 
                            'url': self._router.get(self.play, params={'id': episode['id']}), 
                            'images': {'thumb': episode['images'][0]['uri'], 'fanart': series['keyart']['uri']},
                            'playable': playable,
                            'info': info,
                        })

                return items

            items = self._addon.cache.function(params['path'], get_items, expires=config.EPISODE_CACHE)

        elif params.get('id'):
            def get_items():
                data = self._api.tvshows(params['id'])['data']['screen']['components'][0]
                shows = sorted(data['tiles'], key=lambda x: x['header'].lower().strip(), reverse=False)
                return self._parse_shows(shows)

            items = self._addon.cache.function(params['id'], get_items, expires=config.SHOWS_CACHE)
        else:
            def get_items():
                items = []

                data = self._api.tvshows("/tv-series/all")['data']['screen']['components'][0]['items']
                for item in data:
                    items.append({'title': item['name'], 'url': self._router.get(self.shows, params={'id': item['id'], 'title': item['name']})})

                return items

            items = self._addon.cache.function('shows', get_items, expires=config.SHOWS_CACHE)
    
        self._view.items(items, title=params.get('title', 'Shows'))

    def _parse_shows(self, shows):
        items = []

        for item in shows:
            show_title = item['header']

            if item['contentItem']['isComingSoon']:
                show_title += ' [COLOR yellow](Coming Soon)[/COLOR]'

            info = {
                'title': show_title,
                'plot': item['contentItem']['description'],
                'mediatype': 'tvshow',
            }

            items.append({
                'title': show_title, 
                'url': self._router.get(self.shows, params={'path': item['contentItem']['path'], 'title': show_title}), 
                'images': {'thumb': item['image'], 'poster': item['image'], 'fanart': item['contentItem']['keyart']['uri']},
                'info': info,
            })

        return items

    def search(self, params):
        last_search = self._addon.data.get('last_search', '')

        query = self._view.get_input("Search", default=last_search)
        if not query:
            raise InputError()

        self._addon.data['last_search'] = query

        def get_items():
            data = self._api.search(query)['data']['search']['components'][0]
            return self._parse_shows(data['tiles'])

        items = self._addon.cache.function('search_{}'.format(query), get_items, expires=config.SHOWS_CACHE)
        self._view.items(items, title='Search')

    def login(self, params):
        self._do_login()
        self._view.refresh()

    def logout(self, params):
        if not self._view.dialog_yes_no("Are you sure you want to logout?"):
            return

        self._api.logout()
        self._view.refresh()

    def _do_login(self):
        username = self._view.get_input("Lightbox Email", default=self._addon.data.get('username', '')).strip()
        if not username:
            raise InputError()

        password = self._view.get_input("Lightbox Password", hidden=True).strip()
        if not password:
            raise InputError()

        self._addon.data['username'] = username
        self._api.login(username, password)
    
    def play(self, params):
        if not self._api.logged_in:
            self._do_login()

        try:
            data = self._api.playback_auth(params.get('id'))
            referenceID = data['data']['playbackAuth']['videos'][0]['referenceId']
            jwt_token   = data['data']['playbackAuth']['videos'][0]['token']

            item = self._api.get_brightcove_src(referenceID, jwt_token)
            item['options'] = {'headers': config.HEADERS}
        except:
            raise ViewError('Error playing that episode.\nCheck your Lightbox subscription is valid.')
        else:
            self._view.play(item)