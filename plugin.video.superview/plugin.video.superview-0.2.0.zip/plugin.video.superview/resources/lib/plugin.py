from matthuisman import plugin, gui, cache, userdata, signals

from .api import API
from .language import _
from .constants import RACES_CACHE_KEY

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not plugin.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login))
    else:
        folder.add_item(label=_(_.RACES, _bold=True),  path=plugin.url_for(races), cache_key=RACES_CACHE_KEY)
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout))

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
@plugin.login_required()
def races():
    folder = plugin.Folder(title=_.RACES)

    for slug, _race in api.races().iteritems():
        folder.add_item(
            label     = _race['title'],
            path      = plugin.url_for(race, slug=slug, refresh=int(len(_race['streams']) == 0)),
            cache_key = RACES_CACHE_KEY,
        )

    return folder

@plugin.route()
@plugin.login_required()
def race(slug, refresh=0):
    races = api.races(_skip_cache=int(refresh))
    if slug not in races:
        raise Exception(_.RACE_NOT_FOUND)

    race = races[slug]
    folder = plugin.Folder(title=race['title'])

    for stream in race['streams']:
        folder.add_item(
            label = stream['label'],
            path  = plugin.url_for(play, slug=stream['slug']),
            playable = True,
        )

    if not folder.items:
        folder.add_item(
            label = _(_.NO_STREAMS, _label=True),
            is_folder = False,
        )

    return folder

@plugin.route()
@plugin.login_required()
def play(slug):
    return api.play(slug)

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD, default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        store_pass = gui.yes_no(_.STORE_PASSWORD, heading=_.STORE_PASSWORD_HEADING)

        if api.login(username=username, password=password, store_pass=store_pass):
            gui.refresh()
        else:
            gui.ok(_.LOGIN_ERROR)

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()