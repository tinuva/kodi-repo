import time
from collections import OrderedDict

from bs4 import BeautifulSoup

from matthuisman import util, cache, userdata
from matthuisman.session import Session

from .constants import HEADERS, BASE_URL, RACES_CACHE_KEY, RACES_CACHE_EXPIRY, BRIGHTCOVE_URL, BRIGHTCOVE_KEY, BRIGHTCOVE_ACCOUNT, COOKIE_EXPIRY, PASSWORD_KEY
from .language import _

class API(object):
    def __init__(self):
        self.new_session()

    def new_session(self):
        self._logged_in = False
        self._session = Session(HEADERS, base_url=BASE_URL)
        if self._session.cookies:
            self._logged_in = True

    @property
    def logged_in(self):
        return self._logged_in

    def _check_session(self):
        if time.time() > userdata.get('expires', 0):
            if not self.login(userdata.get('username'), userdata.get(PASSWORD_KEY), store_pass=True):
                raise Exception(_.SESSION_EXPIRED)

    @cache.cached(RACES_CACHE_EXPIRY, key=RACES_CACHE_KEY)
    def races(self):
        self._check_session()

        races = OrderedDict()

        r = self._session.get('superview-videos/')

        split = r.text.split('Full Race Replays')
        upcoming = BeautifulSoup(split[0], 'html.parser')
        replays  = BeautifulSoup(split[1], 'html.parser')

        for elem in upcoming.find_all('span', {'class': 'resultsummary-tabletitle-inner'}):
            race = self._process_race(elem, upcoming=True)
            races[race['slug']] = race

        for elem in reversed(replays.find_all('span', {'class': 'resultsummary-tabletitle-inner'})):
            race = self._process_race(elem)
            if race['slug'] not in races:
                races[race['slug']] = race

        return races

    def _process_race(self, elem, upcoming=False):
        race = {
            'title': elem.get_text(),
            'streams': [],
            'upcoming': upcoming,
        }

        race['slug'] = race['title'].lower().strip().replace(' ', '-')

        rows = elem.parent.find_next_sibling('div', {'class': 'resultsummary-table-wrapper'}).find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) < 5:
                continue

            elem = cells[4].find('a')
            
            try:
                slug = elem.attrs['href'].rstrip('/').split('/')[-1]
                live = 'live' in elem.text.lower()
            except:
                slug = None
                live = False

            stream = {
                'label': cells[0].get_text(),
                'date':  cells[1].get_text(),
                'start': cells[2].get_text(),
                'end':   cells[3].get_text(),
                'slug':  slug,
                'live':  live,
            }

            race['streams'].append(stream)

        return race

    def login(self, username, password, store_pass=False):
        self.logout()
        
        if not password:
            return False

        r = self._session.get('superview/')
        soup = BeautifulSoup(r.text, 'html.parser')

        login_form = soup.find(id="membersignin")
        inputs = login_form.find_all('input')

        data = {}
        for elem in inputs:
            if elem.attrs.get('value'):
                data[elem.attrs['name']] = elem.attrs['value']

        data.update({
            'signinusername': username,
            'signinpassword': password,
        })

        r = self._session.post('superview/', data=data, allow_redirects=False)
        if r.status_code != 302:
            return False

        expires = int(time.time()) + COOKIE_EXPIRY
        userdata.set('expires', expires)

        if store_pass:
            userdata.set(PASSWORD_KEY, password)

        self._session.save_cookies()
        self._logged_in = True
        
        return True

    def logout(self):
        userdata.delete('expires')
        userdata.delete(PASSWORD_KEY)
        self._session.clear_cookies()
        self._logged_in = False

    def play(self, slug):
        self._check_session()

        r = self._session.get('superviews/{}/'.format(slug))
        soup = BeautifulSoup(r.text, 'html.parser')

        bc_div = soup.find("div", {"class": "BrightcoveExperience"})
        bc_data = bc_div.find('video')

        #bc_accont = bc_data.attrs['data-account']
        referenceID = bc_data.attrs['data-video-id']

        return self.get_brightcove_src(referenceID)

    def get_brightcove_src(self, referenceID):
        brightcove_url = BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, referenceID)
        data = self._session.get(brightcove_url, headers={'BCOV-POLICY': BRIGHTCOVE_KEY}).json()
        return util.process_brightcove(data)