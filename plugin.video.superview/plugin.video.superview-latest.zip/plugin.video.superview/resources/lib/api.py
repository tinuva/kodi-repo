from collections import OrderedDict

from bs4 import BeautifulSoup

from matthuisman import util, cache
from matthuisman.session import Session

from .constants import HEADERS, BASE_URL, RACES_CACHE_KEY, RACES_CACHE_EXPIRY, BRIGHTCOVE_URL, BRIGHTCOVE_KEY, BRIGHTCOVE_ACCOUNT

class API(object):
    def __init__(self):
        self.new_session()

    def new_session(self):
        self._logged_in = False
        self._session = Session(HEADERS, base_url=BASE_URL)
        if self._session.cookies:
            self._logged_in = True

    @property
    def logged_in(self):
        return self._logged_in


    @cache.cached(RACES_CACHE_EXPIRY, key=RACES_CACHE_KEY)
    def races(self):
        items = OrderedDict()

        r = self._session.get('superview-videos/')

        split = r.text.split('Full Race Replays')
        upcoming = BeautifulSoup(split[0], 'html.parser')
        replays  = BeautifulSoup(split[1], 'html.parser')

        elems        = upcoming.find_all('span', {'class': 'resultsummary-tabletitle-inner'})
        replay_elems = replays.find_all('span', {'class': 'resultsummary-tabletitle-inner'})
        elems.extend(reversed(replay_elems))

        for elem in elems:
            race = self._process_race(elem)
            items[race['slug']] = race

        return items

    def _process_race(self, elem):
        race = {
            'title': elem.get_text(),
            'streams': [],
        }

        race['slug'] = race['title'].lower().strip().replace(' ', '-')

        rows = elem.parent.find_next_sibling('div', {'class': 'resultsummary-table-wrapper'}).find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) < 5:
                continue

            stream = {
                'label': cells[0].get_text(),
                'date':  cells[1].get_text(),
                'start': cells[2].get_text(),
                'end':   cells[3].get_text(),
                'slug':  cells[4].find('a').attrs['href'].rstrip('/').split('/')[-1],
            }

            race['streams'].append(stream)

        return race

    def login(self, username, password):
        r = self._session.get('superview/')
        soup = BeautifulSoup(r.text, 'html.parser')

        login_form = soup.find(id="membersignin")
        inputs = login_form.find_all('input')

        data = {}
        for elem in inputs:
            if elem.attrs.get('value'):
                data[elem.attrs['name']] = elem.attrs['value']

        data.update({
            'signinusername': username,
            'signinpassword': password,
        })

        r = self._session.post('superview/', data=data, allow_redirects=False)
        if r.status_code != 302:
            return False

        self._session.save_cookies()
        self.new_session()
        
        return True

    def logout(self):
        self._session.clear_cookies()
        self.new_session()

    def play(self, slug):
        r = self._session.get('superviews/{}/'.format(slug))
        soup = BeautifulSoup(r.text, 'html.parser')

        bc_div = soup.find("div", {"class": "BrightcoveExperience"})
        bc_data = bc_div.find('video')

        #bc_accont = bc_data.attrs['data-account']
        referenceID = bc_data.attrs['data-video-id']

        return self.get_brightcove_src(referenceID)

    def get_brightcove_src(self, referenceID):
        brightcove_url = BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, referenceID)
        data = self._session.get(brightcove_url, headers={'BCOV-POLICY': BRIGHTCOVE_KEY}).json()
        return util.process_brightcove(data)