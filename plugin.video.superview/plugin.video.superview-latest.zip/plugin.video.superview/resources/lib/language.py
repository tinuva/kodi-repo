from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME   = 30000
    ASK_PASSWORD   = 30001
    RACES          = 30002
    RACE_NOT_FOUND = 30003
    NO_STREAMS     = 30004

_ = Language()