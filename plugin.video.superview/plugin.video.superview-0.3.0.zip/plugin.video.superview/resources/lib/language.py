from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME            = 30000
    ASK_PASSWORD            = 30001
    RACES                   = 30002
    RACE_NOT_FOUND          = 30003
    NO_STREAMS              = 30004
    SESSION_EXPIRED         = 30005
    STORE_PASSWORD_HEADING  = 30006
    STORE_PASSWORD          = 30007

_ = Language()