from datetime import datetime
import time
import xbmc, xbmcaddon, xbmcgui

__addon__        = xbmcaddon.Addon()
__addonid__      = __addon__.getAddonInfo('id').decode( 'utf-8' )
__addonname__    = __addon__.getAddonInfo('name').decode("utf-8")

POLL_TIME = 60 #seconds

class MyMonitor(xbmc.Monitor):
    def __init__(self, onSettingsChanged):
        self._onSettingsChanged = onSettingsChanged
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        self._onSettingsChanged()

class Main(object):
    def __init__(self):
        self.load_settings()
        self.prev_kodi_time = None
        self.monitor = MyMonitor(onSettingsChanged=self.load_settings)

    def get_kodi_epoch(self):
        kodi_date = xbmc.getInfoLabel('System.Date(dd-mm-yy)').strip()
        kodi_time = xbmc.getInfoLabel('System.Time(hh:mm:ss xx)').strip()
        date_string = "{0} {1}".format(kodi_date, kodi_time)

        if date_string.lower().endswith('m'):
            _format = '%d-%m-%y %I:%M:%S %p'
        else:
            _format = '%d-%m-%y %H:%M:%S'

        kodi_time = datetime(*(time.strptime(date_string, _format)[0:6]))

        return int((kodi_time - datetime(1970,1,1)).total_seconds())

    def callback(self):
        if self.silent == 'false':
            dialog = xbmcgui.Dialog()
            dialog.notification(__addonname__, 'Executing %s' % self.function, xbmcgui.NOTIFICATION_INFO, 2000)
        time.sleep(0.5)
        xbmc.executebuiltin(self.function)

    def start(self):
        while not self.monitor.abortRequested():
            if self.monitor.waitForAbort(POLL_TIME):
                break

            kodi_time = self.get_kodi_epoch()
            if not self.prev_kodi_time:
                self.prev_kodi_time = kodi_time
                continue

            diff = kodi_time - self.prev_kodi_time
            if diff > (POLL_TIME + 30) or diff < 0:
                self.callback()

            self.prev_kodi_time = kodi_time

    def load_settings(self):
        settings = xbmcaddon.Addon()
        self.function = settings.getSetting("function").strip()
        self.silent = settings.getSetting("silent").strip()

if __name__ == '__main__':
    Main().start()