import time
from datetime import datetime

import xbmc

from matthuisman import gui, settings
from matthuisman.log import log

from .constants import POLL_TIME
from .language import _

def get_kodi_epoch():
    kodi_date = xbmc.getInfoLabel('System.Date(dd-mm-yy)').strip()
    kodi_time = xbmc.getInfoLabel('System.Time(hh:mm:ss xx)').strip()
    date_string = "{0} {1}".format(kodi_date, kodi_time)

    if date_string.lower().endswith('m'):
        _format = '%d-%m-%y %I:%M:%S %p'
    else:
        _format = '%d-%m-%y %H:%M:%S'

    kodi_time = datetime(*(time.strptime(date_string, _format)[0:6]))

    return int((kodi_time - datetime(1970,1,1)).total_seconds())

def callback():
    function = settings.get('function')

    if not settings.getBool('silent', False):
        gui.notification(_(_.RUN_FUNCTION, function=function))

    log.debug('Running function: {}'.format(function))
    xbmc.executebuiltin(function)

def service():
    monitor = xbmc.Monitor()

    prev_kodi_time = None

    while not monitor.abortRequested():
        if monitor.waitForAbort(POLL_TIME):
            break
        
        kodi_time = get_kodi_epoch()        
        if not prev_kodi_time:
            prev_kodi_time = kodi_time
            continue

        diff = kodi_time - prev_kodi_time
        if diff > (POLL_TIME + 30) or diff < 0:
            callback()

        prev_kodi_time = kodi_time