# plugin.video.skygo

Unofficial 3rd Party Sky Go plugin for Kodi.
