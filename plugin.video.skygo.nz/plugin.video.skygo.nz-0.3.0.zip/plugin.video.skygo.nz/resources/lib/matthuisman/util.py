import time
import hashlib
from datetime import datetime

import xbmc

from .constants import ADDON
from .log import log

def hash_6(value, default=None):
    if not value:
        return default

    h = hashlib.md5(str(value))
    return h.digest().encode('base64')[:6]

def kodi_version():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split('.')[0])
    except:
        return 0

def strptime(date, str_format):
    try:
        return datetime.strptime(date, str_format)
    except TypeError:
        return datetime(*(time.strptime(date, str_format)[0:6]))

def process_brightcove(program_data):
    try:
        error = program_data[0]['error_code']
    except:
        error = None

    if error:
        raise Exception('Brightcove returned the following error: {0}'.format(error))

    videos = []
    for source in program_data['sources']:
        if not source.get('src'):
            continue

        print(source)

        if source.get('container') == 'MP4':
            videos.append({
                'url': source['src'], 
                '_sort': source.get('avg_bitrate', source.get('height')),
            })
        elif 'key_systems' in source and 'com.widevine.alpha' in source['key_systems']:
            videos.append({
                'url': source['src'],
                'vid_type': 'widevine', 
                'vid_key': source['key_systems']['com.widevine.alpha']['license_url'],
            })

    if videos:
        videos = sorted(videos, key=lambda x: x.get('_sort'), reverse=True)
        video = videos[0]
        video.pop('_sort', None)
        return video

    raise Exception('Could not find a source from brightcove')

def get_string(id, bold=False, label=False, **kwargs):
    string = ADDON.getLocalizedString(id)
    if not string:
        log.warning("LANGUAGE: Addon didn't return a string for id: {}".format(id))
        return str(id)

    string = string.format(**kwargs)

    if label:
        bold = True
        string = '~ {} ~'.format(string)

    if bold:
        string = '[B]{}[/B]'.format(string)
        
    return string