# plugin.video.skygo

Unofficial 3rd Party Sky Go plugin for Kodi.

https://www.matthuisman.nz/2018/08/sky-go-kodi-add-on.html
