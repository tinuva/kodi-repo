import os, platform, re, shutil
import xbmc, xbmcaddon

from . import gui
from .constants import IA_SSD, IA_CDM, IA_PLATFORMS, IA_URL, IA_ADDON_ID, IA_VERSION_KEY, IA_HLS_MIN_VER
from .session import Session
from .util import kodi_version, get_string as _

L_NOT_FOUND        = 32008
L_UWP_ERROR        = 32009
L_KODI18_REQUIRED  = 32010
L_AARCH64_ERROR    = 32011
L_NOT_SUPPORTED    = 32012
L_KODI17_REQUIRED  = 32013
L_DOWNLOADING_FILE = 32014
L_WIDEVINE_DRM     = 32015
L_ERROR_INSTALLING = 32016

class InputstreamItem(object):
    manifest_type = ''
    license_type  = ''
    license_key   = ''
    mimetype      = ''

    def check(self):
        return False

class HLS(InputstreamItem):
    manifest_type = 'hls'
    mimetype      = 'application/vnd.apple.mpegurl'

    def check(self):
        return supports_hls()

class Widevine(InputstreamItem):
    manifest_type = 'mpd'
    license_type  = 'com.widevine.alpha'
    mimetype      = 'application/dash+xml'

    def __init__(self, license_key=None):
        self.license_key = license_key

    def check(self):
        return supports_widevine()

class Error(Exception):
    pass

class Config(object):
    addon = None
    supports_hls = False
    supports_widevine = False

config = Config()

def get_addon():
    if config.addon:
        return config.addon

    try:
        xbmc.executebuiltin('InstallAddon({})'.format(IA_ADDON_ID), True)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format(IA_ADDON_ID))
        config.addon = xbmcaddon.Addon(IA_ADDON_ID)
    except:
        config.addon = None

    return config.addon
    
def open_settings():
    addon = get_addon()
    if not addon:
        raise Error(_(L_NOT_FOUND))
        
    addon.openSettings()

def supports_hls():
    if config.supports_hls:
        return True

    addon = get_addon()
    config.supports_hls = bool(addon and int(addon.getAddonInfo('version')[0]) >= IA_HLS_MIN_VER)
    return config.supports_hls

def supports_widevine():
    if config.supports_widevine:
        return True

    addon = get_addon()
    if not addon:
        raise Error(_(L_NOT_FOUND))

    installer = WidevineInstaller(addon)
    installer.check()
    if not installer.installed:
        installer.install()

    config.supports_widevine = True
    return True

class WidevineInstaller(object):
    def __init__(self, addon):
        self._addon        = addon
        self._decryptpath  = xbmc.translatePath(self._addon.getSetting('DECRYPTERPATH')).decode("utf-8")
        self._path         = xbmc.translatePath(self._addon.getAddonInfo('path')).decode("utf-8")
        self._version      = int(self._addon.getAddonInfo('version')[0])
        self._kodi_version = kodi_version()
        self._installed    = addon.getSetting(IA_VERSION_KEY)
        
        self._get_system_arch()
        self._ver_slug     = self._system + self._arch + str(self._version)

    def check(self):
        error = None

        if self._system == 'UWP':
            error = _(L_UWP_ERROR)
            
        elif self._system == 'Android':
            if self._kodi_version < 18:
                raise Error(_(L_KODI18_REQUIRED, system=self._system))

        elif 'aarch64' in self._arch:
            raise Error(_(L_AARCH64_ERROR))

        # elif self._system == 'Linux':
        #     if self._kodi_version < 18 and self._arch in ['x86_64', 'i386']:
        #         raise Error(_(L_KODI18_REQUIRED, system=self._system))

        elif self._system == 'Windows':
            if self._kodi_version < 18:
                raise Error(_(L_KODI18_REQUIRED, system=self._system))

        elif self._system + self._arch not in IA_PLATFORMS:
            raise Error(_(L_NOT_SUPPORTED, system=self._system, arch=self._arch, kodi_version=self._kodi_version))

        elif self._kodi_version < 17:
            raise Error(_(L_KODI17_REQUIRED))

    @property
    def installed(self):
        return bool(self._ver_slug == self._addon.getSetting(IA_VERSION_KEY) and self._has_ssd_wv() and self._has_widevinecdm())

    def install(self):
        try:
            if not os.path.isdir(self._decryptpath):
                os.makedirs(self._decryptpath)

            self._install_widevinecdm()
            self._install_ssd_wv()
        except:
            raise Error(_(L_ERROR_INSTALLING))
        else:
            self._addon.setSetting(IA_VERSION_KEY, self._ver_slug)

    def _get_system_arch(self):
        self._system = platform.system()
        self._arch = platform.machine()

        if self._system == 'Windows':
            self._arch = platform.architecture()[0]

        elif 'armv' in self._arch:
            arm_version = re.search('\d+', self._arch.split('v')[1])
            if arm_version:
                self._arch = 'armv' + arm_version.group()

        elif self._arch == 'arm':
            self._arch = 'armv8'

        elif self._arch == 'i686':
            self._arch = 'i386'

        if self._system == 'Linux' and xbmc.getCondVisibility('system.platform.android'):
            self._system = 'Android'

        if 'WindowsApps' in xbmc.translatePath('special://xbmcbin/'):
            self._system = 'UWP'

    def _has_ssd_wv(self):
        return os.path.exists(os.path.join(self._decryptpath, IA_SSD[self._system]))

    def _has_widevinecdm(self):
        return os.path.exists(os.path.join(self._decryptpath, IA_CDM[self._system]))

    def _install_widevinecdm(self):
        filename = IA_CDM[self._system]

        dst_path = os.path.join(self._decryptpath, filename)
        url      = IA_URL.format(self._system, self._arch, filename)

        self._progress_download(url, dst_path, filename)
        os.chmod(dst_path, 0755)

    def _install_ssd_wv(self):
        filename = IA_SSD[self._system]

        dst_path = os.path.join(self._decryptpath, filename)

        paths = [os.path.join(self._path, filename), os.path.join(self._path, 'lib', filename), os.path.join(os.sep, 'usr', 'lib', filename)]
        for path in paths:
            if os.path.exists(path):
                try:
                    self._remove_file(dst_path)
                    shutil.copy(path, dst_path)
                    os.chmod(dst_path, 0755)
                    return
                except:
                    continue

        url = IA_URL.format(self._system, self._arch, filename)
        self._progress_download(url, dst_path, filename)

        os.chmod(dst_path, 0755)
        
    def _progress_download(self, url, dst_path, filename):
        resp = Session().get(url, stream=True)
        resp.raise_for_status()

        total_length = float(resp.headers.get('content-length'))

        with gui.progress(_(L_DOWNLOADING_FILE, url=url), heading=_(L_WIDEVINE_DRM)) as progress:
            self._remove_file(dst_path)

            with open(dst_path, 'wb') as f:
                chunk_size = 1024
                downloaded = 0
                for chunk in resp.iter_content(chunk_size=chunk_size):
                    f.write(chunk)
                    downloaded += len(chunk)
                    percent = int(downloaded*100/total_length)

                    if progress.iscanceled():
                        progress.close()
                        resp.close()

                    progress.update(percent)

    def _remove_file(self, file_path):
        if os.path.islink(file_path):
            os.unlink(file_path)
        elif os.path.exists(file_path):
            os.remove(file_path)