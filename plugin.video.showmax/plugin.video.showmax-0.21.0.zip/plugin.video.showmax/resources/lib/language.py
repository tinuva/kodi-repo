from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    LOGIN             = 30000
    LOGOUT            = 30002
    SETTINGS          = 30003
    ASK_USERNAME      = 30004
    ASK_PASSWORD      = 30005
    LOGIN_ERROR       = 30006
    LOGOUT_YES_NO     = 30007
    SERIES            = 30008
    MOVIES            = 30009
    KIDS              = 30010
    SEASON_NUMBER     = 30011
    EPISODE_NUMBER    = 30012
    SEARCH            = 30013
    SEARCH_FOR        = 30014
    NO_RESULTS        = 30015
    COM_LANGUAGE      = 30016
    LANG_ENG          = 30017
    LANG_POL          = 30018
    LANG_AFR          = 30019
    
    LANG_CHOOSE       = 30021
    SELECT_LANG       = 30024

_ = Language()