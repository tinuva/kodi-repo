from time import time
from functools import wraps

from . import peewee, database, userdata
from .constants import CACHE_TABLENAME, CACHE_EXPIRY, CACHE_CHECKSUM, CACHE_CLEAN_INTERVAL, CACHE_CLEAN_KEY
from .util import hash_6
from .log import log

enabled = True
funcs   = []

class Cache(database.Model):
    checksum = CACHE_CHECKSUM

    key     = database.HashField(unique=True)
    value   = database.PickledField()
    expires = peewee.IntegerField()

    class Meta:
        table_name = CACHE_TABLENAME

def key_for(f, *args, **kwargs):
    func_name = f.__name__ if callable(f) else f
    if not enabled or func_name not in funcs:
        return None

    return _build_key(func_name, *args, **kwargs)

def _build_key(func_name, *args, **kwargs):
    key = func_name
    
    for k in sorted(args):
        key += str(k)

    for k in sorted(kwargs):
        key += str(k) + str(kwargs[k])

    return hash_6(key)

def cached(*args, **kwargs):
    def decorator(f, expires=CACHE_EXPIRY, key=None):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            _key = key or _build_key(f.__name__, *args, **kwargs)

            value = get(_key)
            if value != None:
                log('Cache Hit: {}'.format(_key))
                return value

            value = f(*args, **kwargs)
            set(_key, value, expires)

            return value

        funcs.append(f.__name__)
        return decorated_function

    return lambda f: decorator(f, *args, **kwargs)

def get(key, default=None):
    if not enabled:
        return default

    try:
        return Cache.get(Cache.key == key, Cache.expires > time()).value
    except Cache.DoesNotExist:
        return default

def set(key, value, expires=CACHE_EXPIRY):
    expires = int(time() + expires)
    Cache.set(key=key, value=value, expires=expires)

def delete(key):
    return Cache.delete(Cache.key == key)

def remove_expired():
    _time = int(time())
    if _time - userdata.get(CACHE_CLEAN_KEY, 0) > CACHE_CLEAN_INTERVAL:
        deleted = Cache.delete(Cache.expires < _time)
        userdata.set(CACHE_CLEAN_KEY, _time)
        log.info('Cache: Deleted {} Expired Rows'.format(deleted))

database.check_table(Cache)
remove_expired()