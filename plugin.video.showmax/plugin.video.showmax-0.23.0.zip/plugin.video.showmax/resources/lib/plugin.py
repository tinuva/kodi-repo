from matthuisman import plugin, gui, cache, settings, userdata, inputstream, signals
from matthuisman.log import log

from .api import API
from .constants import LIST_EXPIRY, EPISODE_EXPIRY, THUMB_HEIGHT, FANART_HEIGHT, AUDIO_LANGS, SUBS_LANGS
from .language import _

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not plugin.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login))
    else:
        folder.add_item(label=_(_.SERIES, _bold=True),  path=plugin.url_for(series),  cache_key=cache.key_for(series))
        folder.add_item(label=_(_.MOVIES, _bold=True),  path=plugin.url_for(movies),  cache_key=cache.key_for(movies))
        folder.add_item(label=_(_.KIDS, _bold=True),    path=plugin.url_for(kids),    cache_key=cache.key_for(kids))
        folder.add_item(label=_(_.SEARCH, _bold=True),  path=plugin.url_for(search),  cache_key=cache.key_for(search))

        folder.add_item(label=_.LOGOUT,  path=plugin.url_for(logout))

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
@cache.cached(LIST_EXPIRY)
def series():
    folder = plugin.Folder(title=_.SERIES)
    rows = api.series()
    folder.add_items(_parse_series(rows))
    return folder

@plugin.route()
@cache.cached(LIST_EXPIRY)
def movies():
    folder = plugin.Folder(title=_.MOVIES)
    rows = api.movies()
    folder.add_items(_parse_movies(rows))
    return folder

@plugin.route()
@cache.cached(LIST_EXPIRY)
def kids():
    folder = plugin.Folder(title=_.KIDS)
    rows = api.kids()
    folder.add_items(_parse_series(rows))
    return folder

@plugin.route()
def search():
    query = gui.input(_.SEARCH, default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    @cache.cached(LIST_EXPIRY)
    def get_results(query):
        folder = plugin.Folder(title=_(_.SEARCH_FOR, query=query))
        rows = api.search(query)
        folder.add_items(_parse_rows(rows))

        if not folder.items:
            folder.add_item(
                label     = _(_.NO_RESULTS, _label=True),
                is_folder = False,
            )

        return folder

    return get_results(query)

@plugin.route()
@cache.cached(LIST_EXPIRY)
def seasons(series_id):
    data   = api.seasons(series_id)
    art    = _get_art(data['images'])
    rows   = data['seasons']

    folder = plugin.Folder(title=data['title'])
    folder.add_items(_parse_seasons(rows, data['title'], art))

    return folder

@plugin.route()
@cache.cached(EPISODE_EXPIRY)
def episodes(season_id):
    data   = api.episodes(season_id)
    art    = _get_art(data['images'])
    rows   = data['episodes']

    folder = plugin.Folder(title=data['tv_series']['title'])
    folder.add_items(_parse_episodes(rows, data['tv_series']['title'], data['number'], art))

    return folder

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD).strip()
        if not password:
            break

        if api.login(username=username, password=password):
            gui.refresh()
        else:
            gui.ok(_.LOGIN_ERROR)

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()

@plugin.route()
@plugin.login_required()
def play_trailer(asset_id):
    row = api.asset(asset_id)
    videos = _get_videos(row)
    return _play_videos(videos['trailer'])

@plugin.route()
@plugin.login_required()
def play(asset_id):
    row = api.asset(asset_id)
    videos = _get_videos(row)
    return _play_videos(videos['main'])
    
def _play_videos(videos):
    if not videos:
        raise Exception('No videos found')

    default_audio = AUDIO_LANGS[settings.getInt('audio_lang')]
    default_sub   = SUBS_LANGS[settings.getInt('subs_lang')]

    chosen  = None
    options = []

    if len(videos) == 1:
        chosen = videos[0]
    else:
        videos = sorted(videos, key=lambda x: x['language'])

        for video in videos:
            try:
                lang_label = getattr(_, 'LANG_{}'.format(video['language'].upper()))
            except AttributeError:
                lang_label = video['language'].upper()

            options.append(lang_label)

            if video['language'].lower() == default_audio:
                chosen = video
                break

        if not chosen:
            index = gui.select(_.SELECT_LANG, options)
            if index < 0:
                return

            chosen = videos[index]

    url, license_url = api.play(chosen['id'])
    item = plugin.Item(inputstream=inputstream.Widevine(license_url), path=url, art=False)

    chosen_srts = []
    all_srts = []
    for row in chosen.get('subtitles', []):
        if row['type'] == 'forced':
            row['filename'] = '{}.forced.srt'.format(row['language'])
        else:
            row['filename'] = '{}.srt'.format(row['language'])

        if row['language'].lower() == default_sub:
            chosen_srts.append(row)

        all_srts.append(row)

    if not chosen_srts:
        chosen_srts = all_srts

    for row in chosen_srts:
        srtfile = api.get_subtitle(row['filename'], chosen['id'], row['id'])
        if srtfile:
            item.subtitles.append(srtfile)

    return item

def _parse_series(rows):
    items = []

    for row in rows:
        videos = _get_videos(row.get('videos', []))

        item = plugin.Item(
            label     = row['title'],
            info      = {'sorttitle': row['title'], 'plot': row['description'], 'mediatype': 'tvshow', 'tvshowtitle': row['title']},
            art       = _get_art(row.get('images', [])),
            is_folder = True,
            path      = plugin.url_for(seasons, series_id=row['id']),
            cache_key = cache.key_for(seasons, series_id=row['id']),
        )

        if videos['trailer']:
            item.info['trailer'] = plugin.url_for(play_trailer, asset_id=row['id'])

        items.append(item)

    return items

def _parse_seasons(rows, series_title, series_art):
    items = []

    for row in rows:
        item = plugin.Item(
            label     = _(_.SEASON_NUMBER, season_number=row['number']),
            info      = {'plot': row['description'], 'tvshowtitle': series_title, 'mediatype': 'season', 'season': row['number']},
            art       = _get_art(row.get('images', []), series_art),
            is_folder = True,
            path      = plugin.url_for(episodes, season_id=row['id']),
            cache_key = cache.key_for(episodes, season_id=row['id']),
        )

        items.append(item)

    return items

def _parse_episodes(rows, series_title, season, season_art):
    items = []

    for row in rows:
        videos = _get_videos(row.get('videos', []))

        item = plugin.Item(
            label     = row['title'] or _(_.EPISODE_NUMBER, episode_number=row['number']),
            info      = {'plot': row['description'], 'tvshowtitle': series_title, 'season': season, 'episode': row['number'], 'mediatype': 'episode'},
            art       = _get_art(row.get('images', []), season_art),
            is_folder = False,
        )

        if videos['main']:
            item.info.update({
                'duration':  int(videos['main'][0]['duration']),
                'mediatype': 'episode',
            })

            item.video    = {'height': videos['main'][0]['height'], 'width': videos['main'][0]['width'], 'codec': 'h264'}
            item.path     = plugin.url_for(play, asset_id=row['id'])
            item.playable = True

        items.append(item)

    return items

def _parse_movies(rows):
    items = []

    for row in rows:
        videos = _get_videos(row.get('videos', []))

        item = plugin.Item(
            label     = row['title'],
            info      = {'plot': row['description']},
            art       = _get_art(row.get('images', [])),
            is_folder = False,
        )

        if videos['main']:
            item.info.update({
                'duration':  int(videos['main'][0]['duration']),
                'mediatype': 'movie',
            })

            item.video    = {'height': videos['main'][0]['height'], 'width': videos['main'][0]['width'], 'codec': 'h264'}
            item.path     = plugin.url_for(play, asset_id=row['id'])
            item.playable = True

        if videos['trailer']:
            item.info['trailer'] = plugin.url_for(play_trailer, asset_id=row['id'])

        items.append(item)

    return items

def _parse_rows(rows):
    items = []

    for row in rows:
        if row['type'] == 'movie':
            items.extend(_parse_movies([row]))
        elif row['type'] == 'tv_series':
            items.extend(_parse_series([row]))

    return items

def _get_videos(videos):
    vids = {'main': [], 'trailer': []}

    for video in videos:
        if video['usage'] == 'main':
            vids['main'].append(video)
        elif video['usage'] == 'trailer':
            vids['trailer'].append(video)

    return vids

def _get_art(images, default_art=None):
    art = {}
    default_art = default_art or {}

    for image in images:
        if image['type'] == 'poster':
            if image['orientation'] == 'square' or 'thumb' not in art:
                art['thumb'] = image['link'] + '/x{}'.format(THUMB_HEIGHT)
        elif image['type'] == 'background':
            art['fanart'] = image['link'] + '/x{}'.format(FANART_HEIGHT)
        elif image['type'] == 'hero' and 'fanart' not in art:
            art['fanart'] = image['link'] + '/x{}'.format(FANART_HEIGHT)
        elif image['type'] == 'poster' and image['orientation'] == 'portrait':
            art['poster'] = image['link'] + '/x{}'.format(THUMB_HEIGHT)

    for key in default_art:
        if key not in art:
            art[key] = default_art[key]

    return art