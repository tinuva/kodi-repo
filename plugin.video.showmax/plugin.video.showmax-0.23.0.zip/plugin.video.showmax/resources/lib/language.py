from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME      = 30000
    ASK_PASSWORD      = 30001
    SERIES            = 30002
    MOVIES            = 30003
    KIDS              = 30004
    SEASON_NUMBER     = 30005
    EPISODE_NUMBER    = 30006
    COM_LANGUAGE      = 30007
    LANG_ENG          = 30008
    LANG_POL          = 30009
    LANG_AFR          = 30010
    LANG_CHOOSE       = 30011
    AUDIO_LANGUAGE    = 30012
    SUBS_LANGUAGE     = 30013
    SELECT_LANG       = 30014
    LANG_ZUL          = 30015
    LANG_TSN          = 30016

_ = Language()