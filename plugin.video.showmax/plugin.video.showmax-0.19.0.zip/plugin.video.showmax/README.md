# plugin.video.showmax

Unofficial 3rd Party Showmax plugin for Kodi.

https://www.matthuisman.nz/2018/08/showmax-kodi-add-on.html
