import hashlib
import codecs
from bs4 import BeautifulSoup

import xbmc

from matthuisman import userdata, cache, plugin, settings
from matthuisman.session import Session
from matthuisman.log import log

from .constants import HEADERS, API_URL, LOGIN_URL, LANGUAGE_EXPIRY, COMM_LANGS, SUBTITLE_EXPIRY

class API(object):
    def new_session(self):
        self._logged_in = False
        self._language  = COMM_LANGS[settings.getInt('comm_lang')]
        self._session   = Session(HEADERS, base_url=API_URL)
        self._set_access_token(userdata.get('access_token'))

    def _set_access_token(self, token):
        if token:
            self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})
            self._logged_in = True

    @property
    def logged_in(self):
        return self._logged_in
        
    def login(self, username, password):
        log('API: Login')

        data = {
            'response_type': 'token',
            'lang': self._language,
        }

        resp = self._session.get(LOGIN_URL, params=data)
        soup = BeautifulSoup(resp.text, 'html.parser')

        form = soup.find('form', id='new_signin')
        for e in form.find_all('input'):
            data[e.attrs['name']] = e.attrs.get('value')

        data.update({
            'signin[email]': username,
            'signin[password]': password,
        })

        resp = self._session.post(LOGIN_URL, data=data, allow_redirects=False)
        access_token = resp.cookies.get('showmax_oauth')
        
        if not access_token:
            self.logout()
            return False

        self._set_access_token(access_token)

        data = self._session.get('user/current', params={'lang': self._language}).json()
        if 'error_code' in data:
            return False

        device_id = hashlib.sha1(username).hexdigest().upper()

        userdata.set('device_id', device_id)
        userdata.set('access_token', access_token)
        userdata.set('user_id', data['user_id'])
        return True

    def logout(self):
        log('API: Logout')
        userdata.delete('device_id')
        userdata.delete('access_token')
        userdata.delete('user_id')
        self.new_session()

    def _catalogue(self, _params):
        def process_page(start):
            params = {
                'field[]': ['id'],
                'lang': self._language,
                'showmax_rating': 'adults',
                'sort': 'alphabet',
                'start': start,
                'subscription_status': 'full'
            }

            params.update(_params)

            data = self._session.get('catalogue/assets', params=params).json()
            items = data['items']

            count     = int(data.get('count', 0))
            remaining = int(data.get('remaining', 0))
            if count > 0 and remaining > 0:
                items.extend(process_page(start + count))

            return items

        return process_page(start=0)

    def series(self):
        return self._catalogue({
            'field[]': ['id', 'images', 'title', 'items', 'total', 'description', 'videos'],
            'type': 'tv_series',
            'exclude_section[]': ['kids'],
        })

    def movies(self):
        return self._catalogue({
            'field[]': ['id', 'images', 'title', 'items', 'total', 'description', 'videos'],
            'type': 'movie',
            'exclude_section[]': ['kids'],
        })

    def kids(self):
        return self._catalogue({
            'field[]': ['id', 'images', 'title', 'items', 'total', 'description', 'videos'],
            'section': 'kids',
        })

    def seasons(self, series_id):
        params = {
            'field[]': ['id', 'images', 'title', 'items', 'total', 'type', 'description', 'number', 'seasons'],
            'lang': self._language,
            'showmax_rating': 'adults',
            'subscription_status': 'full'
        }

        return self._session.get('catalogue/tv_series/{}'.format(series_id), params=params).json()

    def episodes(self, season_id):
        params = {
            'field[]': ['id', 'images', 'title', 'items', 'total', 'type', 'description', 'number', 'tv_series', 'episodes', 'videos'],
            'lang': self._language,
            'showmax_rating': 'adults',
            'subscription_status': 'full'
        }

        return self._session.get('catalogue/season/{}'.format(season_id), params=params).json()

    def search(self, query):
        return self._catalogue({
            'field[]': ['id', 'images', 'title', 'items', 'total', 'type', 'description', 'type', 'videos'],
            'q': query,
        })

    
    def get_subtitle(self, language, video_id, subtitle_id):
        def secondsToSRT(seconds):
            millis = int(float(seconds)*1000)
            seconds=(millis/1000)%60
            seconds = int(seconds)
            minutes=(millis/(1000*60))%60
            minutes = int(minutes)
            hours=(millis/(1000*60*60))%24
            millis = millis  % 1000
            return "%02d:%02d:%02d,%d" % (hours, minutes, seconds, millis)

        @cache.cached(SUBTITLE_EXPIRY)
        def get_srt_lines(video_id, subtitle_id):
            r = self._session.get('catalogue/subtitles/{}/{}'.format(video_id, subtitle_id))
            if r.status_code != 200:
                log.debug('Failed to download subtitle')
                return None

            soup = BeautifulSoup(r.content.decode('utf-8'))
            lines = []
            for caption in soup.findAll('p'):
                subtext = caption.encode_contents(encoding='utf-8').decode('utf-8').replace('<br/>', '\n')
                lines.append([secondsToSRT(caption['begin']), secondsToSRT(caption['end']), subtext])

            return lines

        lines = get_srt_lines(video_id, subtitle_id)
        srtfile = xbmc.translatePath('special://temp/%s.srt' % language).decode('utf-8')
        with codecs.open(srtfile, 'w', encoding='utf-8') as f:
            for num, srt in enumerate(lines):
                f.write('%s\n%s --> %s\n%s\n\n' % (num, srt[0], srt[1], srt[2]))

        return srtfile

    def asset(self, asset_id):
        params = {
            'field[]': ['videos',],
            'lang': self._language,
            'showmax_rating': 'adults',
            'subscription_status': 'full'
        }
        return self._session.get('catalogue/asset/{}'.format(asset_id), params=params).json()['videos']

    def play(self, video_id):
        params = {
            'encoding': 'mpd_widevine_modular',
            'subscription_status': 'full',
            'lang': self._language,
        }

        data = self._session.get('playback/play/{}'.format(video_id), params=params).json()

        if 'url' not in data:
            raise Exception(data.get('message'))
        
        url        = data['url']
        task_id    = data['packaging_task_id']
        session_id = data['session_id']

        data = {
            'user_id': userdata.get('user_id'),
            'video_id': video_id,
            'hw_code': userdata.get('device_id'),
            'packaging_task_id': task_id,
            'session_id': session_id,
        }

        params = {'showmax_rating': 'adults', 'lang': self._language}
        data = self._session.post('playback/verify', params=params, data=data).json()

        if 'license_request' not in data:
            raise Exception(data.get('message'))

        license_request = data['license_request']
        license_url = API_URL.format('drm/widevine_modular?license_request={}'.format(license_request))

        return url, license_url