# plugin.video.showmax

Unofficial 3rd Party Showmax plugin for Kodi.
