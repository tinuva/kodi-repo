from matthuisman import plugin, gui, cache, settings, userdata, inputstream

from .api import API
from .constants import SHOWS_CACHE_KEY, LIVE_CACHE_KEY, EPISODE_EXPIRY
from .language import _

api = API()

@plugin.route('')
def home():
    folder = plugin.Folder()

    folder.add_item(label=_(_.SHOWS, _bold=True),  path=plugin.url_for(shows),  cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(_.GENRE, _bold=True),  path=plugin.url_for(genres), cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search), cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(_.LIVE, _bold=True),   path=plugin.url_for(live),   cache_key=LIVE_CACHE_KEY)

    folder.add_item(label=_.SETTINGS,  path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def shows():
    folder = plugin.Folder(title=_.SHOWS)
    items = _parse_shows(api.shows())
    folder.add_items(items)
    return folder

@plugin.route()
def genres():
    folder = plugin.Folder(title=_.GENRE)

    for row in api.genres():
        folder.add_item(
            label = row['displayName'],
            path  = plugin.url_for(genre, genre=row['slug'], title=row['displayName']),
            art   = {'thumb': row.get('logo', None)},
        )

    return folder

@plugin.route()
def genre(genre, title):
    folder = plugin.Folder(title=title)
    items = _parse_shows(api.genre(genre))
    folder.add_items(items)
    return folder

def _parse_shows(rows):
    items = []
    for row in rows:
        thumb = row.get('images',{}).get('showTile','').split('?')[0]

        item = plugin.Item(
            label = row['name'],
            art   = {'thumb': thumb},
            path  = plugin.url_for(show, id=row['showId']),
            cache_key = cache.key_for(show, id=row['showId']),
            info = {
                'title': row['name'],
                'plot': row.get('synopsis'), 
                'mediatype': 'tvshow',
                'tvshowtitle': row['name'],
            }
        )

        items.append(item)

    if not items:
        item = plugin.Item(label=_(_.NO_RESULTS, _label=True), is_folder=False)
        items.append(item)

    return items

def _parse_episodes(rows):
    items = []
    for row in rows:
        videoid = row['videoRenditions']['videoCloud']['brightcoveId']
        thumb   = row.get('images',{}).get('videoTile','').split('?')[0]

        info = {
            'title': row['name'],
            'genre': row.get('genre'), 
            'plot': row.get('synopsis'), 
            'duration': int(row.get('duration')), 
            'aired': row.get('airedDate'),
            'mediatype': 'episode',
            'tvshowtitle': row.get('showTitle'),
        }

        try:
            info.update({
                'episode': int(row.get('episode')), 
                'season': int(row.get('season')),
            })
        except:
            pass

        item = plugin.Item(
            label = row['name'],
            art   = {'thumb': thumb},
            path  = plugin.url_for(play, id=videoid),
            info  = info,
            playable = True,
        )

        items.append(item)

    if not items:
        item = plugin.Item(label=_(_.NO_RESULTS, _label=True), is_folder=False)
        items.append(item)

    return items

@plugin.route()
@cache.cached(EPISODE_EXPIRY)
def show(id):
    row = api.show(id)
    folder = plugin.Folder(title=row['name'])
    folder.add_items(_parse_episodes(row['episodes']))
    return folder

@plugin.route()
def play(id):
    return api.get_brightcove_src(id)

@plugin.route()
def play_channel(channel):
    for row in api.live():
        if row['title'] == channel:
            return plugin.Item(
                inputstream = inputstream.HLS(), 
                path = row['videoRenditions']['videoCloud']['hlsUrl'], 
                art = False,
            )

@plugin.route()
def search():
    query = gui.input(_.SEARCH, default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    folder = plugin.Folder(title=_(_.SEARCH_FOR, query=query))
    items = _parse_shows(api.search(query))
    folder.add_items(items)

    return folder

@plugin.route()
def live():
    folder = plugin.Folder(title=_.LIVE)

    for row in api.live():
        folder.add_item(
            label = row['displayName'],
            art   = {'thumb': row.get('logo','').split('?')[0]},
            path  = plugin.url_for(play_channel, is_live=True, channel=row['title']),
            playable = True,
        )

    return folder