from matthuisman import plugin, gui, cache, settings, userdata, inputstream
from matthuisman.util import get_string as _

from .api import API
from .constants import SHOWS_CACHE_KEY, LIVE_CACHE_KEY, EPISODE_EXPIRY

L_SHOWS       = 30000
L_GENRE       = 30001
L_SEARCH      = 30002
L_LIVE        = 30003
L_SETTINGS    = 30004
L_NO_RESULTS  = 30005
L_SEARCH_FOR  = 30006

api = API()

@plugin.route('')
def home():
    folder = plugin.Folder()

    folder.add_item(label=_(L_SHOWS, bold=True),  path=plugin.url_for(shows),  cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(L_GENRE, bold=True),  path=plugin.url_for(genres), cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(L_SEARCH, bold=True), path=plugin.url_for(search), cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(L_LIVE, bold=True),   path=plugin.url_for(live),   cache_key=LIVE_CACHE_KEY)

    folder.add_item(label=_(L_SETTINGS),  path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def shows():
    folder = plugin.Folder(title=_(L_SHOWS))
    items = _parse_shows(api.shows())
    folder.add_items(items)
    return folder

@plugin.route()
def genres():
    folder = plugin.Folder(title=_(L_GENRE))

    for row in api.genres():
        folder.add_item(
            label = row['displayName'],
            path  = plugin.url_for(genre, genre=row['slug'], title=row['displayName']),
            art   = {'thumb': row.get('logo', None)},
        )

    return folder

@plugin.route()
def genre(genre, title):
    folder = plugin.Folder(title=title)
    items = _parse_shows(api.genre(genre))
    folder.add_items(items)
    return folder

def _parse_shows(rows):
    items = []
    for row in rows:
        thumb = row.get('images',{}).get('showTile','').split('?')[0]
        #fanart = row.get('images',{}).get('showHero','').split('?')[0] or thumb
        fanart = thumb

        item = plugin.Item(
            label = row['name'],
            art   = {'thumb': thumb, 'fanart': fanart},
            path  = plugin.url_for(show, id=row['showId']),
            cache_key = cache.key_for(show, id=row['showId']),
            info = {
                'title': row['name'],
                'plot': row.get('synopsis'), 
                'mediatype': 'tvshow',
                'tvshowtitle': row['name'],
            }
        )
        items.append(item)

    if not items:
        item = plugin.Item(label=_(L_NO_RESULTS, label=True), is_folder=False)
        items.append(item)

    return items

def _parse_episodes(rows, fanart=None):
    items = []
    for row in rows:
        videoid = row['videoRenditions']['videoCloud']['brightcoveId']
        thumb   = row.get('images',{}).get('videoTile','').split('?')[0]

        info = {
            'title': row['name'],
            'genre': row.get('genre'), 
            'plot': row.get('synopsis'), 
            'duration': int(row.get('duration')), 
            'aired': row.get('airedDate'),
            'mediatype': 'episode',
            'tvshowtitle': row.get('showTitle'),
        }

        try:
            info.update({
                'episode': int(row.get('episode')), 
                'season': int(row.get('season')),
            })
        except:
            pass

        item = plugin.Item(
            label = row['name'],
            art   = {'thumb': thumb, 'fanart': fanart},
            path  = plugin.url_for(play, id=videoid),
            info  = info,
            playable = True,
        )
        items.append(item)

    if not items:
        item = plugin.Item(label=_(L_NO_RESULTS, label=True), is_folder=False)
        items.append(item)

    return items

@plugin.route()
@cache.cached(EPISODE_EXPIRY)
def show(id):
    row = api.show(id)

    thumb = row.get('images',{}).get('showTile','').split('?')[0]
    #fanart = row.get('images',{}).get('showHero','').split('?')[0] or thumb
    fanart = thumb

    folder = plugin.Folder(title=row['name'])
    folder.add_items(_parse_episodes(row['episodes'], fanart))
    return folder

@plugin.route()
def play(id=None, channel=None):
    if id:
        return api.get_brightcove_src(id)
    elif channel:
        for row in api.live():
            if row['title'] == channel:
                return plugin.Item(inputstream=inputstream.HLS(), path=row['videoRenditions']['videoCloud']['hlsUrl'], art=False)

@plugin.route()
def search():
    query = gui.input(_(L_SEARCH), default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    folder = plugin.Folder(title=_(L_SEARCH_FOR, query=query))
    items = _parse_shows(api.search(query))
    folder.add_items(items)

    return folder

@plugin.route()
def live():
    folder = plugin.Folder(title=_(L_LIVE))

    for row in api.live():
        folder.add_item(
            label = row['displayName'],
            art   = {'thumb': row.get('logo','').split('?')[0]},
            path  = plugin.url_for(play, is_live=True, channel=row['title']),
            playable = True,
        )

    return folder