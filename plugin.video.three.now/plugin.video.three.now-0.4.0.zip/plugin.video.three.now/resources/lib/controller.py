from collections import OrderedDict

from matthuisman.controller import Controller as BaseController

from .api import API
from . import config

class Controller(BaseController):
    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self._api = API(self._addon)

    def home(self, params):
        items = [
            {'title':'Shows',   'url': self._router.get(self.shows)},
            {'title':'Live',    'url': self._router.get(self.live)},
            {'title':'Settings', 'url': self._router.get(self.settings)},
        ]

        self._view.items(items)

    def _get_shows(self):
        def get_items():
            shows = OrderedDict()

            data = self._api.get('shows')['shows']
            for item in data:
                show = self._parse_show(item)
                shows[show['id']] = show

            return shows

        return self._addon.cache.function('shows', get_items, expires=config.SHOWS_CACHE)

    def _get_episodes(self, show):
        def get_items():
            episodes = OrderedDict()

            url = 'show/{}'.format(show['id'])
            data = self._api.get(url)['show']['episodes']
            for item in data:
                episode = self._parse_episode(item, show)
                episodes[episode['id']] = episode

            return episodes

        return self._addon.cache.function(show['id'], get_items, expires=config.EPISODE_CACHE)

    def _get_channels(self):
        def get_items():
            channels = OrderedDict()

            data = self._api.get('live-epg')
            for channel in data['channels']:
                channels[channel['title']] = {
                    'title': channel.get('displayName'),
                    'images': {'thumb': channel.get('logo','').split('?')[0]},
                    'url': self._router.get(self.live, {'play': channel.get('title')}, live=True),
                    'playable': True,
                    'vid_type': 'hls',
                    'play_url': channel['videoRenditions']['videoCloud']['hlsUrl'],
                }

            return channels

        return self._addon.cache.function('channels', get_items, expires=config.SHOWS_CACHE)

    def shows(self, params):
        items = self._get_shows().values()
        self._view.items(items, title='Shows')

    def episodes(self, params):
        show = self._get_shows()[params['show']]
        items = self._get_episodes(show).values()
        self._view.items(items, title=show.get('title'))

    def play(self, params):
        try:
            show = self._get_shows()[params['show']]
            episode = self._get_episodes(show)[params['vid']]
        except:
            episode = {}

        data = self._api.get_brightcove_src(params['vid'])
        data['options'] = {'headers': config.HEADERS}
        episode.update(data)

        self._view.play(episode)

    def live(self, params):
        channels = self._get_channels()

        if params.get('play'):
            channel = channels[params['play']]
            channel['url'] = channel.pop('play_url')
            channel['options'] = {'headers': config.HEADERS, 'use_ia_hls': self._addon.settings.getBool('use_ia_hls')}
            return self._view.play(channel)

        self._view.items(channels.values(), title='Live')

    def _parse_show(self, show):
        showId = show.get('showId')
        title = show.get('name')
        image = show.get('images',{}).get('showTile','').split('?')[0]
        #fanart = show.get('images',{}).get('showHero','').split('?')[0]
        fanart = image

        info = {
            'title': title,
            'plot': show.get('synopsis'), 
            'mediatype': 'tvshow',
            'tvshowtitle': title,
        }

        show = {
            'id': showId,
            'title': title,
            'url': self._router.get(self.episodes, {'show':showId}),
            'images': {'thumb': image, 'poster': image, 'fanart': fanart},
            'info': info,
        }

        return show

    def _parse_episode(self, episode, show):
        title = episode.get('name')
        videoid = episode['videoRenditions']['videoCloud']['brightcoveId']
        image = episode.get('images',{}).get('videoTile','').split('?')[0]

        info = {
            'title': title,
            'genre': episode.get('genre'), 
            'plot': episode.get('synopsis'), 
            'duration': int(episode.get('duration')), 
            'aired': episode.get('airedDate'),
            'mediatype': 'episode',
            'tvshowtitle': episode.get('showTitle'),
        }

        try:
            info.update({
                'episode': int(episode.get('episode')), 
                'season': int(episode.get('season')),
                })
        except:
            pass

        episode = {
            'id': videoid,
            'title': title,
            'url': self._router.get(self.play, {'vid': videoid, 'show': show['id']}),
            'images': {'thumb': image, 'fanart': show.get('fanart')},
            'playable': True,
            'info': info,
        }

        return episode