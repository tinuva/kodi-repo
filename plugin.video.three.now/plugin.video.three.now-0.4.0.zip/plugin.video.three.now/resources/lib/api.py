import requests

from matthuisman.util import process_brightcove, log

from . import config

class API(object):
    def __init__(self, addon):
        self._addon = addon

        self._session = requests.session()
        self._session.headers.update(config.HEADERS)

    def get(self, url, **kwargs):
        url = config.BASE_API.format(url)

        log.debug('{} {}'.format(url, kwargs))
        data = self._session.get(url, **kwargs).json()
        if not data: 
            raise

        return data

    def get_brightcove_src(self, referenceID):
        brightcove_url = config.BRIGHTCOVE_URL.format(config.BRIGHTCOVE_ACCOUNT, referenceID)
        data = self._session.get(brightcove_url, headers={'BCOV-POLICY': config.BRIGHTCOVE_KEY}).json()
        return process_brightcove(data)