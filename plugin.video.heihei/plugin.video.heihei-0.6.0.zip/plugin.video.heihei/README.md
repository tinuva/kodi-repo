# plugin.video.heihei

Unofficial 3rd party HeiHei.nz plugin for Kodi.

https://www.matthuisman.nz/2018/05/heihei-kodi-add-on.html
