import os
import time
from datetime import timedelta

from matthuisman import plugin, gui, cache, settings, userdata, inputstream
from matthuisman.util import get_string as _
from matthuisman.constants import ADDON_PATH

from .api import API
from .constants import SHOWS_EXPIRY, EPISODE_EXPIRY, HEADERS, SHOWS_CACHE_KEY

api = API()

L_ALL_SHOWS    = 30000
L_VIDEO        = 30001
L_AUDIO        = 30002
L_SEARCH       = 30003
L_SETTINGS     = 30004
L_SEARCH_FOR   = 30005
L_NO_RESULTS   = 30006

IMAGE_PATH = os.path.join(ADDON_PATH, 'resources', 'images')

@plugin.route('')
def home():
    folder = plugin.Folder()

    folder.add_item(label=_(L_ALL_SHOWS, bold=True),  path=plugin.url_for(all_shows), cache_key=SHOWS_CACHE_KEY)
    folder.add_item(label=_(L_VIDEO, bold=True),      path=plugin.url_for(video),     cache_key=SHOWS_CACHE_KEY, art={'thumb': os.path.join(IMAGE_PATH, 'video.png')})
    folder.add_item(label=_(L_AUDIO, bold=True),      path=plugin.url_for(audio),     cache_key=SHOWS_CACHE_KEY, art={'thumb': os.path.join(IMAGE_PATH, 'audio.png')})
    folder.add_item(label=_(L_SEARCH, bold=True),     path=plugin.url_for(search))

    folder.add_item(label=_(L_SETTINGS),  path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def all_shows():
    folder = plugin.Folder(title=_(L_ALL_SHOWS))
    rows = _shows()
    folder.add_items(_parse_rows(rows))
    return folder

@plugin.route()
def video():
    folder = plugin.Folder(title=_(L_AUDIO))
    rows = [x for x in _shows() if x['values']['showType'] == 'Show']
    folder.add_items(_parse_rows(rows))
    return folder

@plugin.route()
def audio():
    folder = plugin.Folder(title=_(L_AUDIO))
    rows = [x for x in _shows() if x['values']['showType'] == 'Audio']
    folder.add_items(_parse_rows(rows))
    return folder

@cache.cached(SHOWS_EXPIRY, key=SHOWS_CACHE_KEY)
def _shows():
    return [x for x in api.all_shows() if x['values'].get('showType') in ['Show', 'Audio']]

@plugin.route()
@cache.cached(EPISODE_EXPIRY)
def show(show_id, title, fanart=None):
    folder = plugin.Folder(title=title)
    for row in api.show(show_id):
        title = row.get('title','').encode('utf-8')
        if title:
            folder.add_item(
                label = _(title, label=True),
                is_folder = False,
            )

        rows = row.get('episodes', [])
        folder.add_items(_parse_rows(rows, fanart))

    return folder

@plugin.route()
def search():
    query = gui.input(_(L_SEARCH), default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    @cache.cached(SHOWS_EXPIRY)
    def get_results(query):
        folder = plugin.Folder(title=_(L_SEARCH_FOR, query=query))
        rows = api.search(query)
        folder.add_items(_parse_rows(rows))

        if not folder.items:
            folder.add_item(
                label     = _(L_NO_RESULTS, label=True),
                is_folder = False,
            )

        return folder

    return get_results(query)

def _parse_rows(rows, fanart=None):
    items = []
    for item in rows:
        if not item: 
            continue

        if item['values'].get('showType'):
            items.append(_parse_show(item, fanart))
        elif item['values'].get('mediaType'):
            items.append(_parse_episode(item, fanart))

    return items

def _parse_show(data, fanart):
    show_id = data['id']
    values  = data['values']

    title         = values.get('title', '').encode('utf-8')
    synopsis      = values.get('synopsis', '').encode('utf-8')
    try: thumb    = values['images']['thumbnail']['url'].replace(' ', '%20')
    except: thumb = None

    item = plugin.Item(
        label = title,
        info  = {'plot': synopsis, 'mediatype': 'tvshow'},
        art   = {'thumb': thumb, 'fanart': fanart or thumb},
        path  = plugin.url_for(show, show_id=show_id, title=title, fanart=thumb),
    )

    return item

def _parse_episode(data, fanart):
    episode_id = data['id']
    values     = data['values']

    episode_type = values.get('mediaType')
    if episode_type not in ('video', 'audio'):
        return None

    brightcoveid  = values.get('brightcoveVideoId')
    title         = values.get('title', '').encode('utf-8')
    synopsis      = values.get('synopsis', '').encode('utf-8')
    episode       = values.get('episodeNumber')
    season        = values.get('seasonNumber')
    show_title    = values.get('showName')
    duration      = values.get('runTime', '00:00:00')
    try: thumb    = values['images']['thumbnail']['url'].replace(' ', '%20')
    except: thumb = None

    try: duration = time.strptime(duration,'%H:%M:%S')
    except ValueError:
        try: duration = time.strptime(duration,'%M:%S')
        except: duration = None
    
    if duration:
        duration = int(timedelta(hours=duration.tm_hour,minutes=duration.tm_min,seconds=duration.tm_sec).total_seconds())

    item = plugin.Item(
        label    = title,
        path     = plugin.url_for(play, brightcoveId=brightcoveid),
        playable = True,
        art      = {'thumb': thumb, 'fanart': fanart},
        info     = {
            'plot': synopsis,
            'episode': int(episode) if episode else None,
            'season': int(season) if season else None,
            'mediatype': 'episode',
            'tvshowtitle': show_title,
            'duration': duration,
        },
    )

    return item

@plugin.route()
def play(brightcoveId):
    item = api.get_brightcove_src(brightcoveId)
    item.headers = HEADERS
    return item