# -*- coding: utf-8 -*-
import os
import time
from datetime import timedelta

from matthuisman.controller import Controller as BaseController
from matthuisman.exceptions import InputError

from . import config
from .api import API

class Controller(BaseController):
    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self._api = API(self._addon)

    def home(self, params):
        items = [
            {'title':'A-Z',        'url': self._router.get(self.a_to_z, {'title': 'A-Z'})},
            {'title':'Mātaki',     'url': self._router.get(self.video, {'title': 'Mātaki'}),     'images':{'thumb': os.path.join(self._addon.path, 'resources', 'images', 'video.png')}},
            {'title':'Whakarongo', 'url': self._router.get(self.audio, {'title': 'Whakarongo'}), 'images':{'thumb': os.path.join(self._addon.path, 'resources', 'images', 'audio.png')}},
            {'title':'Search',     'url': self._router.get(self.search, {'title': 'Search'})},
            {'title':'Settings',   'url': self._router.get(self.settings)},
        ]

        self._view.items(items)

    def a_to_z(self, params):
        items = self._all_shows()
        self._view.items(items, title=params.get('title'))

    def video(self, params):
        items = [x for x in self._all_shows() if x['show_type'] == 'Show']
        self._view.items(items, title=params.get('title'))

    def audio(self, params):
        items = [x for x in self._all_shows() if x['show_type'] == 'Audio']
        self._view.items(items, title=params.get('title'))

    def play(self, params):
        data = self._api.get_brightcove_src(params.get("brightcoveId"))
        data['options'] = {'headers': config.HEADERS}
        self._view.play(data)

    def _all_shows(self):
        def get_items():
            page = self._api.get('/fdc5bb90-3855-11e8-bd33-f19b3f2c96ff/values/seasons/refs', 
                    params={'sort': 'designation', 'removeExpired': 'true', 'workflows': '%5B"Published"%5D', 'setSize': '1000', 'includeRefs': 'true'}).json()
    
            items = []
            for data in page['data']:
                for data2 in data.get('values', {}).get('episodes', []):
                    item = self._parse_item(data2)
                    if item: 
                        items.append(item)

            return items

        return self._addon.cache.function('shows', get_items, expires=config.SHOWS_CACHE)

    def search(self, params):
        last_search = self._addon.data.get('last_search', '')

        query = self._view.get_input("Search", default=last_search)
        if not query:
            raise InputError()

        self._addon.data['last_search'] = query

        def get_items():
            page = self._api.get('/search/basic/template001', 
                params={'offset': 0, 'setSize': '1000', 'ascending': 'true', 'removeExpired': 'true', 'workflows': '%5B"Published"%5D', 'includeRefs': 'true', 'query': '"{0}"'.format(query)}).json()

            items = []
            for item in page['data']:
                item = self._parse_item(item)
                if item: 
                    items.append(item)

            return items

        items = self._addon.cache.function('search_{}'.format(query), get_items, expires=config.SHOWS_CACHE)
        self._view.items(items, title='Search')

    def episodes(self, params):
        show_id = params.get('id')

        def get_items():
            page = self._api.get('/{0}/values/seasons/refs'.format(show_id), 
                params={'sort': 'designation', 'removeExpired': 'true', 'workflows': '%5B"Published"%5D', 'setSize': '100', 'includeRefs': 'true'}).json()

            items = []
            for data in page['data']:
                title = data['values'].get('title','').encode('utf-8')
                #if title and not any(x in title.lower() for x in ('episode', 'season')):
                if title:
                    items.append({
                        'title' : "[B][COLOR yellow]** {0} **[/COLOR][/B]".format(title),
                        'is_folder' : False,
                    })

                for data2 in data.get('values', {}).get('episodes', []):
                    item = self._parse_item(data2, params.get('fanart'))
                    if item: 
                        items.append(item)

            return items

        items = self._addon.cache.function(show_id, get_items, expires=config.EPISODE_CACHE)
        self._view.items(items, title=params.get('title'))

    def _parse_item(self, data, fanart=None):
        if data['values'].get('showType'):
            return self._parse_show(data, fanart)
        elif data['values'].get('mediaType'):
            return self._parse_episode(data, fanart)
        else:
            return None

    def _parse_episode(self, data, fanart=None):
        episode_id    = data['id']
        values        = data['values']

        episode_type  = values.get('mediaType')
        brightcoveid  = values.get('brightcoveVideoId')
        title         = values.get('title', '').encode('utf-8')
        synopsis      = values.get('synopsis', '').encode('utf-8')
        episode       = values.get('episodeNumber')
        season        = values.get('seasonNumber')
        show_title    = values.get('showName')
        duration      = values.get('runTime', '00:00:00')
        try: thumb    = values['images']['thumbnail']['url'].replace(' ', '%20')
        except: thumb = None

        try: duration = time.strptime(duration,'%H:%M:%S')
        except ValueError:
            try: duration = time.strptime(duration,'%M:%S')
            except: duration = None

        if duration:
            duration = int(timedelta(hours=duration.tm_hour,minutes=duration.tm_min,seconds=duration.tm_sec).total_seconds())

        if episode_type not in ('video', 'audio'):
            return None

        info = {
            'title': title,
            'originaltitle': title,
            'plot': synopsis,
            'plotoutline': synopsis,
            'episode': int(episode) if episode else None,
            'season': int(season) if season else None,
            'mediatype': 'episode',
            'tvshowtitle': show_title,
            'duration': duration, 
        }

        item = {
            'title': title,
            'playable': True,
            'url': self._router.get(self.play, {'brightcoveId': brightcoveid}),
            'images': {'thumb': thumb, 'fanart': fanart},
            'info': info,
            'episode_type': episode_type,
        }

        return item

    def _parse_show(self, data, fanart=None):
        show_id       = data['id']
        values        = data['values']

        show_type     = values.get('showType')
        title         = values.get('title', '').encode('utf-8')
        synopsis      = values.get('synopsis', '').encode('utf-8')
        try: thumb    = values['images']['thumbnail']['url'].replace(' ', '%20')
        except: thumb = None

        if show_type not in ('Show', 'Audio'):
            return None

        if not fanart: 
            fanart = thumb

        info = {
            'title': title, 
            'originaltitle': title,
            'plot': synopsis,
            'plotoutline': synopsis,
            'mediatype': 'tvshow',
        }

        item = {
            'title': title,
            'playable': False,
            'url': self._router.get(self.episodes, {'id': show_id, 'title': title, 'fanart': thumb}),
            'images': {'thumb': thumb, 'poster': thumb, 'fanart': thumb},
            'info': info,
            'show_type': show_type,
        }

        return item