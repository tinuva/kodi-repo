from matthuisman.session import Session
from matthuisman import plugin, inputstream

from .constants import HEADERS, API_URL, BRIGHTCOVE_URL, BRIGHTCOVE_KEY, BRIGHTCOVE_ACCOUNT

class API(object):
    def __init__(self):
        self._session = Session(HEADERS, base_url=API_URL)

    def all_shows(self):
        shows = []

        params = {
            'sort': 'designation', 
            'removeExpired': 'true', 
            'workflows': '%5B"Published"%5D', 
            'setSize': '1000',
            'includeRefs': 'true',
        }

        data = self._session.get('fdc5bb90-3855-11e8-bd33-f19b3f2c96ff/values/seasons/refs', params=params).json()
        for row in data['data']:
            shows.extend(row['values'].get('episodes', []))

        return shows

    def search(self, query):
        params = {
            'offset': 0, 
            'ascending': 'true', 
            'removeExpired': 'true', 
            'workflows': '%5B"Published"%5D', 
            'setSize': '1000',
            'includeRefs': 'true', 
            'query': '"{}"'.format(query)
        }

        data = self._session.get('search/basic/template001', params=params).json()
        return data['data']

    def show(self, show_id):
        seasons = []

        params = {
            'sort': 'designation', 
            'removeExpired': 'true', 
            'workflows': '%5B"Published"%5D', 
            'setSize': '1000', 
            'includeRefs': 'true'
        }

        data = self._session.get('{}/values/seasons/refs'.format(show_id), params=params).json()
        for row in data['data']:
            seasons.append(row['values'])

        return seasons

    def get_brightcove_src(self, referenceID):
        brightcove_url = BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, referenceID)
        data = self._session.get(brightcove_url, headers={'BCOV-POLICY': BRIGHTCOVE_KEY}).json()

        videos = []
        for source in data['sources']:
            if not source.get('src'):
                continue

            if source.get('container') == 'MP4':
                videos.append({
                    'item': plugin.Item(
                        path = source['src'], 
                        art = False), 
                    '_sort': source.get('avg_bitrate', source.get('height')),
                })

            elif 'key_systems' in source and 'com.widevine.alpha' in source['key_systems']:
                videos.append({
                    'item': plugin.Item(
                        inputstream = inputstream.Widevine(source['key_systems']['com.widevine.alpha']['license_url']), 
                        path = source['src'], 
                        art = False),
                })

        if videos:
            videos = sorted(videos, key=lambda x: x.get('_sort'), reverse=True)
            return videos[0]['item']

        raise Exception('Could not find a source from brightcove')