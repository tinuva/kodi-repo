from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ALL_SHOWS    = 30000
    VIDEO        = 30001
    AUDIO        = 30002

_ = Language()