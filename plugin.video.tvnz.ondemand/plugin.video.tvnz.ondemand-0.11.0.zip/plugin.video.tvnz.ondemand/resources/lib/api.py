from urllib import quote

from matthuisman import plugin, inputstream, cache
from matthuisman.session import Session

from .constants import HEADERS, API_URL, BRIGHTCOVE_URL, BRIGHTCOVE_KEY, BRIGHTCOVE_ACCOUNT, SHOWS_EXPIRY

class API(object):
    def __init__(self):
        self._session = Session(HEADERS, base_url=API_URL)

    def a_to_z(self):
        items = []

        data = self._session.get('/content/tvnz/ondemand/shows').json()
        for belt in data:
            if belt.get('beltType') != 'default':
                continue

            items.append({'title': belt.get('title'), 'path': belt.get('beltPath')})

        return items

    def genre(self):
        items = []

        data = self._session.get('/content/tvnz/ondemand/genre').json()
        for belt in data:
            if belt.get('beltType') != 'default':
                continue

            items.append({'title': belt.get('title'), 'path': belt.get('beltPath')})

        return items

    def search(self, query):
        return self._session.get('/content/tvnz/ondemand/shows/search/{}'.format(quote(query.strip()))).json()

    def show(self, path):
        return self._session.get(path).json()

    def belt(self, path):
        url = '{}/999/0'.format(path)
        return self._session.get(url).json()

    def get_channel(self, channel):
        url = '/content/tvnz/ondemand/channels/{}'.format(channel)
        return self._session.get(url).json()[0]['mainItem']['liveStreamUrl'].strip()

    def get_brightcove_src(self, referenceID):
        brightcove_url = BRIGHTCOVE_URL.format(BRIGHTCOVE_ACCOUNT, referenceID)
        
        resp = self._session.get(brightcove_url, headers={'BCOV-POLICY': BRIGHTCOVE_KEY})
        data = resp.json()

        for source in data['sources']:
            if not source.get('src'):
                continue

            if source.get('type') == 'application/x-mpegURL' and 'key_systems' not in source:
                return plugin.Item(
                    inputstream = inputstream.HLS(), 
                    path = source['src'], 
                    art = False)

            elif source.get('type') == 'application/dash+xml' and 'key_systems' in source and 'com.widevine.alpha' in source['key_systems']:
                return plugin.Item(
                    inputstream = inputstream.Widevine(source['key_systems']['com.widevine.alpha']['license_url']), 
                    path = source['src'], 
                    art = False)

        raise Exception('Could not find a source from brightcove')