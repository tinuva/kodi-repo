from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ALL_SHOWS    = 30000
    A_Z          = 30001
    GENRE        = 30002
    LIVE         = 30003
    ALL_EPISODES = 30004

_ = Language()