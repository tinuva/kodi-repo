# plugin.video.tvnz.ondemand

Unofficial 3rd Party TVNZ OnDemand plugin for Kodi.

https://www.matthuisman.nz/2017/02/kodi-tvnz-ondemand-add-on.html
