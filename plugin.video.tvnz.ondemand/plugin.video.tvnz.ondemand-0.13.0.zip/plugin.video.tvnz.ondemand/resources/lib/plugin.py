import os

from matthuisman import plugin, gui, cache, settings, userdata, inputstream
from matthuisman.constants import ADDON_PATH

from .api import API
from .constants import SHOWS_EXPIRY, EPISODE_EXPIRY, ALL_SHOWS_BELT, IMG_BASE, HEADERS
from .language import _

api = API()

@plugin.route('')
def home():
    folder = plugin.Folder()

    folder.add_item(
        label = _(_.ALL_SHOWS, _bold=True), 
        path  = plugin.url_for(belt, path=ALL_SHOWS_BELT, title=_.ALL_SHOWS), 
        cache_key = cache.key_for(belt, path=ALL_SHOWS_BELT, title=_.ALL_SHOWS),
    )
    
    folder.add_item(label=_(_.A_Z, _bold=True),    path=plugin.url_for(a_to_z), cache_key=cache.key_for(a_to_z))
    folder.add_item(label=_(_.GENRE, _bold=True),  path=plugin.url_for(genre),  cache_key=cache.key_for(genre))
    folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search))
    folder.add_item(label=_(_.LIVE, _bold=True),   path=plugin.url_for(live),   cache_key=cache.key_for(live))

    folder.add_item(label=_.SETTINGS,  path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def a_to_z():
    folder = plugin.Folder(title=_.A_Z)

    for row in api.a_to_z():
        folder.add_item(
            label     = row['title'],
            path      = plugin.url_for(belt, path=row['path'], title=row['title']),
            cache_key = cache.key_for(belt, path=row['path'], title=row['title']),
        )

    return folder
    
@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def belt(path, title=''):
    folder = plugin.Folder(title=title)
    rows = api.belt(path)
    folder.add_items(_parse_rows(rows))
    return folder

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def genre():
    folder = plugin.Folder(title=_.GENRE)

    for row in api.genre():
        folder.add_item(
            label     = row['title'],
            path      = plugin.url_for(belt, path=row['path'], title=row['title']),
            cache_key = cache.key_for(belt, path=row['path'], title=row['title']),
        )

    return folder

@plugin.route()
def search():
    query = gui.input(_.SEARCH, default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    folder = plugin.Folder(title=_(_.SEARCH_FOR, query=query))
    rows = api.search(query)
    folder.add_items(_parse_rows(rows))

    if not folder.items:
        folder.add_item(
            label     = _(_.NO_RESULTS, _label=True),
            is_folder = False,
        )

    return folder

@plugin.route()
def live():
    folder = plugin.Folder(title=_.LIVE)

    def get_path(filename):
        return os.path.join(ADDON_PATH, 'resources', 'images', filename)

    CHANNELS = [
        plugin.Item(label='TVNZ 1', 
            playable=True, path=plugin.url_for(play, is_live=True, channel='tvnz-1'), 
            art = {'thumb': get_path('tvnz-1.png'), 'fanart': get_path('tvnz-1-fanart.jpg')}),
        plugin.Item(label='TVNZ 2', 
            playable=True, path=plugin.url_for(play, is_live=True, channel='tvnz-2'), 
            art = {'thumb': get_path('tvnz-2.png'), 'fanart': get_path('tvnz-2-fanart.jpg')}),
        plugin.Item(label='TVNZ DUKE', 
            playable=True, path=plugin.url_for(play, is_live=True, channel='tvnz-duke'), 
            art = {'thumb': get_path('tvnz-duke.png'), 'fanart': get_path('tvnz-duke-fanart.jpg')}),
    ]

    for channel in CHANNELS:
        folder.add_items([channel])

    return folder

@plugin.route()
@cache.cached(EPISODE_EXPIRY)
def show(path):
    rows = api.show(path)

    show = rows[0]['mainItem']
    image = show.get('tileImage')
    if image and 'http' not in image:
        image = IMG_BASE.format(image)

    folder = plugin.Folder(title=show['displayTitle'])

    subdirs = []
    for row in rows:
        if not row or row.get('beltType') != 'default':
            continue

        count = int(row.get('size', 0))
        def clean_contents(contents):
            return [i for i in contents if i]

        row['contents'] = clean_contents(row['contents'])
        if not row['contents'] or row['contents'][0].get('showPath') != path:
            continue

        subdirs.append(row)

    if not subdirs:
        return folder

    if subdirs[0]['title'].lower().strip() == 'episodes':
        main_dir = subdirs.pop(0)
        items = _parse_rows(main_dir['contents'])
        if len(items) < int(main_dir.get('size', 0)):
            if not subdirs:
                rows = api.belt(main_dir['beltPath'])
                items = _parse_rows(rows)
            else:
                items.append(plugin.Item(
                    label     = _.ALL_EPISODES,
                    path      = plugin.url_for(episodes, path=main_dir['beltPath'], title=show['displayTitle']),
                    cache_key = cache.key_for(episodes,  path=main_dir['beltPath'], title=show['displayTitle']),
                    art       = {'thumb': image},
                ))

        folder.add_items(items)

    for row in subdirs:
        folder.add_item(
            label     = row['title'],
            path      = plugin.url_for(episodes, path=row['beltPath'], title=show['displayTitle']),
            cache_key = cache.key_for(episodes,  path=row['beltPath'], title=show['displayTitle']),
            art       = {'thumb': image},
        )

    return folder

@plugin.route()
@cache.cached(EPISODE_EXPIRY)
def episodes(path, title=''):
    folder = plugin.Folder(title=title)
    rows = api.belt(path)
    folder.add_items(_parse_rows(rows))
    return folder

@plugin.route()
def play(livestream=None, brightcoveId=None, channel=None, from_start=None):
    if brightcoveId:
        item = api.get_brightcove_src(brightcoveId)
    elif livestream:
        item = plugin.Item(inputstream=inputstream.HLS(), path=livestream, art=False)
        if from_start:
            item.properties['ResumeTime'] = '1'
            item.properties['TotalTime']  = '1'
    elif channel:
        path = api.get_channel(channel)
        item = plugin.Item(inputstream=inputstream.HLS(), path=path, art=False)

    item.headers = HEADERS
    
    return item

def _parse_rows(rows):
    items = []
    for item in rows:
        if not item: 
            continue

        if item.get('brightcoveId') or item.get('liveStreamUrl'):
            item = _parse_episode(item)
            if item:
                items.append(item)

        elif item.get('path'):
            item = _parse_show(item)
            if item:
                items.append(item)

    return items

def _parse_show(data):
    if not int(data.get('episodesPublished', 0)):
        return None

    title = data.get('displayTitle')
    image = data.get('tileImage', data.get('images',{}).get('default'))
    if image:
        image = IMG_BASE.format(image)

    item = plugin.Item(
        label = title,
        path  = plugin.url_for(show, path=data.get('path')),
        cache_key = cache.key_for(show, path=data.get('path')),
        art   = {'thumb': image},
        info  = {
            'plot': data.get('synopsis'), 
            'mediatype': 'tvshow',
            'tvshowtitle': title,
        }
    )

    return item

def _parse_episode(data):
    brightcoveId = data.get('brightcoveId')
    liveStreamUrl = data.get('liveStreamUrl')
    if not brightcoveId and not liveStreamUrl:
        return None

    title = data.get('identifier2')
    if not title:
        title = data.get('identifier3')
    if not title:
        title = data.get('identifier1')

    image = data.get('tileImage')
    if image and 'http' not in image:
        image = IMG_BASE.format(image)

    info = {
        'title': title,
        'plot': data.get('synopsis'), 
        'duration': int(data.get('duration',0))/1000, 
        'aired': data.get('broadCastDate'),
        'mediatype': 'episode',
        'tvshowtitle': data.get('identifier1'),
    }

    try:
        info['episode'] = int(data['eVar31'].split('-')[0].strip('e'))
        info['season'] = int(data.get('path').split('/')[-2].strip('s'))
    except:
        pass

    item = plugin.Item(
        label = title,
        playable = True,
        info = info,
        art = {'thumb': image},
    )

    if liveStreamUrl:
        item.info['aired'] = data.get('streamStartTime')
        item.path = plugin.url_for(play, is_live=True, livestream=liveStreamUrl)
        item.context.append((_.WATCH_FROM_START, "XBMC.PlayMedia({0})".format(
            plugin.url_for(play, is_live=True, livestream=liveStreamUrl, from_start=True)
        )))

    else:
        item.path = plugin.url_for(play, brightcoveId=brightcoveId)

    return item