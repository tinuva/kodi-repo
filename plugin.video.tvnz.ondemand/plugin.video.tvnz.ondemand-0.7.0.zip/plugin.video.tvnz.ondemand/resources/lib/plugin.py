import os

from matthuisman import plugin, gui, cache, settings, userdata, inputstream
from matthuisman.util import get_string as _
from matthuisman.constants import ADDON_PATH

from .api import API
from .constants import SHOWS_EXPIRY, ALL_SHOWS_BELT, IMG_BASE, HEADERS

L_ALL_SHOWS    = 30000
L_A_Z          = 30001
L_GENRE        = 30002
L_SEARCH       = 30003
L_LIVE         = 30004
L_SETTINGS     = 30005
L_NO_RESULTS   = 30006
L_SEARCH_FOR   = 30007
L_MORE         = 30008

api = API()

@plugin.route('')
def home():
    folder = plugin.Folder()

    folder.add_item(
        label = _(L_ALL_SHOWS, bold=True), 
        path  = plugin.url_for(belt, path=ALL_SHOWS_BELT, title=_(L_ALL_SHOWS)), 
        cache_key = cache.key_for(belt, path=ALL_SHOWS_BELT, title=_(L_ALL_SHOWS)),
    )
    
    folder.add_item(label=_(L_A_Z, bold=True),       path=plugin.url_for(a_to_z), cache_key=cache.key_for(a_to_z))
    folder.add_item(label=_(L_GENRE, bold=True),     path=plugin.url_for(genre),  cache_key=cache.key_for(genre))
    folder.add_item(label=_(L_SEARCH, bold=True),    path=plugin.url_for(search))
    folder.add_item(label=_(L_LIVE, bold=True),      path=plugin.url_for(live),   cache_key=cache.key_for(live))

    folder.add_item(label=_(L_SETTINGS),  path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def a_to_z():
    folder = plugin.Folder(title=_(L_A_Z))

    for row in api.a_to_z():
        folder.add_item(
            label     = row['title'],
            path      = plugin.url_for(belt, path=row['path'], title=row['title']),
            cache_key = cache.key_for(belt, path=row['path'], title=row['title']),
        )

    return folder
    
@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def belt(path, title=''):
    folder = plugin.Folder(title=title)
    rows = api.belt(path)
    folder.add_items(_parse_rows(rows))
    return folder

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def genre():
    folder = plugin.Folder(title=_(L_GENRE))

    for row in api.genre():
        folder.add_item(
            label     = row['title'],
            path      = plugin.url_for(belt, path=row['path'], title=row['title']),
            cache_key = cache.key_for(belt, path=row['path'], title=row['title']),
        )

    return folder

@plugin.route()
def search():
    query = gui.input(_(L_SEARCH), default=userdata.get('search', '')).strip()
    if not query:
        return

    userdata.set('search', query)

    @cache.cached(SHOWS_EXPIRY)
    def get_results(query):
        folder = plugin.Folder(title=_(L_SEARCH_FOR, query=query))
        rows = api.search(query)
        folder.add_items(_parse_rows(rows))

        if not folder.items:
            folder.add_item(
                label     = _(L_NO_RESULTS, label=True),
                is_folder = False,
            )

        return folder

    return get_results(query)

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def live():
    folder = plugin.Folder(title=_(L_LIVE))

    def get_path(filename):
        return os.path.join(ADDON_PATH, 'resources', 'images', filename)

    CHANNELS = [
        plugin.Item(label='TVNZ 1', 
            playable=True, path=plugin.url_for(play, is_live=True, channel='tvnz-1'), 
            art = {'thumb': get_path('tvnz-1.png'), 'fanart': get_path('tvnz-1-fanart.jpg')}),
        plugin.Item(label='TVNZ 2', 
            playable=True, path=plugin.url_for(play, is_live=True, channel='tvnz-2'), 
            art = {'thumb': get_path('tvnz-2.png'), 'fanart': get_path('tvnz-2-fanart.jpg')}),
        plugin.Item(label='TVNZ DUKE', 
            playable=True, path=plugin.url_for(play, is_live=True, channel='tvnz-duke'), 
            art = {'thumb': get_path('tvnz-duke.png'), 'fanart': get_path('tvnz-duke-fanart.jpg')}),
    ]

    for channel in CHANNELS:
        folder.add_items([channel])

    return folder

@plugin.route()
@cache.cached(SHOWS_EXPIRY)
def show(path, title):
    folder = plugin.Folder(title=title)

    for row in api.show(path):
        if not row or row.get('beltType') != 'default':
            continue

        count = int(row.get('size', 0))
        def clean_contents(contents):
            return [i for i in contents if i]

        contents = clean_contents(row['contents'])
        if not contents or contents[0].get('showPath') != path:
            continue

        episodes = []
        for episode in contents:
            episode = _parse_episode(episode)
            if episode:
                episodes.append(episode)

        if not episodes:
            continue

        if row['title'].lower() != 'episodes':
            folder.add_item(
                label = _(row['title'], label=True),
                is_folder = False,
            )

        folder.add_items(episodes)

        if len(contents) < count:
            folder.add_item(
                label = _(L_MORE),
                path  = plugin.url_for(belt, path=row['beltPath'], title=title),
            )

    return folder


@plugin.route()
def play(livestream=None, brightcoveId=None, channel=None):
    if brightcoveId:
        item = api.get_brightcove_src(brightcoveId)
    elif livestream:
        item = plugin.Item(inputstream=inputstream.HLS(), path=livestream, art=False)
    elif channel:
        path = api.get_channel(channel)
        item = plugin.Item(inputstream=inputstream.HLS(), path=path, art=False)

    item.headers = HEADERS
    
    return item

def _parse_rows(rows):
    items = []
    for item in rows:
        if not item: 
            continue

        if item.get('brightcoveId') or item.get('liveStreamUrl'):
            items.append(_parse_episode(item))
        elif item.get('path'):
            items.append(_parse_show(item))

    return items

def _parse_show(data):
    title = data.get('displayTitle')
    image = data.get('tileImage', data.get('images',{}).get('default'))
    if image:
        image = IMG_BASE.format(image)

    item = plugin.Item(
        label = title,
        path  = plugin.url_for(show, path=data.get('path'), title=title),
        cache_key = cache.key_for(show, path=data.get('path'), title=title),
        art   = {'thumb': image, 'fanart': image},
        info  = {
            'plot': data.get('synopsis'), 
            'mediatype': 'tvshow',
            'tvshowtitle': title,
        }
    )

    return item

def _parse_episode(data):
    brightcoveId = data.get('brightcoveId')
    liveStreamUrl = data.get('liveStreamUrl')
    if not brightcoveId and not liveStreamUrl:
        return None

    title = data.get('identifier2')
    if not title:
        title = data.get('identifier3')
    if not title:
        title = data.get('identifier1')

    image = data.get('tileImage')
    if image and 'http' not in image:
        image = IMG_BASE.format(image)

    fanart = data.get('coverImage')
    if fanart and 'http' not in fanart:
        fanart = IMG_BASE.format(fanart)

    info = {
        'title': title,
        'plot': data.get('synopsis'), 
        'duration': int(data.get('duration',0))/1000, 
        'aired': data.get('broadCastDate'),
        'mediatype': 'episode',
        'tvshowtitle': data.get('identifier1'),
    }

    if liveStreamUrl:
        info['aired'] = data.get('streamStartTime')
        path = plugin.url_for(play, is_live=True, livestream=liveStreamUrl)
    else:
        path = plugin.url_for(play, brightcoveId=brightcoveId)

    try:
        info['episode'] = int(data['eVar31'].split('-')[0].strip('e'))
        info['season'] = int(data.get('path').split('/')[-2].strip('s'))
    except:
        pass

    return plugin.Item(
        label = title,
        path = path,
        playable = True,
        info = info,
        art = {'thumb': image, 'fanart': fanart}
    )