import time
import hashlib
from datetime import datetime

import xbmc

from .constants import ADDON
from .log import log

def hash_6(value, default=None):
    if not value:
        return default

    h = hashlib.md5(str(value))
    return h.digest().encode('base64')[:6]

def get_kodi_version():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split('.')[0])
    except:
        return 0

def strptime(date, str_format):
    try:
        return datetime.strptime(date, str_format)
    except TypeError:
        return datetime(*(time.strptime(date, str_format)[0:6]))

def get_string(id, bold=False, label=False, **kwargs):
    if isinstance(id, (int, long)):
        string = ADDON.getLocalizedString(id)
        if not string:
            log.warning("LANGUAGE: Addon didn't return a string for id: {}".format(id))
            return str(id)
    else:
        string = id

    string = string.format(**kwargs)

    if label:
        bold = True
        string = '~ {} ~'.format(string)

    if bold:
        string = '[B]{}[/B]'.format(string)
        
    return string