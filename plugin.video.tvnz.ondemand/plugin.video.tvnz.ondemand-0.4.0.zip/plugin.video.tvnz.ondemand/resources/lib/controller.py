import os
from urllib import quote

from matthuisman.controller import Controller as BaseController
from matthuisman.exceptions import InputError

from .api import API
from . import config

class Controller(BaseController):
    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self._api = API(self._addon)

    def home(self, params):
        items = [
            {'title':'All',      'url': self._router.get(self.all)},
            {'title':'A-Z',      'url': self._router.get(self.a_to_z)},
            {'title':'Genre',    'url': self._router.get(self.genre)},
            {'title':'Search',   'url': self._router.get(self.search)},
            {'title':'Live',     'url': self._router.get(self.live)},
            {'title':'Settings', 'url': self._router.get(self.settings)},
        ]

        self._view.items(items)

    def all(self, params):
        return self.belt({'path': '/content/tvnz/ondemand/belts/shows/category/all'})

    def a_to_z(self, params):
        def get_items():
            data = self._api.get('/content/tvnz/ondemand/shows')

            items = []
            for belt in data:
                if belt.get('beltType') != 'default':
                    continue

                items.append({
                    'title' : belt.get('title'),
                    'url'   : self._router.get(self.belt, {'path':belt.get('beltPath'), 'title':belt.get('title')})
                    })

            return items

        items = self._addon.cache.function('a_to_z', get_items, expires=config.SHOWS_CACHE)
        self._view.items(items, title='A-Z')

    def genre(self, params):
        def get_items():
            data = self._api.get('/content/tvnz/ondemand/genre')

            items = []
            for belt in data:
                if belt.get('beltType') != 'default':
                    continue

                items.append({
                    'title' : belt.get('title'),
                    'url'   : self._router.get(self.belt, {'path':belt.get('beltPath'), 'title':belt.get('title')})
                    })
            
            return items

        items = self._addon.cache.function('genre', get_items, expires=config.SHOWS_CACHE)
        self._view.items(items, title='Genre')

    def search(self, params):
        last_search = self._addon.data.get('last_search', '')

        query = self._view.get_input("Search", default=last_search)
        if not query:
            raise InputError('No query provided')

        self._addon.data['last_search'] = query

        def get_items():
            url = '/content/tvnz/ondemand/shows/search/{0}'.format(quote(query.strip()))
            data = self._api.get(url)
            return self._parse_content(data)

        items = self._addon.cache.function('search.{}'.format(query), get_items, expires=config.SHOWS_CACHE)
        self._view.items(items, title='Search')

    def live(self, params):
        channels = {
            1:  {'title':'TVNZ 1',     'slug':'tvnz-1',    'info': {'plot': "Breaking news, current affairs, outstanding docos, and a selection of local and international dramas - TVNZ 1 has you covered."}},
            2:  {'title':'TVNZ 2',     'slug':'tvnz-2',    'info': {'plot': "Live the moment with TVNZ 2, New Zealand's home of entertainment. The best content from around the world, plus your local favourites. It's showtime!"}},
            13: {'title':'TVNZ DUKE',  'slug':'tvnz-duke', 'info': {'plot': "Get game, laugh it up, watch real life, get hooked on a top drama or go big with a movie. The place for you is DUKE."}},
        }

        items = []
        for channel_num in channels:
            channel = channels[channel_num]
            channel.update({
                'images': {'thumb': os.path.join(self._addon.path,'resources','images',channel['slug'] + '.png'), 
                            'fanart':os.path.join(self._addon.path,'resources','images',channel['slug'] + '-fanart.jpg')},
                'url': self._router.get(self.live, {'channel': channel_num}, live=True),
                'vid_type': 'hls',
                'playable': True,
            })
            items.append(channel)
    
        if params.get('channel'):
            channel = channels[int(params['channel'])]

            url = '/content/tvnz/ondemand/channels/{0}'.format(channel['slug'])
            channel['url'] = self._api.get(url)[0]['mainItem']['liveStreamUrl'].strip()
            channel['options'] = {'headers': config.HEADERS, 'use_ia_hls': self._addon.settings.getBool('use_ia_hls')}

            self._view.play(channel)
        else:
            self._view.items(items, title='Live')

    def belt(self, params):
        def get_items():
            url = '{0}/999/0'.format(params['path'])
            data = self._api.get(url)
            return self._parse_content(data)

        items = self._addon.cache.function(params['path'], get_items, expires=config.SHOWS_CACHE)
        self._view.items(items, title=params.get('title'))

    def show(self, params):
        def get_items():
            url = params['path']
            data = self._api.get(url)

            items = []
            for belt in data:
                if not belt or belt.get('beltType') != 'default':
                    continue

                count = int(belt.get('size', 0))

                def clean_contents(contents):
                    return [i for i in contents if i]

                contents = clean_contents(belt['contents'])
                if not contents or contents[0].get('showPath') != url:
                    continue

                episodes = []
                for episode in contents:
                    episode = self._parse_episode(episode)
                    if episode:
                        episodes.append(episode)

                if not episodes:
                    continue

                if belt['title'].lower() != 'episodes':
                    items.append({
                        'title' : "[B][COLOR yellow]** {0} **[/COLOR][/B]".format(belt['title'])
                    })

                items.extend(episodes)

                if len(contents) < count:
                    items.append({
                        'title' : "More...",
                        'url'   : self._router.get(self.belt, {'path':belt.get('beltPath'), 'title':params.get('title')})
                        })

            return items

        items = self._addon.cache.function(params['path'], get_items, expires=config.EPISODE_CACHE)
        self._view.items(items, title=params.get('title'))

    def play(self, params):
        if params.get("brightcoveId"):
            data = self._api.get_brightcove_src(params.get("brightcoveId"))
        elif params.get("livestream"):
            data = {'url': params.get("livestream"), 'vid_type': 'hls'}
        else:
            raise Exception("Video not supported")

        data['options'] = {'headers': config.HEADERS}

        self._view.play(data)

    def _parse_content(self, content):
        items = []
        for item in content:
            if not item: continue

            if item.get('brightcoveId') or item.get('liveStreamUrl'):
                items.append(self._parse_episode(item))
            elif item.get('path'):
                items.append(self._parse_show(item))

        return items

    def _parse_episode(self, episode):
        brightcoveId = episode.get('brightcoveId')
        liveStreamUrl = episode.get('liveStreamUrl')
        if not brightcoveId and not liveStreamUrl:
            return None

        path = episode.get('path')

        title = episode.get('identifier2')
        if not title:
            title = episode.get('identifier3')
        if not title:
            title = episode.get('identifier1')

        image = episode.get('tileImage')
        if image and 'http' not in image:
            image = config.IMG_BASE.format(image)

        fanart = episode.get('coverImage')
        if fanart and 'http' not in fanart:
            fanart = config.IMG_BASE.format(fanart)

        info = {
            'title': title,
            'plot': episode.get('synopsis'), 
            'duration': int(episode.get('duration',0))/1000, 
            'aired': episode.get('broadCastDate'),
            'mediatype': 'episode',
            'tvshowtitle': episode.get('identifier1'),
        }

        if liveStreamUrl:
            info['aired'] = episode.get('streamStartTime')
            url = self._router.get(self.play, {'livestream': liveStreamUrl}, live=True)
        else:
            url = self._router.get(self.play, {'brightcoveId': brightcoveId})

        try:
            info['episode'] = int(episode['eVar31'].split('-')[0].strip('e'))
            info['season'] = int(path.split('/')[-2].strip('s'))
        except:
            pass

        episode = {
            'title' : info['title'],
            'url' : url,
            'path' : path,
            'images' : {'thumb': image, 'fanart': fanart},
            'playable' : True,
            'info' : info,
        }
                
        return episode

    def _parse_show(self, show):
        showId = show.get('showId')
        title = show.get('displayTitle')
        path = show.get('path')
        url = self._router.get(self.show, {'path':path, 'title': title})
        image = show.get('tileImage', show.get('images',{}).get('default'))
        if image:
            image = config.IMG_BASE.format(image)

        info = {
            'title': title,
            'originaltitle': title,
            'plot': show.get('synopsis'), 
            'plotoutline': show.get('synopsis'), 
            'mediatype': 'tvshow',
            'tvshowtitle': title,
        }

        show = {
            'id' : showId,
            'title' : title,
            'url'   : url,
            'images' : {'thumb': image, 'poster': image, 'fanart': image},
            'path' : path,
            'info' : info,
        }

        return show