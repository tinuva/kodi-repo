HEADERS    = {'User-Agent': 'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36', 'X-Forwarded-For': '202.89.4.222'}
BASE_API   = 'https://api.tvnz.co.nz/api{0}.androidtablet.v8.json'
IMG_BASE   = 'https://api.tvnz.co.nz{0}'

SHOWS_CACHE        = (60*60*24) #24 Hours
EPISODE_CACHE      = (60*5)     #5 Minutes

BRIGHTCOVE_URL     = 'https://edge.api.brightcove.com/playback/v1/accounts/{0}/videos/{1}'
BRIGHTCOVE_KEY     = 'BCpkADawqM0IurzupiJKMb49WkxM__ngDMJ3GOQBhN2ri2Ci_lHwDWIpf4sLFc8bANMc-AVGfGR8GJNgxGqXsbjP1gHsK2Fpkoj6BSpwjrKBnv1D5l5iGPvVYCo'
BRIGHTCOVE_ACCOUNT = '963482467001'