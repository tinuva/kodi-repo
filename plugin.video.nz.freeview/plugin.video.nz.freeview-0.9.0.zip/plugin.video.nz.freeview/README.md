# plugin.video.nz.freeview

NZ IPTV Plugin for Kodi.

https://www.matthuisman.nz/2017/06/nz-freeview-kodi-add-on.html
