M3U8_URL = 'http://iptv.matthuisman.nz/nz/tv.json'
CHANNELS_EXPIRY = (60*60*1) #1 hour