# service.gpio.monitor

GPIO Monitor service addon for Kodi.

https://www.matthuisman.nz/2016/11/kodi-gpio-monitor-service-addon.html