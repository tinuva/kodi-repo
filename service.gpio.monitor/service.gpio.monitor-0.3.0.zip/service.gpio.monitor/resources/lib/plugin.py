import xbmc, xbmcgui, copy

from matthuisman import plugin, gui, userdata
from matthuisman.constants import ADDON_ID

from .constants import RISING, FALLING, PUD_UP, PUD_DOWN, PUD_NONE, ENABLED, DISABLED, DEFAULT_PIN
from .language import _
from .gpio import check_install

class Pins(list):
    def load(self):
        self[:] = copy.deepcopy(userdata.get('pins', []))

    def save(self):
        userdata.set('pins', self[:])

pins = Pins()

@plugin.before_dispatch()
def before_dispatch():
    pins.load()

def pin_label(pin):
    label = _(_.PIN_LABEL, 
        pin = pin['pin'],
        edge = _.RISING if pin['edge'] == RISING else _.FALLING,
        function = pin['function'] or _.NONE, 
        disabled = _.DISABLED if pin['enabled'] == DISABLED else '',
        bold = pin['function'] == '',
    )

    return label

@plugin.route('')
def home():
    folder = plugin.Folder(cacheToDisc=False)

    for index, pin in enumerate(pins):
        item = plugin.Item(
            label = pin_label(pin),
            path  = plugin.url_for(edit_pin, index=index),
        )

        if index > 0:
            item.context.append((_.MOVE_UP, "XBMC.RunPlugin({})".format(plugin.url_for(move_up, index=index))))

        if index < len(pins)-1:
            item.context.append((_.MOVE_DOWN, "XBMC.RunPlugin({})".format(plugin.url_for(move_down, index=index))))

        if pin['enabled'] == DISABLED:
            item.context.append((_.ENABLE, "XBMC.RunPlugin({})".format(plugin.url_for(enable_pin, index=index))))
        else:
            item.context.append((_.DISABLE, "XBMC.RunPlugin({})".format(plugin.url_for(disable_pin, index=index))))

        item.context.append((_.REMOVE_PIN, "XBMC.RunPlugin({})".format(plugin.url_for(remove_pin, index=index))))

        folder.add_items([item])

    folder.add_item(label=_(_.ADD_PIN, bold=len(pins) == 0),  path=plugin.url_for(add_pin))
    folder.add_item(label=_.RESTART_SERVICE,                  path=plugin.url_for(restart_service))
    folder.add_item(label=_.SETTINGS,                         path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def move_up(index):
    index = int(index)
    pin = pins.pop(index)
    pins.insert(index-1, pin)
    pins.save()
    gui.refresh()

@plugin.route()
def move_down(index):
    index = int(index)
    pin = pins.pop(index)
    pins.insert(index+1, pin)
    pins.save()
    gui.refresh()

@plugin.route()
def enable_pin(index):
    pins[int(index)]['enabled'] = ENABLED
    pins.save()
    gui.refresh()

@plugin.route()
def disable_pin(index):
    pins[int(index)]['enabled'] = DISABLED
    pins.save()
    gui.refresh()

@plugin.route()
def remove_pin(index):
    if not gui.yes_no(_.CONFIRM_REMOVE):
        return

    pins.pop(int(index))
    pins.save()
    gui.refresh()

def pud_label(pud):
    if pud == PUD_UP:
        return _.PUD_UP
    elif pud == PUD_DOWN:
        return _.PUD_DOWN
    else:
        return _.NONE

@plugin.route()
def edit_pin(index):
    pin = pins[int(index)]

    folder = plugin.Folder(title=_.EDIT_PIN)
    folder.add_item(
        label = _('{option}: {pin}', option=_.PIN, pin=pin['pin'] if pin['pin'] else _.NONE),
        path  = plugin.url_for(select_pin, index=index),
    )
    folder.add_item(
        label = _('{option}: {edge}', option=_.EDGE, edge=_.RISING if pin['edge'] == RISING else _.FALLING),
        path  = plugin.url_for(select_edge, index=index),
    )
    folder.add_item(
        label = _('{option}: {pud}', option=_.PUD_SELECT, pud=pud_label(pin['pud'])),
        path  = plugin.url_for(select_pud, index=index),
    )
    folder.add_item(
        label = _('{option}: {enabled}', option=_.ENABLE, enabled=_.YES if pin['enabled'] == ENABLED else _.NO),
        path  = plugin.url_for(select_enabled, index=index),
    )
    folder.add_item(
        label = _('{option}: {function}', option=_.FUNCTION, function=pin['function'] or _.NONE),
        path  = plugin.url_for(select_function, index=index),
    )

    return folder

@plugin.route()
def add_pin():
    pin = DEFAULT_PIN.copy()
    pin['pin'] = _select_pin()
    if not pin['pin']:
        return

    for other_pin in pins:
        if other_pin['pin'] == pin['pin']:
            pin['pud'] = other_pin['pud']
            break

    pins.append(pin)
    pins.save()
    gui.refresh()

@plugin.route()
def select_pin(index):
    pin = pins[int(index)]
    pin['pin'] = _select_pin(default=pin['pin'])
    if not pin['pin']:
        return

    pins.save()
    gui.refresh()

def _select_pin(default=None):
    pin = int(gui.input(_.PIN, default=str(default if default else ''), type=xbmcgui.INPUT_NUMERIC) or -1)
    if pin < 0:
        return

    if pin not in range(1, 41):
        raise Exception(_.PIN_RANGE_ERROR)

    return pin

@plugin.route()
def select_edge(index):
    pin = pins[int(index)]

    index = gui.select(_.EDGE, [_.RISING, _.FALLING])
    if index < 0:
        return

    pin['edge'] = [RISING, FALLING][index]

    pins.save()
    gui.refresh()

@plugin.route()
def select_pud(index):
    pin = pins[int(index)]

    index = gui.select(_.PUD_SELECT, [_.PUD_UP, _.PUD_DOWN, _.NONE])
    if index < 0:
        return

    pin['pud'] = [PUD_UP, PUD_DOWN, PUD_NONE][index]
    for other_pin in pins:
        if other_pin['pin'] == pin['pin'] and other_pin['pud'] != pin['pud']:
            chosen = gui.yes_no(_(_.DIFFERENT_PUD, other_pud=pud_label(other_pin['pud']), this_pud=pud_label(pin['pud'])))
            if not chosen:
                pin['pud'] = other_pin['pud']
            break

    for other_pin in pins:
        if other_pin['pin'] == pin['pin']:
            other_pin['pud'] = pin['pud']

    pins.save()
    gui.refresh()

@plugin.route()
def select_enabled(index):
    pin = pins[int(index)]
    
    if pin['enabled'] == DISABLED and gui.yes_no(_.CONFIRM_ENABLE):
        pin['enabled'] = ENABLED
    elif pin['enabled'] == ENABLED and gui.yes_no(_.CONFIRM_DISABLE):
        pin['enabled'] = DISABLED

    pins.save()
    gui.refresh()

@plugin.route()
def select_function(index):
    pin = pins[int(index)]

    pin['function'] = gui.input(_.FUNCTION, default=pin['function'])
    if not pin['function']:
        return

    pins.save()
    gui.refresh()

@plugin.route()
def restart_service():
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format(ADDON_ID))
    xbmc.sleep(1000)
    xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format(ADDON_ID))
    gui.notification(_.SERVICE_RESTARTED)

@plugin.route()
def reinstall():
    check_install(reinstall=True)