from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    PIN_LABEL         = 30000
    ADD_PIN           = 30001
    SETTINGS          = 30002
    RISING            = 30003
    FALLING           = 30004
    MOVE_UP           = 30005
    MOVE_DOWN         = 30006
    REMOVE_PIN        = 30007
    DISABLED          = 30008
    ENABLE            = 30009
    DISABLE           = 30010
    RESTART_SERVICE   = 30011
    CONFIRM_REMOVE    = 30012
    EDGE              = 30013
    PIN               = 30014
    PIN_RANGE_ERROR   = 30015
    PUD_SELECT        = 30016
    PUD_UP            = 30017
    PUD_DOWN          = 30018
    NONE              = 30019
    FUNCTION          = 30020
    YES               = 30021
    NO                = 30022
    EDIT_PIN          = 30023
    CONFIRM_ENABLE    = 30024
    CONFIRM_DISABLE   = 30025
    SERVICE_RESTARTED = 30027
    CONFIRM_INSTALL   = 30028
    SYSTEM_ERROR      = 30029
    INSTALL_OK        = 30030
    RESTART_REQUIRED  = 30031
    XBIAN_PASSWORD    = 30032
    XBIAN_ERROR       = 30033
    DIFFERENT_PUD     = 30035
    SET_THIS_PUD      = 30036
    SET_OTHERS_PUD    = 30037

_ = Language()