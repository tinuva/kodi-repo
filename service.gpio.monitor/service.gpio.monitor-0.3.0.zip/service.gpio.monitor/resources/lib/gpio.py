import os, sys, subprocess

from collections import defaultdict

import xbmc

from matthuisman import gui, userdata
from matthuisman.constants import ADDON_PATH

from .constants import RISING, FALLING, PUD_UP, PUD_DOWN, PUD_NONE, ENABLED, DISABLED, INSTALLED_KEY
from .language import _

def check_install(reinstall=False):
    if not reinstall:
        if userdata.get(INSTALLED_KEY, False):
            return True

        if not gui.yes_no(_.CONFIRM_INSTALL):
            return False

    restart_required = False
    try:
        if os.path.exists('/storage/.kodi'):
            install_libreelec()
        elif os.path.exists('/home/osmc'):
            install_osmc()
            restart_required = True
        elif os.path.exists('/home/xbian'):
            install_xbian()
            restart_required = True
        else:
            raise Exception(_.SYSTEM_ERROR)
    except Exception as e:
        gui.ok(str(e))
        return False

    userdata.set(INSTALLED_KEY, True)
    if not restart_required:
        gui.notification(_.INSTALL_OK)
        return True

    elif gui.yes_no(_.RESTART_REQUIRED, heading='GPIO Installed'):
        xbmc.executebuiltin('Reboot')
    
    return False

def install_libreelec():
    return

def install_osmc():
    sudo_cmd = 'sudo su -c "{}"'
    install_debian(sudo_cmd, 'osmc')

def install_xbian():
    xbian_password = gui.input(_.XBIAN_PASSWORD, default='raspberry')
    if not xbian_password:
        raise Exception(_.XBIAN_ERROR)

    sudo_cmd = 'echo "{}" | sudo -S su -c "{{}}"'.format(xbian_password)
    install_debian(sudo_cmd, 'xbian')

def install_debian(sudo_cmd, user):
    def cmd(cmd):
        return subprocess.check_output(sudo_cmd.format(cmd), shell=True).strip()

    src_path = os.path.join(ADDON_PATH, 'resources', 'files', '99-gpio.rules')
    dst_path = '/etc/udev/rules.d/99-gpio.rules'

    cmd('groupadd -f -r gpio && adduser {0} gpio && adduser root gpio && rm -f "{2}" && cp "{1}" "{2}"'.format(user, src_path, dst_path))

def service():
    if not check_install():
        return

    pins = userdata.get('pins', [])
    if not pins:
        return

    sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
    import RPi.GPIO as GPIO

    GPIO.setwarnings(False)
    GPIO.cleanup()
    GPIO.setmode(GPIO.BOARD)

    functions = {}

    def callback(pin):
        if GPIO.input(pin):
            edge = RISING
        else: edge = FALLING

        for function in functions[pin].get(edge, []):
            xbmc.executebuiltin(function)

    for pin in pins:
        if not pin['pin'] or not pin['function'] or pin['enabled'] == DISABLED:
            continue

        if pin['pin'] not in functions:
            functions[pin['pin']] = defaultdict(list)

            if pin['pud'] == PUD_NONE:
                 GPIO.setup(pin['pin'], GPIO.IN)
            else:
                GPIO.setup(pin['pin'], GPIO.IN, pull_up_down=GPIO.PUD_UP if pin['pud'] == PUD_UP else GPIO.PUD_DOWN)

            GPIO.remove_event_detect(pin['pin'])
            GPIO.add_event_detect(pin['pin'], GPIO.BOTH, callback=callback)

        functions[pin['pin']][pin['edge']].append(pin['function'])

    monitor = xbmc.Monitor()
    monitor.waitForAbort()

    for pin in functions:
        GPIO.remove_event_detect(pin)

    GPIO.cleanup()