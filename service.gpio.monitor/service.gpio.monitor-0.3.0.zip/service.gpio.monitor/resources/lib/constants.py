RISING = 1
FALLING = 0
PUD_UP = 2
PUD_DOWN = 1
PUD_NONE = 0
ENABLED = 1
DISABLED = 0

INSTALLED_KEY = 'gpio.installed'

DEFAULT_PIN = {
    'pin': 0,
    'edge': FALLING,
    'pud': PUD_UP,
    'enabled': ENABLED,
    'function': '',
}