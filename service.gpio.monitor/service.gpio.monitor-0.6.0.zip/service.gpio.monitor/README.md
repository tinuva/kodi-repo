# service.gpio.monitor

GPIO Monitor service addon for Kodi.

https://www.matthuisman.nz/2016/11/gpio-monitor-service-kodi-add-on.html
