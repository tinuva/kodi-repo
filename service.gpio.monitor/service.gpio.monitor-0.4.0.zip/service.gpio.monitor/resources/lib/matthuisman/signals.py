from collections import defaultdict

from .log import log

_signals = defaultdict(list)

def on(signal):
    def decorator(f):
        _signals[signal].append(f)
        return f
    return decorator

def emit(signal, *args, **kwargs):
    log.debug("SIGNAL: {}".format(signal))
    for f in _signals.get(signal, []):
        f(*args, **kwargs)