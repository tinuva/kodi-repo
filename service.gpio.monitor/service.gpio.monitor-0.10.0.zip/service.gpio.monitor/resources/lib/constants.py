INSTALLED_KEY = 'gpio.installed'

BCM_PINS = [
    2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27
]

COLOR_INACTIVE = 'FFA9A9A9'
COLOR_ACTIVE   = 'FF19f109'
COLOR_DISABLED = 'FFE59400'
COLOR_ERROR    = 'FFFF0000'

FUNCTION_DELIMETER  = '|'
RELOAD_SERVICE_FLAG = 'reload_service'
INSTALLED_FLAG      = '_installed'
AUTO_RELOAD_SETTING = 'auto_reload'