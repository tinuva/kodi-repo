import xbmc

from matthuisman import plugin, gui, cache, settings, database, signals
from matthuisman.constants import ADDON_ID

from .language import _
from .models import Button
from .constants import RELOAD_SERVICE_FLAG, FUNCTION_DELIMETER, INSTALLED_FLAG, AUTO_RELOAD_SETTING
from . import gpio

@plugin.route('')
def home():
    folder = plugin.Folder(cacheToDisc=False)

    if not settings.getBool(INSTALLED_FLAG, False):
        folder.add_item(
            label = _(_.INSTALL_SERVICE, _bold=True), 
            path  = plugin.url_for(install_service),
            info  = {'plot': _.INSTALL_SERVICE_DESC},
        )
        return folder

    btns = list(Button.select())

    for btn in btns:
        label, description = btn.label()

        item = plugin.Item(
            label = label,
            info  = {'plot': description},
            path  = plugin.url_for(view_btn, id=btn.id),
        )
        
        item.context.append((_.DELETE_BTN, 'XBMC.RunPlugin({})'.format(plugin.url_for(delete_btn, id=btn.id))))

        folder.add_items([item])

    folder.add_item(
        label = _(_.ADD_BTN, _bold=len(btns) == 0), 
        path  = plugin.url_for(add_btn),
        info  = {'plot': _.ADD_BTN_DESC},
    )

    if not settings.getBool(AUTO_RELOAD_SETTING, False):
        folder.add_item(
            label = _.RELOAD_SERVICE, 
            path  = plugin.url_for(reload_service),
            info  = {'plot': _.RELOAD_SERVICE_DESC},
        )

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def add_btn():
    btn = Button(enabled=True)
    if not btn.select_pin():
        return

    btn.save()
    _on_btn_change()

@plugin.route()
def view_btn(id):
    btn = Button.get_by_id(id)

    folder = plugin.Folder(title=btn.pin_label, cacheToDisc=False)

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_PIN,  value=btn.pin_label),          
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_pin'),
        info  = {'plot': _.BTN_PIN_DESC},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_WHEN_PRESSED, value=btn.when_pressed),
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_when_pressed'),
        info  = {'plot': _(_.BTN_WHEN_PRESSED_DESC, delimiter=FUNCTION_DELIMETER)},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_WHEN_RELEASED, value=btn.when_released),
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_when_released'),
        info  = {'plot': _(_.BTN_WHEN_RELEASED_DESC, delimiter=FUNCTION_DELIMETER)},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_WHEN_HELD, value=btn.when_held),
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_when_held'),
        info  = {'plot': _(_.BTN_WHEN_HELD_DESC, delimiter=FUNCTION_DELIMETER)},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_NAME, value=btn.name),
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_name'),
        info  = {'plot': _.BTN_NAME_DESC},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_ENABLED, value=btn.enabled),
        path  = plugin.url_for(edit_btn, id=btn.id, method='toggle_enabled'),
        info  = {'plot': _.BTN_ENABLED_DESC},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_PULLUP, value=btn.pull_up),
        path  = plugin.url_for(edit_btn, id=btn.id, method='toggle_pull_up'),
        info  = {'plot': _.BTN_PULLUP_DESC},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_BOUNCE_TIME, value=btn.bounce_time),
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_bounce_time'),
        info  = {'plot': _.BTN_BOUNCE_TIME_DESC},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_HOLD_TIME, value=btn.hold_time),
        path  = plugin.url_for(edit_btn, id=btn.id, method='select_hold_time'),
        info  = {'plot': _.BTN_HOLD_TIME_DESC},
    )

    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_HOLD_REPEAT, value=btn.hold_repeat),
        path  = plugin.url_for(edit_btn, id=btn.id, method='toggle_hold_repeat'),
        info  = {'plot': _.BTN_HOLD_REPEAT_DESC},
    )

    if not settings.getBool(AUTO_RELOAD_SETTING, False):
        folder.add_item(
            label = _.RELOAD_SERVICE, 
            path  = plugin.url_for(reload_service),
            info  = {'plot': _.RELOAD_SERVICE_DESC},
        )

    label, desc = btn.status_label()
    folder.add_item(
        label = _(_.BTN_OPTION, option=_.BTN_STATUS, value=label,),
        is_folder = False,
        info  = {'plot': desc},
    )

    return folder

@plugin.route()
def edit_btn(id, method):
    btn = Button.get_by_id(id)
    if getattr(btn, method)():
        btn.save()
        _on_btn_change()

@plugin.route()
def delete_btn(id):
    btn = Button.get_by_id(id)
    if gui.yes_no(_.CONFIRM_DELETE_BTN) and btn.delete_instance():
        _on_btn_change()

@plugin.route()
def reload_service():
    _reload_service()

@plugin.route()
def install_service():
    with gui.progress(_.INSTALL_SERVICE, percent=100) as progress:
        gpio.install()

    settings.setBool(INSTALLED_FLAG, True)

    if gui.yes_no(_.RESTART_REQUIRED):
        plugin.reboot()

def _on_btn_change():
    if settings.getBool(AUTO_RELOAD_SETTING, False):
        _reload_service()

    gui.refresh()

@signals.on(signals.AFTER_RESET)
def _reload_service():
    database.close()
    
    with gui.progress(_.RELOAD_SERVICE, percent=100) as progress:
        xbmc.executebuiltin('Skin.SetString({},{})'.format(ADDON_ID, RELOAD_SERVICE_FLAG))

        for i in range(5):
            xbmc.sleep(1000)
            if xbmc.getInfoLabel('Skin.String({})'.format(ADDON_ID)) != RELOAD_SERVICE_FLAG:
                break