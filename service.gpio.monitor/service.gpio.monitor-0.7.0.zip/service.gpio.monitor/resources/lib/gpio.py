import os, sys, subprocess

import xbmc

from matthuisman import gui, database, settings
from matthuisman.constants import ADDON_PATH, ADDON_ID, ADDON_DEV
from matthuisman.log import log

from .constants import FUNCTION_DELIMETER, RELOAD_SERVICE_FLAG, INSTALLED_FLAG
from .language import _
from .models import Button

def install():        
    if os.path.exists('/storage/.kodi'):
        install_libreelec()
    elif os.path.exists('/home/osmc'):
        install_osmc()
    elif os.path.exists('/home/xbian'):
        install_xbian()
    else:
        raise Exception(_.SYSTEM_ERROR)

def install_libreelec():
    return

def install_osmc():
    sudo_cmd = 'sudo su -c "{}"'
    install_debian(sudo_cmd, 'osmc')

def install_xbian():
    password = gui.input(_.XBIAN_PASSWORD, default='raspberry')
    sudo_cmd = 'echo "{}" | sudo -S su -c "{{}}"'.format(password)

    try:
        install_debian(sudo_cmd, 'xbian')
    except Exception as e:
        log.exception(e)
        raise Exception(_.XBIAN_ERROR)

def install_debian(sudo_cmd, user):
    def cmd(cmd):
        return subprocess.check_output(sudo_cmd.format(cmd), shell=True).strip()

    src_path = os.path.join(ADDON_PATH, 'resources', 'files', '99-gpio.rules')
    dst_path = '/etc/udev/rules.d/99-{}.GPIO.rules'.format(ADDON_ID)
    cmd('groupadd -f -r gpio && adduser {0} gpio && adduser root gpio && rm -f "{2}" && cp "{1}" "{2}"'.format(user, src_path, dst_path))

def service():
    sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
    import gpiozero

    try:
        from gpiozero.pins.rpigpio import RPiGPIOFactory as Factory
    except ImportError:
        if ADDON_DEV:
            log.debug('Using MockFactory')
            from gpiozero.pins.mock import MockFactory as Factory
        else:
            raise

    gpiozero.Device.pin_factory = Factory()

    def callback(function):
        for function in function.split(FUNCTION_DELIMETER):
            xbmc.executebuiltin(function.strip())

    def setup_buttons():
        if not settings.getBool(INSTALLED_FLAG, False):
            return []

        try:
            database.connect()

            Button.update(status=Button.Status.INACTIVE, error=None).where(Button.enabled == True).execute()
            Button.update(status=Button.Status.DISABLED, error=None).where(Button.enabled == False).execute()
            btns = list(Button.select().where(Button.enabled == True))

            buttons = []
            for btn in btns:
                if not btn.has_callbacks():
                    continue

                try:
                    button = gpiozero.Button(btn.pin, pull_up=btn.pull_up, 
                        bounce_time=btn.bounce_time or None, hold_time=btn.hold_time, hold_repeat=btn.hold_repeat)

                    if btn.when_pressed:
                        button.when_pressed  = lambda: callback(btn.when_pressed)
                    if btn.when_released:
                        button.when_released = lambda: callback(btn.when_released)
                    if btn.when_held:
                        button.when_held     = lambda: callback(btn.when_held)
                except Exception as e:
                    log.exception(e)
                    btn.status = Button.Status.ERROR
                    btn.error  = e
                else:
                    btn.status = Button.Status.ACTIVE            
                    buttons.append(button)
                    
                btn.save()

            return buttons
        except Exception as e:
            log.debug(e)
            return []
        finally:
            database.close()

    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        buttons = setup_buttons()

        xbmc.executebuiltin('Skin.SetString({},)'.format(ADDON_ID))
        while not monitor.abortRequested():
            if not monitor.waitForAbort(1) and xbmc.getInfoLabel('Skin.String({})'.format(ADDON_ID)) == RELOAD_SERVICE_FLAG:
                break
                
        for button in buttons:
            button.close()

    gpiozero.Device.pin_factory.close()