class GeoError(Exception):
    pass

class LoginError(Exception):
    pass

class ViewError(Exception):
    pass

class ComsError(Exception):
    pass

class InputError(Exception):
    pass

class ServiceError(Exception):
    pass

class RouterError(Exception):
    pass

class WVError(Exception):
    pass
    