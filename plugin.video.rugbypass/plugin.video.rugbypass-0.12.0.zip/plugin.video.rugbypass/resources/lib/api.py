import time
import json
from datetime import datetime

import requests
requests.packages.urllib3.disable_warnings()

from matthuisman.util import log
from matthuisman.exceptions import LoginError, ComsError, GeoError

from . import config
from .models import Game

class API(object):
    def __init__(self, addon):
        self._addon = addon

        self._session = requests.session()
        self._session.headers.update(config.HEADERS)
        self._session.cookies.update(self._addon.data.get('cookies', {}))

        self._logged_in = self._addon.data.get('nllinktoken') != None

    @property
    def logged_in(self):
        return self._logged_in

    def _parse_game(self, item):
        epoch = datetime.utcfromtimestamp(0)

        def get_date(date, default=None):
            if not date:
                return default

            try:
                d = datetime.strptime(date, '%Y-%m-%dT%H:%M:%S.000')
            except TypeError:
                d = datetime(*(time.strptime(date, '%Y-%m-%dT%H:%M:%S.000')[0:6]))

            return int((d - epoch).total_seconds())

        info = {'home': item['homeTeam'], 'away': item['awayTeam']}
        game = Game(id=int(item['id']), state=int(item['gameState']), start=int(get_date(item['dateTimeGMT'], 0)), 
            end=int(get_date(item.get('endDateTimeGMT'), 0)), slug=str(item['seoName']), info=info)

        return game

    def update_games(self):
        return self.recent_games()

    def fetch_game(self, slug):
        data = self._request('GET', '/game/{0}'.format(slug), params={'format':'json'})
        return self._parse_game(data)
        
    def recent_games(self, date=None):
        games = []

        data = self._request('GET', '/scoreboard', params={'format':'json'})['games']
        for item in data:
            game = self._parse_game(item)
            games.append(game)

        return games

    def _close_session(self):
        self._addon.data.pop('cookies', None)
        self._session.cookies.clear()

    def logout(self):
        self._request('POST', '/service/logout', data={'format': 'json'})
        self._addon.data.pop('nllinktoken', None)
        self._logged_in = False
        self._close_session()

    def _request(self, _type, url, **kwargs):
        proxy = config.MJH_PROXY if self._addon.settings.getBool('mjh_proxy') else None

        try:
            return self._do_request(_type, url, **kwargs)
        except GeoError:
            if not proxy:
                raise

        try:
            self._do_request('GET', '/service/checkgames', params={'format':'json'}, timeout=10, proxies={'https': proxy}, verify=False)
            self._addon.data['cookies'] = self._session.cookies.get_dict()
        except:
            pass

        return self._do_request(_type, url, **kwargs)

    def _do_request(self, _type, url, retries=2, **kwargs):
        url = config.BASE_API.format(url)

        for i in range(retries):
            log.debug('{0} {1} {2}'.format(_type, url, kwargs))
            r = self._session.request(_type, url, **kwargs)
            data = r.json()
            if r.status_code == 200 and data:
                break

        if not data: 
            raise ComsError("No data returned.")

        if type(data) == dict and data.get('code','') == 'failedgeo':
            raise GeoError("Geo Restricted")

        return data

    def login(self, username, password):
        data = {
            'username': username,
            'password': password,
            'cookielink': 'true',
            'format': 'json',
        }

        r = self._request('POST', '/secure/authenticate', data=data)
        nllinktoken = self._session.cookies.get_dict().pop('nllinktoken', None)
        if r.get('code') != 'loginsuccess' or not nllinktoken:
            self._addon.data.pop('nllinktoken', None)
            self._logged_in = False
            raise LoginError("Failed to login: '{0}'".format(r.get('code')))

        self._addon.data['nllinktoken'] = nllinktoken
        self._close_session()

    def get_play_url(self, game, stream_type):
        payload = {
            'id': game.id,
            'gs': game.state,
            'gt': stream_type,
            'type': 'game',
            'format': 'json',
        }

        if game.state == Game.PROCESSING:
            payload['st'] = game.start * 1000
            payload['dur'] = game.duration * 1000

        try:
            login_cookies = {'nllinktoken': self._addon.data.get('nllinktoken'), 'UserName': self._addon.data.get('username')}
            data = self._request('POST', '/service/publishpoint', data=payload, cookies=login_cookies)
            if not data.get('path'):
                raise ComsError
        except ComsError as e:
            raise ComsError("{0}\nCheck your RugbyPass subscription is current.".format(e))
        else:
            return data['path']
        finally:
            self._close_session()