from resources.lib import config
from resources.lib.matthuisman.service import Service

Service().run(config.POLL_TIME)