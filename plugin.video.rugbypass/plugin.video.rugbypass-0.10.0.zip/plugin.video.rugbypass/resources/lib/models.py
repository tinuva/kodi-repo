import json
from datetime import datetime, timedelta

from . import config
from matthuisman import peewee, models

class Game(models.Model):
    FULL = 1
    CONDENSED = 8

    UPCOMING = 0   #Not yet played
    LIVE = 1       #Live
    PROCESSING = 2 #Can re-watch entire live stream
    PLAYED = 3     #Can watch full and condensend game

    id    = peewee.IntegerField(primary_key=True)
    slug  = peewee.TextField(unique=True)
    state = peewee.IntegerField(index=True)
    start = peewee.IntegerField()
    end   = peewee.IntegerField()
    info  = models.PickledField()

    @property
    def result(self):
        home = self.info['home']
        away = self.info['away']

        if home['score'] == '' or away['score'] == '':
            return ''
        if int(home['score']) == int(away['score']):
            return 'A draw ({0} all)'.format(home['score'])
        elif int(home['score']) > int(away['score']):
            return '{0} win {1} to {2}'.format(home['name'], home['score'], away['score'])
        else:
            return '{0} win {1} to {2}'.format(away['name'], away['score'], home['score'])

    def description(self, show_hours):
        description = '{0} host {1}\n{2}'.format(self.info['home']['name'], self.info['away']['name'], self.kickoff)

        result = self.result
        if result and show_hours != -1 and datetime.fromtimestamp(self.start) < datetime.now() - timedelta(hours=show_hours):
            description = '{0}\n\n{1}'.format(description, result)
        
        return description

    @property
    def kickoff(self):
        return 'Kick-off: {0}'.format(datetime.fromtimestamp(self.start).strftime('%I:%M%p %d/%m/%Y').lstrip("0").replace(" 0", " "))

    @property
    def duration(self):
        if self.end == 0: 
            return None
        return self.end - self.start

    @property
    def playable(self):
        return self.state in (Game.LIVE, Game.PROCESSING, Game.PLAYED)

    @property
    def title(self):
        return '{0} vs {1}'.format(self.info['home']['name'], self.info['away']['name'])

    @property
    def image(self):
        return config.IMG_URL.format(self.info['home']['code'])

class Alert(object):
    NOTIFICATION = 0
    DIALOG = 1

    STREAM_START = 0
    KICK_OFF = 1