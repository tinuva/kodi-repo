from time import time

from matthuisman import settings, plugin, database, cache, gui, userdata, inputstream, util, signals

from .constants import SERVICE_TIME, GAMES_EXPIRY, GAMES_CACHE_KEY
from .api import API, UserAPI
from .models import Game, Alert
from .language import _

if settings.FRESH and util.get_kodi_version() >= 18:
    settings.setBool('use_ia_hls', True)

api  = API()
user = UserAPI()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    user.new_session()
    plugin.logged_in = user.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not user.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login))
    else:
        folder.add_item(label=_(_.LIVE, _bold=True), path=plugin.url_for(live), cache_key=GAMES_CACHE_KEY)
        folder.add_item(label=_(_.PLAYED, _bold=True), path=plugin.url_for(played), cache_key=GAMES_CACHE_KEY)
        folder.add_item(label=_(_.UPCOMING, _bold=True), path=plugin.url_for(upcoming), cache_key=GAMES_CACHE_KEY)
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout))
        
    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def login():
    while not user.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD, default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        try:
            user.login(username=username, password=password)
            gui.refresh()
        except Exception as e:
            gui.ok(_(_.LOGIN_ERROR, error_msg=e))

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    user.logout()
    gui.refresh()

@plugin.route()
def live():
    return show_games(Game.state == Game.LIVE, title=_.LIVE)

@plugin.route()
def played():
    return show_games(Game.state << (Game.PROCESSING, Game.PLAYED), title=_.PLAYED)

@plugin.route()
def upcoming():
    return show_games(Game.state == Game.UPCOMING, order_by=Game.start.asc(), title=_.UPCOMING)

@plugin.route()
def alerts(slug):
    game   = get_game(slug)
    alerts = userdata.get('alerts', [])

    if game.id not in alerts:
        alerts.append(game.id)
        gui.notification(_.REMINDER_SET, heading=game.title, icon=game.image)
    else:
        alerts.remove(game.id)
        gui.notification(_.REMINDER_REMOVED, heading=game.title, icon=game.image)

    userdata.set('alerts', alerts)
    gui.refresh()

@plugin.route()
def show_score(slug):
    game = get_game(slug)
    gui.ok(heading=game.title, message=game.result)

@plugin.route()
def play(slug, game_type, from_start=None):
    game = get_game(slug)
    return _get_play_item(game, game_type, from_start)

@plugin.login_required()
def _get_play_item(game, game_type, from_start=None):
    item = parse_game(game)

    try:
        item.path = user.get_play_url(game, game_type)
    except:
        raise plugin.Error(_.ERROR_PLAY_GAME)

    if from_start:
        item.properties['ResumeTime'] = '1'
        item.properties['TotalTime']  = '1'

    item.inputstream = inputstream.HLS()

    return item

@signals.on(signals.ON_SERVICE)
def service():
    if not settings.getBool('use_service'):
        return

    games = update_games()
    check_alerts(games)

def show_games(query, order_by=None, title=None):
    folder = plugin.Folder(title=title)

    if not order_by:
        order_by = Game.start.desc()

    if not cache.get(GAMES_CACHE_KEY):
        update_games()

    games = Game.select().where(query).order_by(order_by)
    items = [parse_game(game) for game in games]

    if items:
        folder.add_items(items)
    else:
        folder.add_item(label=_(_.NO_GAMES, _label=True), is_folder=False)

    return folder

def update_games():
    games = api.update_games()

    Game.truncate()
    Game.insert_many([game.to_dict() for game in games])
    
    cache.set(GAMES_CACHE_KEY, True, expires=GAMES_EXPIRY)
    return games

def get_game(slug):
    game = Game.get_or_none(Game.slug == slug)
    if not game:
        try:
            game = api.fetch_game(slug)
            game.save()
        except:
            raise plugin.Error(_.ERROR_GAME_NOT_FOUND)

    return game

def parse_game(game):
    item = plugin.Item(
        label     = game.title,
        is_folder = False,
        playable  = game.state != Game.UPCOMING,
        art       = {'thumb': game.image},
        info      = {
            'title':    game.title,
            'plot':     game.description,
            'duration': game.duration,
            'aired':    game.aired,
        }
    )

    if game.state == Game.UPCOMING and settings.getBool('use_service'):
        item.path = plugin.url_for(alerts, slug=game.slug)

        if game.id not in userdata.get('alerts', []):
            item.info['playcount'] = 0
            item.context.append((_.SET_REMINDER, "XBMC.RunPlugin({0})".format(item.path)))
        else:
            item.info['playcount'] = 1
            item.context.append((_.REMOVE_REMINDER, "XBMC.RunPlugin({0})".format(item.path)))

    elif game.state == Game.LIVE:
        item.path = plugin.url_for(play, is_live=True, slug=game.slug, game_type=Game.FULL)
        item.context.append((_.WATCH_LIVE, "XBMC.PlayMedia({0})".format(item.path)))

        if settings.getBool('use_ia_hls'):
            item.context.append((_.WATCH_FROM_START, "XBMC.PlayMedia({0})".format(
                plugin.url_for(play, is_live=True, slug=game.slug, game_type=Game.FULL, from_start=True)
            )))

    elif game.state == Game.PROCESSING:
        item.path = plugin.url_for(play, slug=game.slug, game_type=Game.FULL)
        item.context.append((_.FULL_GAME, "XBMC.PlayMedia({0})".format(item.path)))

    elif game.state == Game.PLAYED:
        item.path = plugin.url_for(play, slug=game.slug, game_type=Game.FULL)
        item.context.append((_.FULL_GAME, "XBMC.PlayMedia({0})".format(item.path)))
        item.context.append((_.CONDENSED_GAME, "XBMC.PlayMedia({0})".format(
            plugin.url_for(play, slug=game.slug, game_type=Game.CONDENSED)
        )))

    if game.result:
        item.context.append((_.SHOW_SCORE, "XBMC.RunPlugin({0})".format(
            plugin.url_for(show_score, slug=game.slug)
        )))

    return item

def check_alerts(games):
    alerts = userdata.get('alerts', [])
    if not alerts: return
    
    games = [g for g in games if g.id in alerts]

    alerts = []
    for game in games:
        if game.state == Game.UPCOMING:
            alerts.append(game.id)
            continue

        if game.state == Game.LIVE:
            _to_start = game.start - time()
            
            if settings.getInt('alert_when') == Alert.STREAM_START:
                message = _.STREAM_STARTED
            elif settings.getInt('alert_when') == Alert.KICK_OFF and _to_start > 0 and _to_start <= SERVICE_TIME:
                message = _.KICKOFF
            else: 
                continue

            if settings.getInt('alert_type') == Alert.NOTIFICATION:
                gui.notification(message, heading=game.title, time=5000, icon=game.image)

            elif gui.yes_no(message, heading=game.title, yeslabel=_.WATCH, nolabel=_.CLOSE):
                _get_play_item(game, Game.FULL).play()
 
    userdata.set('alerts', alerts)