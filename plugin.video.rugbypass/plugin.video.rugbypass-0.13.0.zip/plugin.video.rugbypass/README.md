# plugin.video.rugbypass

Unofficial 3rd party RugbyPass.com plugin for Kodi.

https://www.matthuisman.nz/2017/08/rugbypass-kodi-add-on.html
