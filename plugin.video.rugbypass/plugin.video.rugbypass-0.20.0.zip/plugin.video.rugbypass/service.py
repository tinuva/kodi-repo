import xbmc

monitor = xbmc.Monitor()
while not monitor.abortRequested():
    xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.rugbypass/?_=_service)')
    if monitor.waitForAbort(270):
        break