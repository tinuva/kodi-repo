from datetime import datetime, timedelta

from matthuisman import peewee, database, settings

from .constants import IMG_URL
from .language import _

class Game(database.Model):
    FULL = 1
    CONDENSED = 8

    UPCOMING = 0   #Not yet played
    LIVE = 1       #Live
    PROCESSING = 2 #Can re-watch entire live stream
    PLAYED = 3     #Can watch full and condensend game

    slug  = peewee.TextField(unique=True)
    state = peewee.IntegerField(index=True)
    start = peewee.IntegerField()
    end   = peewee.IntegerField()
    info  = database.PickledField()

    @property
    def result(self):
        home = self.info['home']
        away = self.info['away']

        if home['score'] == '' or away['score'] == '':
            return None
        if int(home['score']) == int(away['score']):
            return _(_.A_DRAW, win_team=home['name'], win_score=home['score'], lose_team=away['name'], lose_score=away['score'])
        elif int(home['score']) > int(away['score']):
            return _(_.X_WINS, win_team=home['name'], win_score=home['score'], lose_team=away['name'], lose_score=away['score'])
        else:
            return _(_.X_WINS, win_team=away['name'], win_score=away['score'], lose_team=home['name'], lose_score=home['score'])

    @property
    def aired(self):
        return datetime.fromtimestamp(self.start).isoformat()

    @property
    def description(self):
        home = self.info['home']
        away = self.info['away']
        show_hours = settings.getInt('show_hours') if settings.getBool('show_score') else -1

        result = ''
        if home['score'] and away['score'] and show_hours != -1 and datetime.fromtimestamp(self.start) < datetime.now() - timedelta(hours=show_hours):
            result = self.result

        return _(_.GAME_DESC, home_team=home['name'], away_team=away['name'], kick_off=self.kickoff, result=result)

    @property
    def kickoff(self):
        return _(_.KICK_OFF, date_time=datetime.fromtimestamp(self.start).strftime('%I:%M%p %d/%m/%Y').lstrip("0").replace(" 0", " "))

    @property
    def duration(self):
        if self.end == 0: 
            return None
        return self.end - self.start

    @property
    def playable(self):
        return self.state in (Game.LIVE, Game.PROCESSING, Game.PLAYED)

    @property
    def title(self):
        return _(_.GAME_TITLE, home_team=self.info['home']['name'], away_team=self.info['away']['name'])

    @property
    def image(self):
        return IMG_URL.format(self.info['home']['code'])

class Alert(object):
    DIALOG = 0
    NOTIFICATION = 1

    STREAM_START = 0
    KICK_OFF = 1

database.tables.append(Game)