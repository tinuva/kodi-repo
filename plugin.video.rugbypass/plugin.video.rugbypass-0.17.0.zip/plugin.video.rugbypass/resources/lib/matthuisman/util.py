import time
import hashlib
from datetime import datetime

import xbmc

from .constants import ADDON
from .log import log

def hash_6(value, default=None):
    if not value:
        return default

    h = hashlib.md5(str(value))
    return h.digest().encode('base64')[:6]

def get_kodi_version():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split('.')[0])
    except:
        return 0

def strptime(date, str_format):
    try:
        return datetime.strptime(date, str_format)
    except TypeError:
        return datetime(*(time.strptime(date, str_format)[0:6]))

def format_string(string, _bold=False, _label=False, _color=None, _strip=True, **kwargs):
    if kwargs:
        string = string.format(**kwargs)

    if _strip:
        string = string.strip()

    if _label:
        _bold = True
        string = u'~ {} ~'.format(string)

    if _bold:
        string = u'[B]{}[/B]'.format(string)

    if _color:
        string = u'[COLOR {}]{}[/COLOR]'.format(_color, string)
        
    return string