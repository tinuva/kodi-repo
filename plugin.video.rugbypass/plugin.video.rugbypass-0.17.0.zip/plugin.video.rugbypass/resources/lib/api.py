from datetime import datetime

from matthuisman import settings, userdata
from matthuisman.session import Session
from matthuisman.util import strptime

from .constants import HEADERS, MJH_PROXY, API_URL
from .models import Game

class Error(Exception):
    pass

class GeoError(Exception):
    pass

class API(object):
    _cookies_key = '_cookies'

    def new_session(self):
        self._session = Session(HEADERS, cookies_key=self._cookies_key, base_url=API_URL)

    def _parse_game(self, item):
        epoch = datetime.utcfromtimestamp(0)

        def get_date(date, default=None):
            if not date:
                return default

            d = strptime(date, '%Y-%m-%dT%H:%M:%S.000')
            return int((d - epoch).total_seconds())

        info = {'home': item['homeTeam'], 'away': item['awayTeam']}
        game = Game(id=int(item['id']), state=int(item['gameState']), start=int(get_date(item['dateTimeGMT'], 0)), 
            end=int(get_date(item.get('endDateTimeGMT'), 0)), slug=str(item['seoName']), info=info)

        return game

    def update_games(self):
        return self.recent_games()

    def fetch_game(self, slug):
        data = self._request('GET', 'game/{0}'.format(slug), params={'format':'json'})
        return self._parse_game(data)
        
    def recent_games(self, date=None):
        games = []

        data = self._request('GET', 'scoreboard', params={'format':'json'})['games']
        for item in data:
            game = self._parse_game(item)
            games.append(game)

        return games

    def _request(self, _type, url, **kwargs):
        proxy = MJH_PROXY if settings.getBool('mjh_proxy') else None

        try:
            return self._do_request(_type, url, **kwargs)
        except GeoError:
            if not proxy:
                raise

        self._do_request('GET', 'service/checkgames', params={'format':'json'}, timeout=10, proxies={'https': proxy}, verify=False)
        self._session.save_cookies()
        return self._do_request(_type, url, **kwargs)

    def _do_request(self, _type, url, **kwargs):
        data = self._session.request(_type, url, **kwargs).json()
        if data.get('code','') == 'failedgeo':
            raise GeoError()

        return data

class UserAPI(API):
    _cookies_key = 'user_cookies'

    @property
    def logged_in(self):
        return self._session.cookies.get('nllinktoken') != None

    def login(self, username, password):
        data = {
            'username': username,
            'password': password,
            'cookielink': 'true',
            'format': 'json',
        }

        r = self._request('POST', 'secure/authenticate', data=data)
        if r.get('code') != 'loginsuccess':
            raise Error(r.get('code'))

        self._session.save_cookies()

    def get_play_url(self, game, stream_type):
        payload = {
            'id': game.id,
            'gs': game.state,
            'gt': stream_type,
            'type': 'game',
            'format': 'json',
        }

        if game.state == Game.PROCESSING:
            payload['st'] = game.start * 1000
            payload['dur'] = game.duration * 1000

        return self._request('POST', 'service/publishpoint', data=payload)['path']

    def logout(self):
        self._request('POST', 'service/logout', data={'format': 'json'})
        self._session.cookies.clear()
        self._session.save_cookies()