from time import time

from matthuisman import settings, plugin, database, cache, gui, userdata, inputstream, util
from matthuisman.util import get_string as _

from .constants import SERVICE_TIME, GAMES_EXPIRY, GAMES_CACHE_KEY
from .api import API, UserAPI
from .models import Game, Alert

L_LOGIN                = 30000
L_LIVE                 = 30001
L_PLAYED               = 30002
L_UPCOMING             = 30003
L_LOGOUT               = 30004
L_SETTINGS             = 30005
L_ASK_USERNAME         = 30006
L_ASK_PASSWORD         = 30007
L_LOGIN_ERROR          = 30008
L_LOGOUT_YES_NO        = 30009
L_REMINDER_SET         = 30010
L_REMINDER_REMOVED     = 30011
L_ERROR_PLAY_GAME      = 30012
L_NO_GAMES             = 30013
L_ERROR_GAME_NOT_FOUND = 30014
L_SET_REMINDER         = 30015
L_REMOVE_REMINDER      = 30016
L_WATCH_LIVE           = 30017
L_WATCH_FROM_START     = 30018
L_FULL_GAME            = 30019
L_CONDENSED_GAME       = 30020
L_SHOW_SCORE           = 30021
L_STREAM_STARTED       = 30022
L_KICKOFF              = 30023
L_WATCH                = 30024
L_CLOSE                = 30025

if settings.FRESH and util.get_kodi_version() >= 18:
    settings.setBool('use_ia_hls', True)

api  = API()
user = UserAPI()

@plugin.before_dispatch()
def before_dispatch():
    database.check_table(Game)

    api.new_session()
    user.new_session()

    plugin.logged_in = user.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not user.logged_in:
        folder.add_item(label=_(L_LOGIN, bold=True), path=plugin.url_for(login))
    else:
        folder.add_item(label=_(L_LIVE, bold=True), path=plugin.url_for(live), cache_key=GAMES_CACHE_KEY)
        folder.add_item(label=_(L_PLAYED, bold=True), path=plugin.url_for(played), cache_key=GAMES_CACHE_KEY)
        folder.add_item(label=_(L_UPCOMING, bold=True), path=plugin.url_for(upcoming), cache_key=GAMES_CACHE_KEY)
        folder.add_item(label=_(L_LOGOUT), path=plugin.url_for(logout))
        
    folder.add_item(label=_(L_SETTINGS), path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def login():
    while not user.logged_in:
        username = gui.input(_(L_ASK_USERNAME), default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_(L_ASK_PASSWORD), default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        try:
            user.login(username=username, password=password)
            gui.refresh()
        except Exception as e:
            gui.ok(_(L_LOGIN_ERROR, error_msg=e))

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_(L_LOGOUT_YES_NO)):
        return

    user.logout()
    gui.refresh()

@plugin.route()
def live():
    return show_games(Game.state == Game.LIVE, title=_(L_LIVE))

@plugin.route()
def played():
    return show_games(Game.state << (Game.PROCESSING, Game.PLAYED), title=_(L_PLAYED))

@plugin.route()
def upcoming():
    return show_games(Game.state == Game.UPCOMING, order_by=Game.start.asc(), title=_(L_UPCOMING))

@plugin.route()
def alerts(slug):
    game   = get_game(slug)
    alerts = userdata.get('alerts', [])

    if game.id not in alerts:
        alerts.append(game.id)
        gui.notification(_(L_REMINDER_SET), heading=game.title, icon=game.image)
    else:
        alerts.remove(game.id)
        gui.notification(_(L_REMINDER_REMOVED), heading=game.title, icon=game.image)

    userdata.set('alerts', alerts)
    gui.refresh()

@plugin.route()
def show_score(slug):
    game = get_game(slug)
    gui.ok(heading=game.title, message=game.result)

@plugin.service()
def service():
    if not settings.getBool('use_service'):
        return

    games = update_games()
    check_alerts(games)

def show_games(query, order_by=None, title=None):
    folder = plugin.Folder(title=title)

    if not order_by:
        order_by = Game.start.desc()

    if not cache.get(GAMES_CACHE_KEY):
        update_games()

    games = Game.select().where(query).order_by(order_by)
    items = [parse_game(game) for game in games]

    if items:
        folder.add_items(items)
    else:
        folder.add_item(label=_(L_NO_GAMES, label=True), is_folder=False)

    return folder

def update_games():
    games = api.update_games()
    Game.replace_many([game.to_dict() for game in games])
    cache.set(GAMES_CACHE_KEY, True, expires=GAMES_EXPIRY)
    return games

def get_game(slug):
    game = Game.get_or_none(Game.slug == slug)
    if not game:
        try:
            game = api.fetch_game(slug)
            game.save()
        except:
            raise plugin.Error(_(L_ERROR_GAME_NOT_FOUND))

    return game

def parse_game(game):
    item = plugin.Item(
        label     = game.title,
        is_folder = False,
        playable  = game.state != Game.UPCOMING,
        art       = {'thumb': game.image},
        info      = {
            'title':    game.title,
            'plot':     game.description,
            'duration': game.duration,
            'aired':    game.aired,
        }
    )

    if game.state == Game.UPCOMING and settings.getBool('use_service'):
        item.path = plugin.url_for(alerts, slug=game.slug)

        if game.id not in userdata.get('alerts', []):
            item.info['playcount'] = 0
            item.context.append((_(L_SET_REMINDER), "XBMC.RunPlugin({0})".format(item.path)))
        else:
            item.info['playcount'] = 1
            item.context.append((_(L_REMOVE_REMINDER), "XBMC.RunPlugin({0})".format(item.path)))

    elif game.state == Game.LIVE:
        item.path = plugin.url_for(play, is_live=True, slug=game.slug, game_type=Game.FULL)
        item.context.append((_(L_WATCH_LIVE), "XBMC.PlayMedia({0})".format(item.path)))

        if settings.getBool('use_ia_hls'):
            item.context.append((_(L_WATCH_FROM_START), "XBMC.PlayMedia({0})".format(
                plugin.url_for(play, is_live=True, slug=game.slug, game_type=Game.FULL, from_start=True)
            )))

    elif game.state == Game.PROCESSING:
        item.path = plugin.url_for(play, slug=game.slug, game_type=Game.FULL)
        item.context.append((_(L_FULL_GAME), "XBMC.PlayMedia({0})".format(item.path)))

    elif game.state == Game.PLAYED:
        item.path = plugin.url_for(play, slug=game.slug, game_type=Game.FULL)
        item.context.append((_(L_FULL_GAME), "XBMC.PlayMedia({0})".format(item.path)))
        item.context.append((_(L_CONDENSED_GAME), "XBMC.PlayMedia({0})".format(
            plugin.url_for(play, slug=game.slug, game_type=Game.CONDENSED)
        )))

    if game.result:
        item.context.append((_(L_SHOW_SCORE), "XBMC.RunPlugin({0})".format(
            plugin.url_for(show_score, slug=game.slug)
        )))

    return item

def check_alerts(games):
    alerts = userdata.get('alerts', [])
    if not alerts: return
    
    games = [g for g in games if g.id in alerts]

    alerts = []
    for game in games:
        if game.state == Game.UPCOMING:
            alerts.append(game.id)
            continue

        if game.state == Game.LIVE:
            _to_start = game.start - time()
            
            if settings.getInt('alert_when') == Alert.STREAM_START:
                message = _(L_STREAM_STARTED)
            elif settings.getInt('alert_when') == Alert.KICK_OFF and _to_start > 0 and _to_start <= SERVICE_TIME:
                message = _(L_KICKOFF)
            else: 
                continue

            if settings.getInt('alert_type') == Alert.NOTIFICATION:
                gui.notification(message, heading=game.title, time=5000, icon=game.image)

            elif gui.dialog_yes_no(message, heading=game.title, yeslabel=_(L_WATCH), nolabel=_(L_CLOSE)):
                _get_play_item(game, Game.FULL).play()
 
    userdata.set('alerts', alerts)

@plugin.route()
def play(slug, game_type, from_start=None):
    game = get_game(slug)
    return _get_play_item(game, game_type, from_start)

@plugin.login_required()
def _get_play_item(game, game_type, from_start=None):
    item = parse_game(game)

    try:
        item.path = user.get_play_url(game, game_type)
    except:
        raise plugin.Error(_(L_ERROR_PLAY_GAME))

    if from_start:
        item.properties['ResumeTime'] = "1"
        item.properties['TotalTime']  = "1"

    item.inputstream = inputstream.HLS()

    return item