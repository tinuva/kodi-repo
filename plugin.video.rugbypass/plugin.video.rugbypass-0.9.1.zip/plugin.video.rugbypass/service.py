#!/usr/bin/env python2.7
from resources.lib import config
from matthuisman.service import Service

Service().run(config.POLL_TIME)