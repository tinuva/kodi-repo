from datetime import datetime
from time import time

from matthuisman.controller import Controller as BaseController
from matthuisman.exceptions import InputError, ViewError, ServiceError
from matthuisman import util

from . import config
from .api import API
from .models import Game, Alert

class Controller(BaseController):
    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self._api = API(self._addon)

        if self._addon.first_run and util.kodi_version() >= 18:
            self._addon.settings.setBool('use_ia_hls', True)

        self._addon.db.check_table(Game)

    def home(self, params):
        items = [
            {'title':'[B]Live[/B]', 'url': self._router.get(self.live)},
            {'title':'[B]Upcoming[/B]', 'url': self._router.get(self.upcoming)},
            {'title':'[B]Played[/B]', 'url': self._router.get(self.played)}
        ]
        
        if not self._api.logged_in:
            items.append({'title':'[B]Login[/B]', 'url': self._router.get(self.login)})
        else:
            items.append({'title':'Logout', 'url': self._router.get(self.logout)})

        items.append({'title':'Settings', 'url': self._router.get(self.settings)})

        self._view.items(items)

    def live(self, params):
        self._show_games(Game.state == Game.LIVE, title='Live')

    def upcoming(self, params):
        self._show_games(Game.state == Game.UPCOMING, order_by=Game.start.asc(), title='Upcoming')

    def played(self, params):
        self._show_games(Game.state << (Game.PROCESSING, Game.PLAYED), title='Played')

    def _show_games(self, query, order_by=None, title=None):
        if not order_by:
            order_by = Game.start.desc()

        if time() - self._addon.data.get('updated', 0) > config.POLL_TIME + 30:
            self._update_games()

        games = Game.select().where(query).order_by(order_by)
        items = [self._parse_game(game) for game in games]
        if not items:
            items.append({'title': '[B]~ No {} Games ~[/B]'.format(title or '')})

        self._view.items(items, title=title)

    def _update_games(self):
        games = self._api.update_games()
        self._save_games(games)
        self._addon.data['updated'] = int(time())
        return games

    def _save_games(self, games):
        Game.replace_many([game.to_dict() for game in games])

    def _get_game(self, slug):
        game = Game.get_or_none(Game.slug == slug)
        if not game:
            try:
                game = self._api.fetch_game(slug)
                self._save_games([game])
            except:
                raise ViewError('Failed to find that game.')

        return game

    def _parse_game(self, game):
        show_hours = self._addon.settings.getInt('show_hours') if self._addon.settings.getBool('show_score') else -1

        info = {
            'title': game.title,
            'plot': game.description(show_hours),
            'duration': game.duration,
            'aired': datetime.fromtimestamp(game.start).isoformat()
        }

        context = []
        if game.state == Game.UPCOMING:
            select_action = self._router.get(self.alerts, {'slug': game.slug})

            if game.id not in self._addon.data.get('alerts', []):
                info['playcount'] = 0
                context.append(["Set Reminder", "XBMC.RunPlugin({0})".format(select_action)])
            else:
                info['playcount'] = 1
                context.append(["Remove Reminder", "XBMC.RunPlugin({0})".format(select_action)])

        elif game.state == Game.LIVE:
            select_action = self._router.get(self.play, {'slug': game.slug, 'type': Game.FULL}, live=True)
            context.append(["Watch Live", "XBMC.PlayMedia({0})".format(select_action)])

            if self._addon.settings.getBool('use_ia_hls'):
                context.append(["Watch from Start", "XBMC.PlayMedia({0})".format(
                    self._router.get(self.play, {'slug': game.slug, 'type': Game.FULL, 'from_start': True}, live=True)
                )])

        elif game.state == Game.PROCESSING:
            select_action = self._router.get(self.play, {'slug': game.slug, 'type': Game.FULL})
            context.append(["Full Game", "XBMC.PlayMedia({0})".format(select_action)])

        elif game.state == Game.PLAYED:
            select_action = self._router.get(self.play, {'slug': game.slug, 'type': Game.FULL})
            context.append(["Full Game", "XBMC.PlayMedia({0})".format(select_action)])
            context.append(["Condensed Game", "XBMC.PlayMedia({0})".format(
                self._router.get(self.play, {'slug': game.slug, 'type': Game.CONDENSED})
            )])

        if game.result:
            context.append(["Show Score", "XBMC.RunPlugin({0})".format(
                self._router.get(self.dialog,  {'heading': game.title, 'message': game.result})
            )])

        item = {
            'title': game.title,
            'playable': game.state != Game.UPCOMING,
            'is_folder': False,
            'url': select_action,
            'images': {'thumb': game.image},
            'info': info,
            'context': context,
            'vid_type': 'hls',
        }

        return item

    def alerts(self, params):
        game = self._get_game(params.get('slug'))
        alerts = self._addon.data.get('alerts', [])

        if game.id not in alerts:
            alerts.append(game.id)
            self._view.notification('Reminder Set', heading=game.title, icon=game.image)
        else:
            alerts.remove(game.id)
            self._view.notification('Reminder Removed', heading=game.title, icon=game.image)

        self._addon.data['alerts'] = alerts
        self._view.refresh()

    def login(self, params):
        self._do_login()
        self._view.refresh()

    def logout(self, params):
        if not self._view.dialog_yes_no("Are you sure you want to logout?"):
            raise InputError()

        self._api.logout()
        self._view.refresh()

    def _do_login(self):
        username = self._view.get_input("RugbyPass Email", default=self._addon.data.get('username', '')).strip()
        if not username:
            raise InputError()

        password = self._view.get_input("RugbyPass Password", hidden=True).strip()
        if not password:
            raise InputError()

        self._addon.data['username'] = username
        self._api.login(username=username, password=password)

    def play(self, params):
        game = self._get_game(params.get('slug'))
        self._play(game, params.get('type'), params.get('from_start'))

    def _play(self, game, _type, from_start=None):
        if not self._api.logged_in:
            self._do_login()
        
        item = self._parse_game(game)
        item['url'] = self._api.get_play_url(game, _type)
        
        if not item['url']:
            raise ViewError('Error playing that game.\nCheck your RugbyPass.com subscription is valid.')

        item['options'] = {'use_ia_hls': self._addon.settings.getBool('use_ia_hls'), 'position':1 if from_start else None}
        self._view.play(item)

    def service(self, params):
        try:
            games = self._update_games()
            self._check_alerts(games)
        except Exception as e:
            raise ServiceError(e)

    def _check_alerts(self, games):
        alerts = self._addon.data.get('alerts', [])
        if not alerts: return
        
        games = [g for g in games if g.id in alerts]

        _alerts = []
        for game in games:
            if game.state == Game.UPCOMING:
                _alerts.append(game.id)
                continue

            if game.state == Game.LIVE:
                _to_start = game.start - time()
                
                if self._addon.getInt('alert_when') == Alert.STREAM_START:
                    message = 'Live stream has started'
                elif self._addon.getInt('alert_when') == Alert.KICK_OFF and _to_start > 0 and _to_start <= config.POLL_TIME:
                    message = "Is about to kick-off"
                else: 
                    continue

                if self._addon.getInt('alert_type') == Alert.DIALOG:
                    if self._view.dialog_yes_no(message, heading=game.title, yeslabel='Watch', nolabel='Close'):
                        self._play(game, Game.FULL)
                else:
                    self._view.notification(message, heading=game.title, time=5000, icon=game.image)

        self._addon.data['alerts'] = _alerts