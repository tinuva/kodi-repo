M3U8_URL = 'http://iptv.matthuisman.nz/nz/radio.json'
CHANNELS_EXPIRY = (60*60*1) #1 hour