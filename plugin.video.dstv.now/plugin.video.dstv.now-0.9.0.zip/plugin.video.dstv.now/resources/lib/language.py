from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME     = 30000
    ASK_PASSWORD     = 30001
    LIVE_TV          = 30002
    CHANNEL          = 30003
    SERIES           = 30004
    MOVIES           = 30005
    KIDS             = 30006
    SPORT            = 30007
    SHOWS            = 30008
    ACTUALITY        = 30009

_ = Language()