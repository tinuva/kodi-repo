from matthuisman import plugin, gui, cache, settings, userdata, inputstream, signals

from .api import API
from .constants import LIVE_TV_EXPIRY, ALL_SERIES_EXPIRY, HEADERS
from .language import _

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not plugin.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login))
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True),  path=plugin.url_for(live_tv),  cache_key=cache.key_for(live_tv))
        folder.add_item(label=_(_.SERIES, _bold=True),  path=plugin.url_for(all_series),  cache_key=cache.key_for(all_series))
        # folder.add_item(label=_(_.MOVIES, _bold=True),  path=plugin.url_for(movies),  cache_key=cache.key_for(movies))
        # folder.add_item(label=_(_.KIDS, _bold=True),  path=plugin.url_for(kids),  cache_key=cache.key_for(kids))
        # folder.add_item(label=_(_.SPORT, _bold=True),  path=plugin.url_for(sport),  cache_key=cache.key_for(sport))
        # folder.add_item(label=_(_.SHOWS, _bold=True),  path=plugin.url_for(shows),  cache_key=cache.key_for(shows))
        # folder.add_item(label=_(_.ACTUALITY, _bold=True),  path=plugin.url_for(actuality),  cache_key=cache.key_for(actuality))
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout))

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
@plugin.login_required()
@cache.cached(LIVE_TV_EXPIRY)
def live_tv():
    folder = plugin.Folder(title=_.LIVE_TV)

    channels = api.channels()
    for channel in channels:
        folder.add_item(
            label     = _(_.CHANNEL, channel_number=channel['channelNumber'], channel_name=channel['channelName']),
            info      = {'plot': channel['description']},
            art       = {'thumb': channel['channelLogoPaths'].get('XLARGE')},
            path      = plugin.url_for(play_channel, is_live=True, id=channel['id']),
            playable  = True
        )

    return folder

@plugin.route()
@plugin.login_required()
@cache.cached(ALL_SERIES_EXPIRY)
def all_series():
    folder = plugin.Folder(title=_.SERIES)

    for row in api.all_series():
        if 'program' in row:
            folder.add_item(
                label = row['program']['title'],
                art   = {'thumb': row['program']['images']['poster']['LARGE']},
                info  = {'plot': row['program'].get('synopsis', '')},
                path  = plugin.url_for(series, id=row['program']['id']),
                cache_key = row['program']['id'],
            )
        elif 'video' in row:
            folder.add_item(
                label = row['video']['title'],
                art   = {'thumb': row['video']['images']['poster']['LARGE']},
                info  = {'plot': row['video'].get('synopsis', '')},
                path  = plugin.url_for(play_vod, id=row['video']['videoAssets'][0]['manItemId'], video=row['video']['videoAssets'][0]['url']),
                playable = True,
            )

    return folder

@plugin.route()
@plugin.login_required()
def series(id):
    series = api.series(id)
    folder = plugin.Folder(title=series['title'])

    for row in series['seasons']:
        folder.add_item(
            label = 'Season {}'.format(row['seasonNumber']),
            info  = {'plot': row.get('synopsis', '')},
            art   = {'thumb': series['images']['poster']['LARGE']},
            path  = plugin.url_for(season, series=id, season=row['seasonNumber']),
            cache_key = id,
        )

    return folder

@plugin.route()
@plugin.login_required()
def season(series, season):
    series = api.series(series)
    folder = plugin.Folder(title=series['title'])

    for row in series['seasons']:
        if int(row['seasonNumber']) != int(season):
            continue

        for video in row['videos']:
            folder.add_item(
                label = video['title'],
                info  = {
                    'plot': video['synopsis'],
                    'season': video['seasonNumber'],
                    'episode': video['seasonEpisode'],
                    'duration': video['durationInSeconds'],
                    'mediatype': 'episode',
                    'tvshowtitle': series['title'],
                },
                art   = {'thumb': video['images']['play-image']['LARGE']},
                path  = plugin.url_for(play_vod, id=video['videoAssets'][0]['manItemId'], video=video['videoAssets'][0]['url']),
                playable = True,
            )

        break

    return folder

@plugin.route()
@plugin.login_required()
#@cache.cached(OD_EXPIRY)
def movies():
    folder = plugin.Folder(title=_.MOVIES)
    return folder

@plugin.route()
@plugin.login_required()
#@cache.cached(OD_EXPIRY)
def kids():
    folder = plugin.Folder(title=_.KIDS)
    return folder

@plugin.route()
@plugin.login_required()
#@cache.cached(OD_EXPIRY)
def sport():
    folder = plugin.Folder(title=_.SPORT)
    return folder

@plugin.route()
@plugin.login_required()
#@cache.cached(OD_EXPIRY)
def shows():
    folder = plugin.Folder(title=_.SHOWS)
    return folder

@plugin.route()
@plugin.login_required()
#@cache.cached(OD_EXPIRY)
def actuality():
    folder = plugin.Folder(title=_.ACTUALITY)
    return folder

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD, default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        if api.login(username=username, password=password):
            gui.refresh()
        else:
            gui.ok(_.LOGIN_ERROR)

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()

@plugin.route()
@plugin.login_required()
def play_vod(id, video):
    url, license_url = api.play_vod(id, video)

    return plugin.Item(
        inputstream=inputstream.Widevine(license_url), 
        headers=HEADERS, 
        path=url, 
        art=False,
        properties={'inputstream.adaptive.manifest_update_parameter': 'full'},
    )

@plugin.route()
@plugin.login_required()
def play_channel(id):
    url, license_url = api.play_channel(id)

    return plugin.Item(
        inputstream=inputstream.Widevine(license_url), 
        headers=HEADERS, 
        path=url, 
        art=False,
        properties={'inputstream.adaptive.manifest_update_parameter': 'full'},
    )