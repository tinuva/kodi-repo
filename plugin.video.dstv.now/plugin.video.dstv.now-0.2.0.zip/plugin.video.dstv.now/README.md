# plugin.video.dstv.now

Unofficial 3rd Party DStv Now plugin for Kodi.

https://www.matthuisman.nz/2018/09/dstv-now-kodi-add-on.html
