from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    LOGIN            = 30000
    LOGOUT           = 30002
    SETTINGS         = 30003
    ASK_USERNAME     = 30004
    ASK_PASSWORD     = 30005
    LOGIN_ERROR      = 30006
    LOGOUT_YES_NO    = 30007
    LIVE_TV          = 30008
    CHANNEL          = 30009

_ = Language()