import hashlib
import random
import string
import urlparse
import time

import xbmc

from matthuisman import userdata, cache
from matthuisman.session import Session
from matthuisman.log import log

from .constants import HEADERS, CLIENT_ID, PLATFORM_ID, PRODUCT_ID, DEVICE_TYPE, DEVICE_NAME, LOGIN_URL, REFRESH_TOKEN_URL, API_URL, LICENSE_URL

class Error(Exception):
    pass

class API(object):
    def __init__(self):
        self.new_session()
        self._nonce = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in xrange(30))

    def new_session(self):
        self._logged_in = False
        self._session = Session(HEADERS)
        self._set_access_token(userdata.get('access_token'))

    def _set_access_token(self, token):
        if token:
            self._session.headers.update({'Authorization': token})
            self._logged_in = True

    @property
    def logged_in(self):
        return self._logged_in

    def _parse_token(self, location):
        data = dict(urlparse.parse_qsl(urlparse.urlsplit(location).fragment))
        userdata.set('access_token', data['access_token'])
        userdata.set('id_token', data['id_token'])
        userdata.set('token_expires', int(time.time()) + int(data['expires_in']) - 30)
        self._set_access_token(data['access_token'])

    def _check_token(self):
        if userdata.get('token_expires') < time.time():
            self._refresh_token()

    def _refresh_token(self):
        log('API: Refresh Token')

        params = {
            'id_token_hint': userdata.get('id_token'),
            'prompt': 'none',
            'redirect_uri': 'http://localhost:49152',
            'client_id': CLIENT_ID,
            'nonce': self._nonce,
            'scope': 'openid',
            'response_type': 'id_token token',
        }

        resp = self._session.get(REFRESH_TOKEN_URL, params=params, allow_redirects=False)
        location = resp.headers.get('location')
        if not location:
            raise Exception('Failed to refresh token!')

        self._parse_token(location)
        
    def login(self, username, password):
        log('API: Login')

        data = {
            'AuthenticationType': 'Email',
            'Email': username,
            'Password': password,
           # 'userCountry': 'South Africa',
            'redirect_uri': 'http://localhost:49152/',
            'client_id': CLIENT_ID,
            'nonce': self._nonce,
            'response_type': 'id_token token',
            'scope': 'openid',
        }

        resp = self._session.post(LOGIN_URL, data=data, allow_redirects=False)
        location = resp.headers.get('location')
        if not location:
            return False

        device_id = hashlib.sha1(username).hexdigest().upper()
        userdata.set('device_id', device_id)
        self._parse_token(location)

        return True

    def channels(self):
        log('API: Channels')
        self._check_token()

        url  = API_URL.format('epg/v2/getStreamableChannels;platformId={}'.format(PLATFORM_ID))
        data = self._session.get(url).json()
        return data['items']

    def play_channel(self, channel_id):
        log('API: Play Channel')
        self._check_token()

        url = API_URL.format('epg/v2/getEpgChannel;channelId={};platformId={}'.format(channel_id, PLATFORM_ID))
        data = self._session.get(url).json()

        device_id  = userdata.get('device_id')
        stream_url = None
        
        for stream in data['streams']:
            if stream['streamType'] == 'MobileAlt':
                stream_url = stream['playerUrl'].replace('.isml?', '.isml/.mpd?').replace('.ism?', '.ism/.mpd?')
                break

        if not stream_url:
            raise Exception('Unable to find suitable stream url.')

        parsed = urlparse.urlparse(stream_url)
        content_id = urlparse.parse_qs(parsed.query)['contentId'][0]

        url = API_URL.format('user-manager/v1/vod-authorisation;productId={};platformId={};deviceId={};deviceType={};deviceName={}'.format(
            PRODUCT_ID, PLATFORM_ID, device_id, DEVICE_TYPE, DEVICE_NAME))

        data    = self._session.post(url).json()
        session = data.get('irdetoSession')
        if not session:
            raise Exception(data.get('errorMessage'))

        session_id = session['sessionId']
        ticket     = session['ticket']

        license_url = LICENSE_URL.format(content_id, session_id, ticket, device_id)
        
        return stream_url, license_url

    def logout(self):
        log('API: Logout')
        userdata.delete('access_token')
        userdata.delete('id_token')
        userdata.delete('token_expires')
        userdata.delete('device_id')
        self.new_session()