HEADERS = {
    'User-Agent': 'okhttp/3.10.0',
    'X-Requested-With': 'com.dstvmobile.android',
    'api-consumer': 'DStvNowAndroid',
    'X-Forwarded-For': '41.57.63.249',
}

CLIENT_ID   = '9226bb7d-bd26-4b76-ba28-252d0d0eb6c5'
PRODUCT_ID  = '1b09957b-27aa-493b-a7c9-53b3cec92d63'
PLATFORM_ID = 'b058d380-69ac-4275-abfb-a2da0edfee43'
DEVICE_NAME = 'KODI'
DEVICE_TYPE = 'Android'

LOGIN_URL         = 'https://connect.dstv.com/4.1/DStvNowApp/OAuth/Login'
REFRESH_TOKEN_URL = 'https://connect.dstv.com/4.1/DStvNowApp/oauth'
API_URL           = 'https://ssl.dstv.com/api/cs-mobile/{}'
LICENSE_URL       = 'http://license.dstv.com/widevine/getLicense?CrmId=afl&AccountId=afl&ContentId={}&SessionId={}&Ticket={}&DeviceId={}'
TIMEOUT           = (10, 20)
LIVE_TV_EXPIRY    = (60*60*24) #24 hours