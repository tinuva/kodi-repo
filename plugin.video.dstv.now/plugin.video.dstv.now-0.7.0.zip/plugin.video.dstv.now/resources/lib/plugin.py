from matthuisman import plugin, gui, cache, settings, userdata, inputstream, signals

from .api import API
from .constants import LIVE_TV_EXPIRY, HEADERS
from .language import _

api = API()

@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in

@plugin.route('')
def home():
    folder = plugin.Folder()

    if not plugin.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login))
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True),  path=plugin.url_for(live_tv),  cache_key=cache.key_for(live_tv))
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout))

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))

    return folder

@plugin.route()
def login():
    while not api.logged_in:
        username = gui.input(_.ASK_USERNAME, default=userdata.get('username', '')).strip()
        if not username:
            break

        userdata.set('username', username)

        password = gui.input(_.ASK_PASSWORD, default=cache.get('password', '')).strip()
        if not password:
            break

        cache.set('password', password, expires=60)

        if api.login(username=username, password=password):
            gui.refresh()
        else:
            gui.ok(_.LOGIN_ERROR)

    cache.delete('password')

@plugin.route()
def logout():
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()

@plugin.route()
@plugin.login_required()
def play_channel(channel_id):
    url, license_url = api.play_channel(channel_id)

    return plugin.Item(
        inputstream=inputstream.Widevine(license_url), 
        headers=HEADERS, 
        path=url, 
        art=False,
        properties={'inputstream.adaptive.manifest_update_parameter': 'full'},
    )

@plugin.route()
@plugin.login_required()
@cache.cached(LIVE_TV_EXPIRY)
def live_tv():
    folder = plugin.Folder(title=_.LIVE_TV)

    channels = api.channels()
    for channel in channels:
        folder.add_item(
            label     = _(_.CHANNEL, channel_number=channel['channelNumber'], channel_name=channel['channelName']),
            info      = {'plot': channel['description']},
            art       = {'thumb': channel['channelLogoPaths'].get('XLARGE')},
            path      = plugin.url_for(play_channel, is_live=True, channel_id=channel['id']),
            playable  = True
        )

    return folder