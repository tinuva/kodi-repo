from matthuisman.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME     = 30000
    ASK_PASSWORD     = 30001
    LIVE_TV          = 30002
    CHANNEL          = 30003

_ = Language()