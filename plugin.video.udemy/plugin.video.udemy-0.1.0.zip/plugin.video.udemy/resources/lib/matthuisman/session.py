import requests

from . import userdata
from .log import log

class Session(requests.Session):
    def __init__(self, headers=None, cookies_key='_cookies', base_url='{}'):
        super(Session, self).__init__()

        self._headers     = headers or {}
        self._cookies_key = cookies_key
        self._base_url    = base_url

        self.headers.update(self._headers)
        if self._cookies_key:
            self.cookies.update(userdata.get(self._cookies_key, {}))

    def request(self, method, url, **kwargs):
        if not url.startswith('http'):
            url = self._base_url.format(url)

        try:
            resp = super(Session, self).request(method, url, **kwargs)
            result = resp.status_code
        except:
            result = 'ERROR'
        finally:
            log('[{}] {} {} {}'.format(result, method, url, kwargs if method.lower() != 'post' else ""))

        return resp

    def save_cookies(self):
        userdata.set(self._cookies_key, self.cookies.get_dict())