HEADERS = {
    'User-Agent': 'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36 UdemyAndroid 4.4.0(203) (tablet)',
    'Authorization': 'Basic YWQxMmVjYTljYmUxN2FmYWM2MjU5ZmU1ZDk4NDcxYTY6YTdjNjMwNjQ2MzA4ODI0YjIzMDFmZGI2MGVjZmQ4YTA5NDdlODJkNQ==',
}

API_URL   = 'https://www.udemy.com/api-2.0/{}'

MY_COURSES_EXPIRY = (60*30)   #30 Minutes
COURSE_EXPIRY     = (60*60*24) #24 Hours