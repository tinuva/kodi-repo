import re

from HTMLParser import HTMLParser

from matthuisman import userdata, settings, cache
from matthuisman.session import Session
from matthuisman.log import log

from .constants import HEADERS, API_URL, COURSE_EXPIRY

h = HTMLParser()
def strip_tags(text):
    if not text:
        return ''

    text = re.sub('\([^\)]*\)', '', text)
    text = re.sub('<[^>]*>', '', text)
    text = h.unescape(text)
    return text

class API(object):
    def new_session(self):
        self.logged_in = False

        sub_domain = settings.get('business_name') if settings.getBool('business_account', False) else ''
        if not sub_domain:
            sub_domain = 'www'

        if sub_domain != userdata.get('sub_domain', 'www'):
            userdata.delete('access_token')
            cache.empty()
            userdata.set('sub_domain', sub_domain)

        base_url = API_URL.format(sub_domain)

        self._session = Session(HEADERS, base_url=base_url)
        self.set_access_token(userdata.get('access_token'))

    def set_access_token(self, token):
        if token:
            self._session.headers.update({'Authorization': 'Bearer {0}'.format(token)})
            self.logged_in = True

    def my_courses(self):
        log('API: My Courses')

        params = {
            'page_size'       : 9999,
            'ordering'        : '-access_time,-enrolled',
            'fields[course]'  : 'id,title,image_480x270,image_750x422,headline,num_published_lectures,content_info,completion_ratio',
        }

        return self._session.get('users/me/subscribed-courses', params=params).json()['results']

    @cache.cached(COURSE_EXPIRY, key=lambda x, course_id: course_id)
    def course(self, course_id):
        course = {
            'title': '',
            'image': '',
            'chapters': {},
        }

        params = {
            'page_size'        : 9999,
            'fields[course]'   : 'title,image_480x270',
            'fields[chapter]'  : 'description,object_index,title,course',
            'fields[lecture]'  : 'title,object_index,description,is_published,course,id,asset',
            'fields[asset]'    : 'asset_type,length,status',
            'fields[practice]' : 'id',
            'fields[quiz]'     : 'id',
        }

        data = self._session.get('courses/{}/cached-subscriber-curriculum-items'.format(course_id), params=params).json()['results']

        chapter = None
        for row in data:
            if row['_class'] == 'chapter':
                course['title'] = row['course']['title']
                course['image'] = row['course']['image_480x270']

                chapter = {
                    'index': row['object_index'],
                    'title': row['title'],
                    'description': strip_tags(row['description']),
                    'lectures': [],
                }

                course['chapters'][row['id']] = chapter
            elif row['_class'] == 'lecture' and row['is_published'] and row['asset']['asset_type'] in ('Video', 'Audio'):
                if not chapter:
                    continue

                lecture = {
                    'id': row['id'],
                    'title': row['title'],
                    'description': strip_tags(row['description']),
                    'asset': {
                        'id': row['asset']['id'],
                        'length': row['asset']['length'],
                    }
                }

                chapter['lectures'].append(lecture)

        return course

    def get_stream_urls(self, asset_id):
        params = {
            'fields[asset]'   : '@min,status,stream_urls,length,course',
        }

        return self._session.get('assets/{0}'.format(asset_id), params=params).json().get('stream_urls', {})

    def login(self, username, password):
        log('API: Login')

        data = {
            "email": username,
            "password": password
        }

        params = {
            'fields[user]': 'title,image_100x100,name,access_token',
        }

        data = self._session.post('auth/udemy-auth/login/', params=params, data=data).json()
        access_token = data.get('access_token')
        
        if not access_token:
            error = data.get('detail', '')
            raise Exception(error)

        userdata.set('access_token', access_token)
        self.set_access_token(access_token)

    def logout(self):
        log('API: Logout')
        userdata.delete('access_token')
        cache.empty()
        self.new_session()