# plugin.video.udemy

Unofficial 3rd Party Udemy plugin for Kodi.

https://www.matthuisman.nz/2018/08/udemy-kodi-add-on.html

## Acknowledgements

Based on [@lwille](https://github.com/lwille/plugin.video.udemy) plugin. Thank you!

The Udemy logo is a registered trademark of Udemy, Inc.

Fanart Image Source: https://pixnio.com/objects/computer/internet-technology-laptop-computer-computer-keyboard-notebook
