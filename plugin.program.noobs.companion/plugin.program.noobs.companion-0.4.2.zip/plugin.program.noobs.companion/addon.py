﻿# coding=utf-8
from __future__ import absolute_import

import os, time, traceback
from urlparse import parse_qsl

import xbmc, xbmcplugin, xbmcgui

from resources.lib import util
from resources.lib import config

dialog = xbmcgui.Dialog()

def error(message):
    dialog.ok('ERROR!', str(message))

def boot_system(system_name):
    system_key = util.get_system_key(system_name)
    system = util.get_system(system_key)
    if not system:
        dialog.notification(config.__addonname__, 'Could not find system: {0}'.format(system_name), os.path.join(config.__addonpath__, 'icon.png'), 3000)
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    dialog.notification(name, 'Booting....', icon, 2000)
    time.sleep(1)
    util.partition_boot(system.get('partitions')[0])

def install_system(system_key):
    from resources.lib import install

    system = util.get_system(system_key)
    if not system:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    function = getattr(install, util.get_system_info(system_key).get('boot-back', ''), None)
    if not function:
        dialog.notification(name, 'Currently not Boot-Back installable.', icon, 5000)
        return

    function(system.get('partitions'))
    dialog.notification(name, 'Boot-Back Installed', icon, 2000)
    xbmc.executebuiltin('Container.Refresh')

def defaultboot_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    util.partition_defaultboot(system.get('partitions')[0])
    dialog.notification(name, 'Set to Default Boot', icon, 2000)

def rename_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    kb = xbmc.Keyboard()
    kb.setHeading('Rename system')
    kb.setDefault(system.get('name',''))
    kb.doModal()
    if not kb.isConfirmed():
        return

    new_name = kb.getText()
    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    util.update_system(system_key, {'name' : new_name})
    xbmc.executebuiltin('Container.Refresh')

def set_icon_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    new_icon = dialog.browseSingle(2, 'Choose a new icon', 'files')
    if not new_icon:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    util.update_system(system_key, {'icon' : new_icon})
    xbmc.executebuiltin('Container.Refresh')

def archive_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    folder = dialog.browse(type=0, heading='Select location for OS to be archived too', shares='files')
    if not folder:
        return

    dialog.notification(name, 'Archive started..', icon, 5000)
    dst = util.archive_system(system, folder)
    dialog.ok("ARCHIVE SUCCESS!", '{0} has successfully been archived to {1}'.format(name, dst))

def clear_data():
    if dialog.yesno('Clear Data?', 'This will delete the current saved data for this addon.\nYou will lose any custom names / icons you have set.', ):
        util.delete_data()
        dialog.notification(config.__addonname__, 'Data cleared', os.path.join(config.__addonpath__, 'icon.png'), 3000)

def list_systems():
    systems = util.get_systems()
    
    for system_key in sorted(systems.iterkeys()):
        system = systems[system_key]

        listitem = xbmcgui.ListItem(label=system['name'], thumbnailImage=system['icon'])

        context_items = [
            ('Rename', "XBMC.RunPlugin({0}?action=rename&system={1})".format(sys.argv[0], system_key)),
            ('Set Icon', "XBMC.RunPlugin({0}?action=set_icon&system={1})".format(sys.argv[0], system_key)),
            ('Set to Default Boot', "XBMC.RunPlugin({0}?action=defaultboot&system={1})".format(sys.argv[0], system_key)),
        ]

        if config.DATA['system']['recovery_partition'] not in system.get('partitions'):
            context_items.extend((
                ('Archive System', "XBMC.RunPlugin({0}?action=archive&system={1})".format(sys.argv[0], system_key)),
            ))

        if util.get_system_info(system_key).get('boot-back', None):
            context_items.extend((
                ('Install Boot-Back', "XBMC.RunPlugin({0}?action=install&system={1})".format(sys.argv[0], system_key)),
            ))

        listitem.addContextMenuItems(context_items)

        action = "{0}?action=boot&system={1}".format(sys.argv[0], system_key)
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), action, listitem, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

try:
    if not xbmc.getCondVisibility('System.Platform.Linux.RaspberryPi'):
        dialog.ok("Not Supported", 'This addon only works on the Raspberry Pi range of boards.')
        sys.exit(0)

    if config.__system__ == config.NOT_SUPPORTED:
        dialog.ok("Not Supported", 'The supported systems are:\nLibreELEC, OpenELEC, OSMC & Xbian')
        sys.exit(0)

    util.init()

    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if action == 'boot':
        boot_system(params.get('system'))
    elif action == 'install':
        install_system(params.get('system'))
    elif action == 'defaultboot':
        defaultboot_system(params.get('system'))
    elif action == 'rename':
        rename_system(params.get('system'))
    elif action == 'set_icon':
        set_icon_system(params.get('system'))
    elif action == 'archive':
        archive_system(params.get('system'))
    elif action == 'clear':
        clear_data()
    else:
        list_systems()
except Exception as e:
    traceback.print_exc()
    error(e)