import os, re, json
import xbmc, xbmcaddon

__addon__           = xbmcaddon.Addon(id='plugin.program.noobs.companion')
__addonid__         = __addon__.getAddonInfo('id').decode('utf-8')
__addonversion__    = __addon__.getAddonInfo('version')
__addonname__       = __addon__.getAddonInfo('name').decode('utf-8')
__language__        = __addon__.getLocalizedString
__addonpath__       = xbmc.translatePath(__addon__.getAddonInfo('path'))
__datapath__        = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__files_path__      = os.path.join(__addonpath__, 'resources', 'files')
__data_file__       = os.path.join(__datapath__, 'data.json')
__partition_pattern = re.compile(r'^(/dev/.*[^0-9])([0-9]+)$')
__recovery_part__   = 1
__settings_part__   = 5

LIBREELEC = 'LibreELEC'
OSMC = 'OSMC'
XBIAN = 'XBIAN'
NOT_SUPPORTED = 'Not Supported'

if os.path.exists('/storage/.kodi'):
    __system__ = LIBREELEC
    __boot__   = '/flash'
    __reboot__ = "reboot {0}"
    __cmd__    = '{0}'
elif os.path.exists('/home/osmc'):
    __system__ = OSMC
    __boot__   = '/boot'
    __reboot__ = "reboot {0}"
    __cmd__    = 'sudo su -c "{0}"'
elif os.path.exists('/home/xbian'):
    __system__ = XBIAN
    __boot__   = "/boot"
    __reboot__ = "'{1}' {0}"
    __cmd__    = 'echo raspberry | sudo -S su -c "{0}"'
else:
    __system__ = NOT_SUPPORTED

if not os.path.exists(__datapath__):
    os.mkdir(__datapath__)

try:
    with open(__data_file__, 'r') as f:
        DATA = json.loads(f.read())
except:
    DATA = {'user':{}, 'system':{}}

def save_data():
    with open(__data_file__, 'w') as f:
        f.write(json.dumps(DATA, indent=4, separators=(',', ': ')))

__systems__ = [
    # https://downloads.raspberrypi.org/os_list_v3.json #
    {'pattern': 'LibreELEC', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/libreelec.png'},
    {'pattern': 'OSMC', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/osmc.png'},
    {'pattern': 'Lakka', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/lakka.png', 'boot-back': 'lakka'},
    {'pattern': 'RaspbianLite', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/raspbian.png'},
    {'pattern': 'Raspbian', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/raspbian.png', 'boot-back': 'raspbian'},
    {'pattern': 'recalbox', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/recalboxos.png', 'boot-back': 'recalbox'},
    {'pattern': 'Screenly', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/screenlyose.png'},
    {'pattern': 'RISC', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/riscos.png'},
    {'pattern': 'Windows', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/windows10iotcore.png'},
    {'pattern': 'TLXOS', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/tlxos.png'},

    # https://raw.githubusercontent.com/procount/pinn-os/master/os/os_list_v3.json #
    {'pattern': 'AIYprojects', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/aiyprojects.png'},
    {'pattern': 'CStemBian', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/cstembian.png'},
    {'pattern': 'PiTop', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/pitop.png'},
    {'pattern': 'solydx', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/solydx.png'},
    {'pattern': 'ubuntuMate1604LTS', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/ubuntu-mate.png'},
    {'pattern': 'openelec', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/openelec.png'},
    {'pattern': 'XBian', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/xbian.png'},
    {'pattern': 'Retropie', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/retropie.png', 'boot-back': 'retropie'},
    {'pattern': 'kali', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/kali.png'},
    {'pattern': 'rtandroid', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/rtandroid.png'},
    {'pattern': 'lede2', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/lede2.png'},
    {'pattern': 'Arch', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/arch.png'},
    {'pattern': 'void', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/void.png'},
    {'pattern': 'gentoo', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/gentoo.png'},
    {'pattern': 'hypriotos', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/hypriot.png'},
    {'pattern': 'raspberry-vi', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/raspberry-vi.png'},
    {'pattern': 'picoreplayer', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/picoreplayer.png'},
    {'pattern': 'quirky', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/quirky.png'},
    {'pattern': 'lineage', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/lineage.png'},

    # https://raw.githubusercontent.com/matthuisman/pinn-os/master/os/os_list_v3.json #
    {'pattern': 'batocera', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/batocera.png', 'boot-back': 'batocera'},
    {'pattern': 'Kano_OS', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/kano_os.png'},
    {'pattern': 'RasPlex', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/rasplex.png'},
    {'pattern': 'PiMusicBox', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/pimusicbox.png'},
    {'pattern': 'RetroX', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/retrox.png'},
    {'pattern': 'FlintOS', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/flintos.png'},
    {'pattern': 'FedBerry', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/fedberry.png'},
    {'pattern': 'Amibian', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/amibian.png'},
    {'pattern': 'Gladys', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/gladys.png'},
    {'pattern': 'DietPi', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/dietpi.png'},
    {'pattern': 'resinOS', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/resinos.png'},

    # Built-in
    {'pattern': 'NOOBS', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/noobs.png'},
    {'pattern': 'PINN', 'icon': 'https://raw.githubusercontent.com/matthuisman/images/master/noobs-companion/pinn.png'},
]